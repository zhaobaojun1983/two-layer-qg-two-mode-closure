"""Long-time, matched-initial-field validation of the two-mode closure.

NumPy only. All runs use one fixed Nmode=24 trial/test basis assembled with
1025 quadrature nodes. Parent resolution changes pad these same modes with
zeros: they do not change the initial physical field or its normalization.
Errors are sampled every 5 original nondimensional time units. Threshold
crossings are reported as sample brackets, not interpolated exact times.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import time
import numpy as np

from _coeffs_strict import build
from two_mode_closure import closure_coefficients, fourier_grid, ParentQG, make_modal_rhs

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "long_time_results"


def fixed_parent(co, wave, mask, N, Ny):
    """Change parent resolution while retaining the exact same trial fields."""
    b = co["basis"]
    nmode = b["Sm"].shape[0]
    if N < nmode:
        raise ValueError("Parent N must contain the fixed trial modes.")
    y, Sm, A0, B0 = build(co["F"], co["s"], co["lam"], 0., N=N, M=Ny)
    def pad_modes(v):
        return np.pad(v.reshape(2, 2, nmode), ((0, 0), (0, 0), (0, N-nmode))).reshape(2, 2*N)
    basis = dict(b, y=y, Sm=Sm, A0=A0, B0=B0,
                 phi=pad_modes(b["phi"]), adjoint=pad_modes(b["adjoint"]))
    return ParentQG(dict(co, basis=basis), wave, mask)


def step(rhs, u, dt):
    k1 = rhs(u)
    k2 = rhs(u + .5*dt*k1)
    k3 = rhs(u + .5*dt*k2)
    k4 = rhs(u + dt*k3)
    return u + dt/6*(k1+2*k2+2*k3+k4)


def norm(u):
    return float(np.linalg.norm(u))


def diagnostics(parent, u, full, lw, wave, mask):
    pa = parent.amplitudes(u)
    uf, ul = parent.reconstruct(full), parent.reconstruct(lw)
    un = norm(u)
    flat_hat = np.fft.fft(u, axis=-1)
    active_max = np.max(np.abs(wave[mask]))
    tail = np.abs(wave) >= .75*active_max
    return dict(full_error=norm(u-uf)/un, longwave_error=norm(u-ul)/un,
        offspace=norm(u-parent.reconstruct(pa))/un,
        retained_full=norm(parent.reconstruct(pa-full))/un,
        retained_longwave=norm(parent.reconstruct(pa-lw))/un,
        longwave_full_difference=norm(uf-ul)/un,
        amplitude_full=norm(pa-full)/max(norm(pa), 1e-300),
        amplitude_longwave=norm(pa-lw)/max(norm(pa), 1e-300),
        parent_norm=un,
        x_tail=norm(flat_hat[...,tail])/max(norm(flat_hat), 1e-300),
        y_tail=norm(u[:,-max(2,parent.N//4):])/un)


def run(name, k=.1, amp=.01, ratio=.5, phase=np.pi/2, lam=.2,
        N=24, Nx=32, Ny=129, dt=.2, duration=3000., sample=5.):
    OUT.mkdir(exist_ok=True)
    settings = dict(name=name, k=k, amp=amp, ratio=ratio, phase=phase, lam=lam,
                    F=.5, s=.5, N=N, Nx=Nx, Ny=Ny, dt=dt, duration=duration,
                    sample=sample, Nmode=24, coefficient_quadrature=1025)
    if (OUT / (name+".json")).exists():
        previous = json.loads((OUT / (name+".json")).read_text())
        if previous["settings"] == settings:
            print(name+" already complete", flush=True)
            return previous
        raise ValueError("Existing run has different settings: "+name)
    co = closure_coefficients(lam=lam, N=24, M=1025)
    x, wave, mask = fourier_grid(k, Nx)
    parent = fixed_parent(co, wave, mask, N, Ny)
    a0 = np.array([amp*np.cos(k*x), amp*ratio*np.cos(k*x-phase)])
    u, full, lw = parent.reconstruct(a0), a0.copy(), a0.copy()
    temporal = np.eye(2)[None] - wave[mask,None,None]**2*co["M"][None]
    sv = np.linalg.svd(temporal, compute_uv=False)
    checks = dict(mass_min_singular=float(sv[:,-1].min()),
                  mass_max_condition=float((sv[:,0]/sv[:,-1]).max()),
                  projector_identity_error=norm(parent.extract@parent.phi-np.eye(2)))
    # Necessary explicit-RK4 spectral stability check, including all active waves.
    max_imag, max_growth = 0., 0.
    for w in wave[mask]:
        operators = [(-1j*w)*(parent.A0-w*w*parent.H)/(parent.b0-w*w)[:,None],
            (-1j*w)*np.linalg.solve(np.eye(2)-w*w*co["M"], co["C"]-w*w*co["E"]),
            (-1j*w)*(co["C"]-w*w*co["D"])]
        for op in operators:
            eigen = np.linalg.eigvals(op)
            max_imag = max(max_imag, float(np.abs(eigen.imag).max()))
            max_growth = max(max_growth, float(eigen.real.max()))
    checks.update(max_linear_frequency=max_imag, max_linear_growth=max_growth,
                  rk4_imaginary_axis_limit=2*np.sqrt(2)/max_imag)
    if dt*max_imag >= 2*np.sqrt(2)*.95 or max_growth > 1e-9:
        raise ValueError("Linear spectral precondition failed: "+str(checks))
    rhs = [parent.rhs, make_modal_rhs(co,wave,mask,True), make_modal_rhs(co,wave,mask,False)]
    steps_per_sample = int(np.ceil(sample/dt))
    actual_dt = sample/steps_per_sample
    nsamples = int(round(duration/sample))
    if abs(nsamples*sample-duration)>1e-10:
        raise ValueError("Duration must be an integer number of sample intervals.")
    times, records, us, fs, ls = [0.], [diagnostics(parent,u,full,lw,wave,mask)], [u.copy()], [full.copy()], [lw.copy()]
    started = time.perf_counter()
    for j in range(1, nsamples+1):
        for _ in range(steps_per_sample):
            u, full, lw = step(rhs[0],u,actual_dt), step(rhs[1],full,actual_dt), step(rhs[2],lw,actual_dt)
        if not all(np.all(np.isfinite(v)) for v in (u,full,lw)):
            raise FloatingPointError(f"Nonfinite state at t={j*sample}")
        times.append(j*sample)
        records.append(diagnostics(parent,u,full,lw,wave,mask))
        us.append(u.copy()); fs.append(full.copy()); ls.append(lw.copy())
        if j % max(1,int(500/sample)) == 0:
            print(f"{name} t={j*sample:g}: lw={100*records[-1]['longwave_error']:.4f}% off={100*records[-1]['offspace']:.4f}% ({time.perf_counter()-started:.1f}s)",flush=True)
    arrays = {key: np.array([row[key] for row in records]) for key in records[0]}
    arrays.update(time=np.array(times), parent=np.array(us), full=np.array(fs), longwave=np.array(ls),
                  phi=parent.phi, extract=parent.extract, initial_amplitudes=a0)
    summary = dict(settings=settings, checks=checks, actual_dt=actual_dt,
        runtime_seconds=time.perf_counter()-started,
        reference_self_nonlinear_time=1/(abs(co["G"][0,0,0])*amp*k) if abs(co["G"][0,0,0])>1e-10 else None,
        final=records[-1], maxima={key:float(arrays[key].max()) for key in records[0]},
        threshold_brackets={})
    for err in ("longwave_error", "full_error", "offspace"):
        summary["threshold_brackets"][err]={}
        for threshold in (.01,.05,.1):
            hits = np.flatnonzero(arrays[err] > threshold)
            summary["threshold_brackets"][err][str(threshold)] = [times[max(0,int(hits[0])-1)],times[int(hits[0])]] if len(hits) else None
    summary["source_sha256"] = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
        (Path(__file__),ROOT/"two_mode_closure.py",ROOT/"_coeffs_strict.py")}
    np.savez_compressed(OUT/(name+".npz"), **arrays)
    with (OUT/(name+".csv")).open("w",newline="",encoding="utf-8") as handle:
        writer=csv.DictWriter(handle,fieldnames=["time"]+list(records[0])); writer.writeheader()
        writer.writerows(dict(time=t,**r) for t,r in zip(times,records))
    (OUT/(name+".json")).write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print("COMPLETE "+name+" "+json.dumps(summary["threshold_brackets"]),flush=True)
    return summary


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("name")
    for key,default,kind in [("k",.1,float),("amp",.01,float),("ratio",.5,float),("phase",np.pi/2,float),
                             ("lam",.2,float),("N",24,int),("Nx",32,int),("Ny",129,int),
                             ("dt",.2,float),("duration",3000.,float),("sample",5.,float)]:
        parser.add_argument("--"+key,type=kind,default=default)
    run(**vars(parser.parse_args()))
