"""Fixed-basis two-mode Petrov--Galerkin closure (NumPy only).

All amplitudes below multiply the k=0 modes returned by modal_basis.
The long-wave system retains the FULL dispersion matrix.  No dispersion-
diagonal coordinate transform is used in field reconstruction.
"""
import numpy as np

from _coeffs_strict import L, U, modal_basis, ordered_kernel, project


def closure_coefficients(F=.5, s=.5, lam=.2, N=64, M=1025):
    basis = modal_basis(F, s, lam, N=N, M=M)
    fields = basis["fields"]
    mass = np.column_stack([project(basis, fields[j, :, 0]) for j in range(2)])
    uv = U(basis["y"], lam)
    Hfields = [np.array([uv * (v[0] + s * v[1]),
                        uv * (s * v[0] + v[1])]) for v in fields[:, :, 0]]
    E = np.column_stack([project(basis, v) for v in Hfields])
    C = np.diag(basis["c"])
    G = np.empty((2, 2, 2))
    R = np.empty_like(G)
    for p in range(2):
        for q in range(2):
            G[:, p, q] = project(basis, ordered_kernel(fields[p], fields[q], F))
            pp, tp = fields[p, :, 0]
            pqy, tqy = fields[q, :, 1]
            R[:, p, q] = project(basis, np.array([pp * pqy + tp * tqy,
                                                 pp * tqy + tp * pqy]))
    return dict(F=F, s=s, lam=lam, basis=basis, C=C, M=mass, E=E,
                D=E - mass @ C, G=G, R=R)


def fourier_grid(k, Nx=32):
    length = 2 * np.pi / k
    x = np.arange(Nx) * length / Nx
    wave = 2 * np.pi * np.fft.fftfreq(Nx, d=length / Nx)
    # The retained x modes satisfy the usual strict 2/3 condition.
    mask = np.abs(np.fft.fftfreq(Nx) * Nx) < Nx / 3
    return x, wave, mask


def dx(a, wave, order=1):
    return np.fft.ifft(np.fft.fft(a, axis=-1) * (1j * wave) ** order,
                       axis=-1).real


def filter_x(a, mask):
    return np.fft.ifft(np.fft.fft(a, axis=-1) * mask, axis=-1).real


def modal_nonlinearity(a, wave, coeffs, include_x=True):
    ax = dx(a, wave)
    out = np.einsum("ipq,px,qx->ix", coeffs["G"], a, ax)
    if include_x:
        axx, axxx = dx(a, wave, 2), dx(a, wave, 3)
        out += np.einsum("ipq,px,qx->ix", coeffs["R"], ax, axx)
        out -= np.einsum("iqp,px,qx->ix", coeffs["R"], a, axxx)
    return out


def make_modal_rhs(coeffs, wave, mask, full=False):
    C, M, E, D = (coeffs[key] for key in ("C", "M", "E", "D"))
    # Fourier blocks of the exact projected temporal operator.
    temporal = np.eye(2)[None] - wave[:, None, None] ** 2 * M[None]
    inverse = np.linalg.inv(temporal)
    dispersion = E if full else D

    def rhs(a):
        value = -C @ dx(a, wave) - dispersion @ dx(a, wave, 3)
        value -= filter_x(modal_nonlinearity(a, wave, coeffs, full), mask)
        if full:
            value_hat = np.einsum("xij,jx->ix", inverse, np.fft.fft(value, axis=-1))
            value = np.fft.ifft(value_hat, axis=-1).real
        return filter_x(value, mask)

    return rhs


class ParentQG:
    """Fourier-x / sine-y Galerkin discretization of the parent PV equations.

    u is a real array of shape (2,N,Nx), holding sine coefficients of psi,tau.
    This implementation evaluates the parent Jacobians directly; it does not
    use G or R to compute nonlinear forcing.
    """
    def __init__(self, coeffs, wave, mask):
        basis = coeffs["basis"]
        self.F, self.wave, self.mask = coeffs["F"], wave, mask
        self.N = basis["Sm"].shape[0]
        self.S = basis["Sm"].T
        ny = len(basis["y"])
        weights = np.full(ny, 2 * L / (ny - 1) / L)
        weights[[0, -1]] *= .5
        self.project_sine = basis["Sm"] * weights
        kn = np.arange(1, self.N + 1) * np.pi / (2 * L)
        self.Sy = np.cos((basis["y"][:, None] + L) * kn[None]) * kn[None]
        self.b0 = np.diag(basis["B0"])
        self.bk = self.b0[:, None] - wave[None] ** 2
        uv = U(basis["y"], coeffs["lam"])
        HU = self.project_sine @ (uv[:, None] * self.S)
        HS = coeffs["s"] * HU
        self.H = np.block([[HU, HS], [HS, HU]])
        self.A0 = basis["A0"]
        self.phi = basis["phi"].T
        self.extract = basis["adjoint"] @ basis["B0"]

    def reconstruct(self, a):
        return (self.phi @ a).reshape(2, self.N, -1)

    def amplitudes(self, u):
        return self.extract @ u.reshape(2 * self.N, -1)

    def nonlinear_grid(self, u):
        flat = u.reshape(2 * self.N, -1)
        qhat = np.fft.fft(flat, axis=-1) * self.bk
        q = np.fft.ifft(qhat, axis=-1).real.reshape(u.shape)
        ux = np.einsum("yn,cnx->cyx", self.S, dx(u, self.wave))
        uy = np.einsum("yn,cnx->cyx", self.Sy, u)
        qx = np.einsum("yn,cnx->cyx", self.S, dx(q, self.wave))
        qy = np.einsum("yn,cnx->cyx", self.Sy, q)
        J = lambda a, b: ux[a] * qy[b] - uy[a] * qx[b]
        return np.array([J(0, 0) + J(1, 1), J(0, 1) + J(1, 0)])

    def nonlinear_sine(self, u):
        return np.einsum("ny,cyx->cnx", self.project_sine, self.nonlinear_grid(u))

    def rhs(self, u):
        flat = u.reshape(2 * self.N, -1)
        linear = self.A0 @ dx(flat, self.wave) + self.H @ dx(flat, self.wave, 3)
        forcing = linear + self.nonlinear_sine(u).reshape(flat.shape)
        value_hat = -np.fft.fft(forcing, axis=-1) / self.bk
        return np.fft.ifft(value_hat * self.mask, axis=-1).real.reshape(u.shape)


def rk4(rhs, initial, duration, dt):
    steps = int(np.ceil(duration / dt))
    dt = duration / steps
    state = initial.copy()
    for _ in range(steps):
        k1 = rhs(state)
        k2 = rhs(state + dt * k1 / 2)
        k3 = rhs(state + dt * k2 / 2)
        k4 = rhs(state + dt * k3)
        state += dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6
    return state
