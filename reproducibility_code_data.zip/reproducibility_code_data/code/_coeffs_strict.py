# -*- coding: utf-8 -*-
"""Two-layer long-wave coefficients with the full vector adjoint projection.

LHS convention: B0 u_t + A0 u_x + N(u,u) = 0, so quadratic
coefficients are +<phi_dag,N>, with <phi_dag,B0 phi> = 1.
muAB/nuAB multiply A B_X; muBA/nuBA multiply B A_X.
xiB/xiC use dispersion-diagonal coordinates, not a fixed k=0 basis.
"""
import numpy as np

# Baseline nondimensional parameters of the manuscript.
UM, UJ, W, L, BETA = 0.15, 0.40, 0.65, 1.0, 1.0
COEFFICIENT_SCHEMA = "vector-adjoint-ordered-v2"
COEFFICIENT_KEYS = ("cB", "cC", "xiB", "xiC", "muBB", "muCC", "muAB",
                    "muBA", "nuBB", "nuCC", "nuAB", "nuBA")


def U(y, lam):
    return UM + UJ / np.cosh((y - lam) / W) ** 2


def U1(y, lam):
    return -2 * UJ * np.tanh((y - lam) / W) / np.cosh((y - lam) / W) ** 2 / W


def U2(y, lam):
    s2 = 1.0 / np.cosh((y - lam) / W) ** 2
    return UJ * (4 * s2 - 6 * s2 ** 2) / W ** 2


def build(F, s, lam, k, N=160, M=1200):
    yy = np.linspace(-L, L, M); h = 2 * L / (M - 1)
    Kn = np.arange(1, N + 1)[:, None] * np.pi / (2 * L)
    Sm = np.sin(Kn * (yy + L))
    uv = U(yy, lam); u2v = U2(yy, lam)

    def mm(f):
        return Sm @ (f * Sm).T * h / L
    MU, MS = mm(uv), mm(s * uv)
    MB = mm(BETA - u2v)
    M2FS = mm(2 * F * s * uv - s * u2v)
    DB = np.diag(-(Kn[:, 0] ** 2 + k ** 2))
    DC = DB - 2 * F * np.eye(N)
    Z = np.zeros((N, N))
    A = np.block([[MU @ DB + MB, MS @ DC + M2FS],
                  [MS @ DB + M2FS, MU @ DC + MB]])
    B = np.block([[DB, Z], [Z, DC]])
    return yy, Sm, A, B


def _eigensystem(A, B):
    # B is nonsingular and diagonal in the channel sine basis.
    w, V = np.linalg.eig(A / np.diag(B)[:, None])
    if np.max(np.abs(w.imag)) > 1e-9:
        raise ValueError("The selected basic flow has a non-real spectrum.")
    return w.real, V.real


def _pick(w, r, bt):
    idx = np.where(r < 1.0 if bt else r > 1.0)[0]
    if len(idx) == 0:
        raise ValueError("No mode with the requested BT/BC character was found.")
    return int(idx[np.argmin(w[idx])])


def modal_basis(F, s, lam, N=160, M=1200):
    yy, Sm, A, B = build(F, s, lam, 0.0, N=N, M=M)
    w, V = _eigensystem(A, B)
    r = np.linalg.norm(V[N:], axis=0) / np.maximum(np.linalg.norm(V[:N], axis=0), 1e-300)
    js = [_pick(w, r, True), _pick(w, r, False)]
    c = w[js]
    if abs(c[0] - c[1]) < 1e-8:
        raise ValueError("Distinct modal speeds are required for dispersion diagonalization.")
    wA, VA = _eigensystem(A.T, B.T)
    phi, adjoint, fields, left_fields = [], [], [], []
    Kn = np.arange(1, N + 1)[:, None] * np.pi / (2 * L)
    Cm = np.cos(Kn * (yy + L))
    derivative_bases = [Sm, Kn * Cm, -Kn ** 2 * Sm, -Kn ** 3 * Cm]
    for mode, j in enumerate(js):
        v = V[:, j].copy()
        g = Sm.T @ v[mode * N:(mode + 1) * N]
        v /= g[int(np.argmax(np.abs(g)))]
        a = VA[:, int(np.argmin(np.abs(wA - w[j])))].copy()
        a /= a @ (B @ v)
        phi.append(v); adjoint.append(a)
        fields.append([[part @ base for base in derivative_bases]
                       for part in (v[:N], v[N:])])
        left_fields.append([Sm.T @ a[:N] / L, Sm.T @ a[N:] / L])
    return dict(y=yy, Sm=Sm, A0=A, B0=B, c=c, phi=np.array(phi),
                adjoint=np.array(adjoint), fields=np.array(fields),
                left_fields=np.array(left_fields))


def ordered_kernel(a, b, F):
    """Coefficient of amplitude_a * dX(amplitude_b) in both PV equations."""
    pa, ta = a; pb, tb = b
    NB = pb[0] * pa[3] - pa[1] * pb[2] + tb[0] * ta[3] - ta[1] * tb[2]
    NC = (pb[0] * (ta[3] - 2 * F * ta[1]) - pa[1] * (tb[2] - 2 * F * tb[0])
          + tb[0] * pa[3] - ta[1] * pb[2])
    return np.array([NB, NC])


def project(basis, forcing):
    return np.trapezoid(np.sum(basis["left_fields"] * forcing[None, :, :], axis=1),
                        basis["y"], axis=1)


def dispersion_matrix(basis, s, lam):
    # Fixed-basis D_ij=<phi_i^dag,(H-c_j I)phi_j>, after u_xxt=-C u_xxx.
    uv = U(basis["y"], lam)
    D = np.empty((2, 2))
    for j in range(2):
        p, t = basis["fields"][j, :, 0, :]
        forcing = np.array([(uv - basis["c"][j]) * p + s * uv * t,
                            s * uv * p + (uv - basis["c"][j]) * t])
        D[:, j] = project(basis, forcing)
    return D


def coeffs_strict(F, s, lam, N=160, M=1200):
    basis = modal_basis(F, s, lam, N=N, M=M)
    D = dispersion_matrix(basis, s, lam)
    # a=b+P b_XX, P_ij=-D_ij/(c_i-c_j), i!=j, removes cross dispersion.
    # Leading quadratic coefficients are unchanged by this linear transformation.
    pairs = [(0, 0), (1, 1), (0, 1), (1, 0)]
    G = np.array([project(basis, ordered_kernel(basis["fields"][i], basis["fields"][j], F))
                  for i, j in pairs]).T
    values = [*basis["c"], D[0, 0], D[1, 1], *G[0], *G[1]]
    return dict(zip(COEFFICIENT_KEYS, map(float, values)))


if __name__ == "__main__":
    for key, value in coeffs_strict(0.5, 0.5, 0.2).items():
        print("%6s = %+.9f" % (key, value))
