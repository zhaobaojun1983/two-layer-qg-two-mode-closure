"""Dealiased Fourier / matrix ETDRK4 evolution of the corrected long-wave PDE.

Evolution is in zeta=x-v*t; a stationary BVP therefore remains stationary.
All four dispersion and eight ordered quadratic coefficients are retained.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / ".local_python"))
from scipy.interpolate import BPoly
from scipy.optimize import minimize_scalar

OUT = ROOT / "wave_propagation_results"


def phi(z, order):
    z = np.asarray(z, dtype=complex)
    small = np.abs(z) < .75
    safe = np.where(small, 1., z)
    value = np.expm1(safe) / safe
    import math
    for j in range(2, order + 1):
        value = (value - 1. / math.factorial(j - 1)) / safe
    term = np.full(z.shape, 1. / math.factorial(order), dtype=complex)
    series = term.copy()
    for m in range(1, 32):
        term = term * np.where(small, z, 0.) / (m + order)
        series += term
    return np.where(small, series, value)


class FourierETDRK4:
    def __init__(self, C, D, G, length, nx, dt, frame_speed=0.):
        self.C, self.D, self.G = map(np.asarray, (C, D, G))
        self.length, self.nx, self.dt = length, nx, dt
        self.frame_speed = frame_speed
        self.x = (np.arange(nx) - nx // 2) * length / nx
        self.k = 2 * np.pi * np.fft.fftfreq(nx, d=length / nx)
        self.mask = np.abs(np.fft.fftfreq(nx) * nx) < nx / 3
        blocks = -(self.C - frame_speed * np.eye(2))[None] + self.k[:, None, None] ** 2 * self.D
        eig, vec = np.linalg.eig(blocks)
        if np.max(np.abs(eig.imag)) > 1e-10:
            raise ValueError("This experiment expects the real-spectrum baseline linear blocks.")
        inv = np.linalg.inv(vec)
        z = dt * 1j * self.k[:, None] * eig
        matrix = lambda f: np.einsum("kij,kj,kjl->kil", vec, f, inv)
        self.E, self.E2 = matrix(np.exp(z)), matrix(np.exp(z / 2))
        self.Q = matrix(dt / 2 * phi(z / 2, 1))
        self.f1 = matrix(dt * (phi(z, 1) - 3 * phi(z, 2) + 4 * phi(z, 3)))
        self.f2 = matrix(dt * (phi(z, 2) - 2 * phi(z, 3)))
        self.f3 = matrix(dt * (-phi(z, 2) + 4 * phi(z, 3)))

    def project(self, u):
        return np.fft.fft(u, axis=-1) * self.mask

    def nonlinear(self, h):
        h = h * self.mask
        u = np.fft.ifft(h, axis=-1).real
        ux = np.fft.ifft(h * (1j * self.k), axis=-1).real
        return -np.fft.fft(np.einsum("ipq,px,qx->ix", self.G, u, ux), axis=-1) * self.mask

    @staticmethod
    def multiply(matrix, h):
        return np.einsum("kij,jk->ik", matrix, h)

    def step(self, h):
        apply = self.multiply
        n0 = self.nonlinear(h)
        a = apply(self.E2, h) + apply(self.Q, n0)
        na = self.nonlinear(a)
        b = apply(self.E2, h) + apply(self.Q, na)
        nb = self.nonlinear(b)
        c = apply(self.E2, a) + apply(self.Q, 2 * nb - n0)
        nc = self.nonlinear(c)
        result = apply(self.E, h) + apply(self.f1, n0) + 2 * apply(self.f2, na + nb) + apply(self.f3, nc)
        # Preserve the generated mean; remove only unretained Fourier modes.
        return np.fft.fft(np.fft.ifft(result, axis=-1).real, axis=-1) * self.mask


def reference_profile(x):
    ref = json.loads((ROOT / "traveling_wave_results/reference.json").read_text())
    with np.load(ROOT / "traveling_wave_results/reference.npz") as data:
        mesh, y = data["mesh"], data["scaled_states"]
    interpolator = BPoly.from_derivatives(mesh, [np.array([y[:2, j], y[2:4, j], y[4:6, j]]) for j in range(len(mesh))])
    scaled = np.abs(x) * ref["kappa_seed"]
    u = np.zeros((2, len(x)))
    inside = scaled <= mesh[-1]
    u[:, inside] = ref["amplitude_scale"] * interpolator(scaled[inside]).T
    # The BVP endpoint is below 6e-16; zero extension prevents extrapolation.
    return ref, u


def initial_perturbation(x, u, kind, epsilon):
    if kind == "none":
        return np.zeros_like(u)
    if kind == "amplitude":
        return epsilon * u
    if kind == "B_only":
        return np.array([np.zeros_like(x), epsilon * u[1]])
    if kind != "localized":
        raise ValueError(kind)
    # Fixed analytic smooth, asymmetric perturbations; no grid-dependent noise.
    rng = np.random.default_rng(20261031)
    wave = np.linspace(.025, .20, 12)
    phases = rng.uniform(0, 2 * np.pi, (2, 12))
    weights = rng.normal(size=(2, 12))
    f = np.array([np.sum(weights[i, :, None] * np.cos(wave[:, None] * x + phases[i, :, None]), axis=0) for i in range(2)])
    f *= np.exp(-(x / 70.) ** 2)
    return epsilon * f * (np.linalg.norm(u, axis=1) / np.linalg.norm(f, axis=1))[:, None]


def phase_align(u, ref, k, bound=20.):
    """One common displacement fitted to A, then applied to both components."""
    uh = np.fft.fft(u, axis=-1)
    rh = np.fft.fft(ref, axis=-1)
    # Difference form avoids catastrophic cancellation near a perfect match.
    objective = lambda shift: float(np.sum(np.abs(uh[0] - rh[0] * np.exp(-1j * k * shift)) ** 2))
    optimum = minimize_scalar(objective, bounds=(-bound, bound), method="bounded", options={"xatol": 1e-10})
    shift = float(optimum.x) if objective(optimum.x) < objective(0.) else 0.
    aligned_ref = np.fft.ifft(rh * np.exp(-1j * k * shift), axis=-1).real
    return shift, aligned_ref


def run_case(name, nx=4096, length=8192., dt=5., duration=20000., sample=100., kind="none", epsilon=0.):
    OUT.mkdir(exist_ok=True)
    started = time.perf_counter()
    x = (np.arange(nx) - nx // 2) * length / nx
    ref, raw_u = reference_profile(x)
    co = ref["coefficients"]
    integrator = FourierETDRK4(co["C"], co["D"], co["G"], length, nx, dt, ref["speed"])
    base = np.fft.ifft(integrator.project(raw_u), axis=-1).real
    delta = initial_perturbation(x, base, kind, epsilon)
    initial = np.fft.ifft(integrator.project(base + delta), axis=-1).real
    h = integrator.project(initial)
    steps = int(round(duration / dt))
    stride = int(round(sample / dt))
    assert abs(steps * dt - duration) < 1e-9 and abs(stride * dt - sample) < 1e-9 and steps % stride == 0
    times, profiles, shifts, raw_errors, shape_errors, means, peaks = [], [], [], [], [], [], []
    norm = np.linalg.norm(base, axis=1)
    for j in range(steps + 1):
        if j % stride == 0:
            u = np.fft.ifft(h, axis=-1).real
            if not np.all(np.isfinite(u)):
                raise RuntimeError((name, "nonfinite state", j * dt))
            shift, moved = phase_align(u, base, integrator.k)
            times.append(j * dt)
            profiles.append(u)
            shifts.append(shift)
            raw_errors.append(np.linalg.norm(u - base, axis=1) / norm)
            shape_errors.append(np.linalg.norm(u - moved, axis=1) / norm)
            means.append(np.mean(u, axis=1))
            peaks.append(np.min(u, axis=1))
        if j < steps:
            h = integrator.step(h)
    arrays = dict(time=np.array(times), x=x, profiles=np.array(profiles), reference=base,
                  initial=initial, phase_shift=np.array(shifts), relative_error=np.array(raw_errors),
                  aligned_relative_error=np.array(shape_errors), means=np.array(means), minima=np.array(peaks))
    np.savez_compressed(OUT / (name + ".npz"), **arrays)
    meta = dict(name=name, model="corrected fixed-basis long-wave closure", frame_speed=ref["speed"],
                settings=dict(nx=nx, length=length, dt=dt, duration=duration, sample=sample, kind=kind, epsilon=epsilon),
                reference_settings=ref["settings"], coefficients=co,
                initial_relative_perturbation=(np.linalg.norm(initial - base, axis=1) / norm).tolist(),
                initial_projection_relative_error=(np.linalg.norm(base - raw_u, axis=1) / norm).tolist(),
                max_relative_error=np.max(arrays["relative_error"], axis=0).tolist(),
                final_relative_error=arrays["relative_error"][-1].tolist(),
                max_aligned_relative_error=np.max(arrays["aligned_relative_error"], axis=0).tolist(),
                final_aligned_relative_error=arrays["aligned_relative_error"][-1].tolist(),
                final_phase_shift=shifts[-1], max_absolute_phase_shift=float(np.max(np.abs(shifts))),
                nonlinear_reference_time=1/(abs(co["G"][0][0][0] * ref["center_A"]) * ref["kappa_seed"]),
                source_sha256={p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in
                               ("wave_propagation.py", "traveling_wave_results/reference.json", "traveling_wave_results/reference.npz")},
                runtime_seconds=time.perf_counter() - started)
    (OUT / (name + ".json")).write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(json.dumps({k: meta[k] for k in ("name", "max_relative_error", "max_aligned_relative_error", "final_phase_shift", "runtime_seconds")}), flush=True)
    return meta


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", default="pilot")
    parser.add_argument("--duration", type=float, default=1000.)
    parser.add_argument("--dt", type=float, default=5.)
    args = parser.parse_args()
    run_case(args.name, duration=args.duration, dt=args.dt)
