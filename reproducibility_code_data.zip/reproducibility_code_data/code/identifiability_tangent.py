"""Discrete ETDRK4 tangent propagation for physical inverse observations.

Only the small parameter-dependent coefficient/matrix construction is centrally
differenced. The ETDRK4 stages are differentiated explicitly, including ordered
quadratic terms, initial-template nuisance parameters and reconstruction modes.
"""
import json
from pathlib import Path
import time

import numpy as np

from direct_identifiability import (SCALES, X_SENSORS, smooth_coefficients,
                                   initial_profile, central_jacobian, forward)
from wave_propagation import FourierETDRK4

ROOT = Path(__file__).resolve().parent
MATRIX_KEYS = ("E", "E2", "Q", "f1", "f2", "f3")


def forward_jacobian(p, nx=512, dt=5., N=24, Ny=1025):
    """Return observations (2,41,3,65) and Jacobian (obs.size,len(p))."""
    p = np.asarray(p, dtype=float)
    if p.ndim != 1 or len(p) not in (3, 7):
        raise ValueError("Expected three physical or seven physical/initial parameters.")
    count = len(p)
    theta = p[:3]
    nuisance = p[3:] if count == 7 else np.zeros(4)
    co = smooth_coefficients(theta, N=N, Ny=Ny)
    length = 1024.
    solver = FourierETDRK4(co["C"], co["D"], co["G"], length, nx, dt, frame_speed=0.)
    derivatives = {key: np.zeros((count, nx, 2, 2), dtype=complex) for key in MATRIX_KEYS}
    dG = np.zeros((count, 2, 2, 2))
    dlayer = np.zeros((count, *co["layer"].shape))
    for j in range(3):
        offset = np.zeros(3)
        offset[j] = 1e-4*SCALES[j]
        cp = smooth_coefficients(theta+offset, N=N, Ny=Ny)
        cm = smooth_coefficients(theta-offset, N=N, Ny=Ny)
        sp = FourierETDRK4(cp["C"], cp["D"], cp["G"], length, nx, dt, frame_speed=0.)
        sm = FourierETDRK4(cm["C"], cm["D"], cm["G"], length, nx, dt, frame_speed=0.)
        for key in MATRIX_KEYS:
            derivatives[key][j] = (getattr(sp, key)-getattr(sm, key))/(2*offset[j])
        dG[j] = (cp["G"]-cm["G"])/(2*offset[j])
        dlayer[j] = (cp["layer"]-cm["layer"])/(2*offset[j])

    h = solver.project(initial_profile(solver.x, nuisance))
    dh = np.zeros((count, 2, nx), dtype=complex)
    if count == 7:
        for j in range(4):
            offset = np.zeros(4)
            offset[j] = 1e-5
            du = (initial_profile(solver.x, nuisance+offset)
                  - initial_profile(solver.x, nuisance-offset))/(2*offset[j])
            dh[3+j] = solver.project(du)

    def multiply(key, value):
        return np.einsum("kij,jk->ik", getattr(solver, key), value)

    def tangent_multiply(key, value, tangent):
        return (np.einsum("kij,pjk->pik", getattr(solver, key), tangent)
                + np.einsum("pkij,jk->pik", derivatives[key], value))

    def nonlinear(value, tangent):
        value = value*solver.mask
        tangent = tangent*solver.mask
        u = np.fft.ifft(value, axis=-1).real
        ux = np.fft.ifft(value*(1j*solver.k), axis=-1).real
        du = np.fft.ifft(tangent, axis=-1).real
        dux = np.fft.ifft(tangent*(1j*solver.k), axis=-1).real
        nl = np.einsum("irs,rx,sx->ix", co["G"], u, ux)
        dnl = (np.einsum("irs,prx,sx->pix", co["G"], du, ux)
               + np.einsum("irs,rx,psx->pix", co["G"], u, dux)
               + np.einsum("pirs,rx,sx->pix", dG, u, ux))
        return (-np.fft.fft(nl, axis=-1)*solver.mask,
                -np.fft.fft(dnl, axis=-1)*solver.mask)

    indices = (X_SENSORS+length/2)/(length/nx)
    exact_nodes = np.max(abs(indices-np.round(indices))) < 1e-12
    if exact_nodes:
        take = np.round(indices).astype(int)
    else:
        interpolation = np.exp(1j*solver.k[:, None]*(X_SENSORS[None]+length/2))/nx
    stride = int(round(25./dt))
    steps = int(round(1000./dt))
    if stride <= 0 or abs(stride*dt-25.) > 1e-10 or abs(steps*dt-1000.) > 1e-10:
        raise ValueError("dt must resolve the prescribed output grid exactly.")
    snapshots, tangent_snapshots = [], []
    for step in range(steps+1):
        if step % stride == 0:
            if exact_nodes:
                snapshots.append(np.fft.ifft(h, axis=-1).real[:, take])
                tangent_snapshots.append(np.fft.ifft(dh, axis=-1).real[:, :, take])
            else:
                snapshots.append(np.real(h@interpolation))
                tangent_snapshots.append(np.real(np.einsum("pjk,kx->pjx", dh, interpolation)))
        if step == steps:
            break
        n0, dn0 = nonlinear(h, dh)
        a = multiply("E2", h)+multiply("Q", n0)
        da = tangent_multiply("E2", h, dh)+tangent_multiply("Q", n0, dn0)
        na, dna = nonlinear(a, da)
        b = multiply("E2", h)+multiply("Q", na)
        db = tangent_multiply("E2", h, dh)+tangent_multiply("Q", na, dna)
        nb, dnb = nonlinear(b, db)
        c = multiply("E2", a)+multiply("Q", 2*nb-n0)
        dc = tangent_multiply("E2", a, da)+tangent_multiply("Q", 2*nb-n0, 2*dnb-dn0)
        nc, dnc = nonlinear(c, dc)
        updated = (multiply("E", h)+multiply("f1", n0)
                   + 2*multiply("f2", na+nb)+multiply("f3", nc))
        dupdated = (tangent_multiply("E", h, dh)+tangent_multiply("f1", n0, dn0)
                    + 2*tangent_multiply("f2", na+nb, dna+dnb)
                    + tangent_multiply("f3", nc, dnc))
        h = np.fft.fft(np.fft.ifft(updated, axis=-1).real, axis=-1)*solver.mask
        dh = np.fft.fft(np.fft.ifft(dupdated, axis=-1).real, axis=-1)*solver.mask
    modal = np.array(snapshots)
    dmodal = np.array(tangent_snapshots)
    observations = np.einsum("ljy,tjx->ltyx", co["layer"], modal)
    jacobian = (np.einsum("ljy,tpjx->pltyx", co["layer"], dmodal)
                + np.einsum("pljy,tjx->pltyx", dlayer, modal))
    jacobian = jacobian.reshape(count, -1).T
    if not np.all(np.isfinite(observations)) or not np.all(np.isfinite(jacobian)):
        raise ValueError("Nonfinite tangent forward result.")
    return observations, jacobian


def main():
    records = []
    points = [np.array([.5, .5, .2, 0., 0., 0., 0.]),
              np.array([.55, .45, .15, .02, -.1, .05, .02])]
    scale = np.r_[SCALES, np.ones(4)]
    for p in points:
        start = time.perf_counter()
        obs, tangent = forward_jacobian(p)
        tangent_time = time.perf_counter()-start
        start = time.perf_counter()
        finite = central_jacobian(p, step=1e-4)
        finite_time = time.perf_counter()-start
        direct = forward(p)
        difference = (tangent-finite)*scale
        record = dict(parameters=p.tolist(),
            forward_relative_difference=float(np.linalg.norm(obs-direct)/np.linalg.norm(direct)),
            scaled_Jacobian_relative_Frobenius=float(np.linalg.norm(difference)/np.linalg.norm(finite*scale)),
            column_relative_L2=(np.linalg.norm(tangent-finite, axis=0)/np.linalg.norm(finite, axis=0)).tolist(),
            tangent_seconds=tangent_time, finite_difference_seconds=finite_time)
        records.append(record)
        print(json.dumps(record), flush=True)
    result = dict(scope="Discrete tangent chain-rule check against full-forward central differences.",
        coefficient_difference_step="1e-4*[.5,.5,.2]", initial_nuisance_difference_step=1e-5,
        comparisons=records)
    target = ROOT/"identifiability_results/tangent_audit.json"
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(result, indent=2), encoding="utf-8")
    if max(r["scaled_Jacobian_relative_Frobenius"] for r in records) >= 1e-5:
        raise RuntimeError("Tangent Jacobian comparison exceeds requested tolerance.")


if __name__ == "__main__":
    main()
