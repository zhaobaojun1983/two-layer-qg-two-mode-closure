"""Continuous reference branches for the bounded inverse experiment.

In the audited parameter box, the baseline modes continue as the two lowest
real phase speeds. Their BT/BC amplitude ratios may cross unity; that change
of modal character must not switch the eigenbranch used by the inverse map.
The original coefficient generator is retained for previous experiments.
"""
import numpy as np
from _coeffs_strict import build, _eigensystem, U, L, ordered_kernel, project


def inverse_coefficients(F, s, lam, N=24, M=1025):
    y, Sm, A, B = build(F, s, lam, 0., N=N, M=M)
    values, vectors = _eigensystem(A, B)
    order = np.argsort(values)
    selected = order[:2]
    if values[order[2]]-values[order[1]] < 1e-5:
        raise ValueError("Selected inverse branches are not separated from the remaining spectrum.")
    left_values, left_vectors = _eigensystem(A.T, B.T)
    kn = np.arange(1,N+1)[:,None]*np.pi/(2*L)
    cm = np.cos(kn*(y+L))
    bases = [Sm,kn*cm,-kn**2*Sm,-kn**3*cm]
    phi, adjoint, fields, left_fields = [],[],[],[]
    for mode, index in enumerate(selected):
        v = vectors[:,index].copy()
        component = Sm.T@v[mode*N:(mode+1)*N]
        v /= component[np.argmax(abs(component))]
        a = left_vectors[:,np.argmin(abs(left_values-values[index]))].copy()
        a /= a@(B@v)
        phi.append(v)
        adjoint.append(a)
        fields.append([[part@basis for basis in bases] for part in (v[:N],v[N:])])
        left_fields.append([Sm.T@a[:N]/L,Sm.T@a[N:]/L])
    basis = dict(y=y,Sm=Sm,A0=A,B0=B,c=values[selected],phi=np.array(phi),adjoint=np.array(adjoint),
                 fields=np.array(fields),left_fields=np.array(left_fields))
    field = basis["fields"]
    mass = np.column_stack([project(basis,field[j,:,0]) for j in range(2)])
    uv = U(y,lam)
    E = np.column_stack([project(basis,np.array([uv*(v[0]+s*v[1]),uv*(s*v[0]+v[1])])) for v in field[:,:,0]])
    C = np.diag(basis["c"])
    G = np.empty((2,2,2))
    for p in range(2):
        for q in range(2):
            G[:,p,q] = project(basis,ordered_kernel(field[p],field[q],F))
    return dict(F=F,s=s,lam=lam,basis=basis,C=C,D=E-mass@C,M=mass,E=E,G=G,
                second_to_remaining_gap=float(values[order[2]]-values[order[1]]))
