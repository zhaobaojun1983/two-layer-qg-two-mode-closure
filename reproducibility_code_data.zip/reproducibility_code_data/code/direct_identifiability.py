"""Direct least-squares inversion with parameter-dependent physical observations.

Conditional identical-twin experiments of the corrected long-wave closure.
The initial modal template is known, or four of its parameters are unknown.
No modal amplitude is identified with a layer measurement.
"""
import hashlib
import json
from functools import lru_cache
from pathlib import Path
import sys
import time
import numpy as np
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / ".local_python"))
from scipy.interpolate import BPoly
from scipy.optimize import least_squares
from two_mode_closure import closure_coefficients
from inverse_modal_branch import inverse_coefficients
from wave_propagation import FourierETDRK4

OUT = ROOT / "identifiability_results"
THETA = np.array([.5, .5, .2])
SCALES = np.array([.5, .5, .2])
LOWER = np.array([.25, .30, -.35, -.5, -2., -1., -.3])
UPPER = np.array([.90, .70, .35, .5, 2., 1., .3])
X_SCALE = np.array([.5, .5, .2, .2, 1., .5, .2])
Y_SENSORS = np.array([-.5, 0., .5])
TIMES = np.arange(0., 1000.1, 25.)
X_SENSORS = np.arange(-320., 64.1, 6.)


@lru_cache(maxsize=1)
def reference():
    co = closure_coefficients(*THETA, N=64, M=4097)
    with np.load(ROOT / "traveling_wave_results/reference.npz") as data:
        mesh, states = data["mesh"], data["scaled_states"]
    wave = json.loads((ROOT / "traveling_wave_results/reference.json").read_text())
    interp = BPoly.from_derivatives(mesh, [np.array([states[:2, j], states[2:4, j], states[4:6, j]]) for j in range(len(mesh))])
    return co, wave, interp, mesh[-1]


def smooth_coefficients(theta, N=24, Ny=1025):
    co = inverse_coefficients(*theta, N=N, M=Ny)
    ref, _, _, _ = reference()
    raw = co["basis"]["phi"].reshape(2, 2, N)
    padded = np.pad(raw, ((0, 0), (0, 0), (0, 64-N))).reshape(2, 128)
    refphi = ref["basis"]["phi"]
    overlaps = refphi @ padded.T / (np.linalg.norm(refphi, axis=1)[:, None] * np.linalg.norm(padded, axis=1)[None, :])
    # Labels follow the spectrally separated, path-verified lowest two roots.
    # A distant reference correlation is diagnostic, not a reordering rule.
    permutation = [0, 1]
    padded = padded[permutation]
    diagonal_overlap = overlaps[np.arange(2), permutation]
    ref_extract = ref["basis"]["adjoint"] @ ref["basis"]["B0"]
    gauge = np.diag(ref_extract @ padded.T)
    if np.min(np.abs(gauge)) < .2:
        raise ValueError("Reference normalization degeneracy.")
    scale = 1. / gauge
    idx = np.array(permutation)
    matrices = {key: co[key][np.ix_(idx, idx)] * scale[None, :] / scale[:, None] for key in ("C", "D", "M", "E")}
    G = co["G"][np.ix_(idx, idx, idx)] * scale[None, :, None] * scale[None, None, :] / scale[:, None, None]
    phi = co["basis"]["phi"][idx].reshape(2, 2, N) * scale[:, None, None]
    sine = np.sin(np.arange(1, N+1)[:, None] * np.pi * (Y_SENSORS[None, :] + 1) / 2)
    vertical = np.einsum("jcn,ny->jcy", phi, sine)
    layer = np.stack((vertical[:, 0] + vertical[:, 1], vertical[:, 0] - vertical[:, 1]))
    return dict(**matrices, G=G, phi=phi, layer=layer, overlap=diagonal_overlap,
                speed_gap=float(abs(matrices["C"][0, 0]-matrices["C"][1, 1])), raw=co, gauge_scale=scale)


def initial_profile(x, nuisance=None):
    _, wave, interp, extent = reference()
    q = np.zeros(4) if nuisance is None else np.asarray(nuisance)
    coordinate = (x - 25.*q[2]) / np.exp(q[3])
    z = abs(coordinate) * wave["kappa_seed"]
    u = np.zeros((2, len(x)))
    inside = z <= extent
    u[:, inside] = wave["amplitude_scale"] * interp(z[inside]).T
    return u * np.exp(q[:2, None])


def forward(parameters, nx=512, dt=5., N=24, Ny=1025):
    parameters = np.asarray(parameters)
    theta = parameters[:3]
    q = parameters[3:] if len(parameters) == 7 else np.zeros(4)
    co = smooth_coefficients(theta, N=N, Ny=Ny)
    length = 1024.
    solver = FourierETDRK4(co["C"], co["D"], co["G"], length, nx, dt, frame_speed=0.)
    h = solver.project(initial_profile(solver.x, q))
    # The observation grid is independent of parameters and coincides with
    # forward nodes for nx=512,1024. Use Fourier interpolation otherwise.
    indices = (X_SENSORS + length/2) / (length/nx)
    exact_nodes = np.max(abs(indices - np.round(indices))) < 1e-12
    sample = int(round(25. / dt))
    assert abs(sample*dt-25.) < 1e-10
    snapshots = []
    for j in range(int(round(1000./dt))+1):
        if j % sample == 0:
            if exact_nodes:
                amplitudes = np.fft.ifft(h, axis=-1).real[:, np.round(indices).astype(int)]
            else:
                amplitudes = np.real(h @ np.exp(1j*solver.k[:, None]*(X_SENSORS[None, :]+length/2))) / nx
            snapshots.append(amplitudes)
        if j < int(round(1000./dt)):
            h = solver.step(h)
    modal = np.array(snapshots)
    observations = np.einsum("ljy,tjx->ltyx", co["layer"], modal)
    if not np.all(np.isfinite(observations)):
        raise ValueError("Nonfinite forward field.")
    return observations


def observation_indices(configuration="surface", spatial=33, temporal=21, window=1000., omit_initial=False):
    xi = np.round(np.linspace(0, len(X_SENSORS)-1, spatial)).astype(int)
    ti = np.round(np.linspace(0, int(round(window/25.)), temporal)).astype(int)
    if len(set(ti)) != len(ti):
        raise ValueError("Duplicate time samples.")
    if omit_initial:
        ti = ti[ti > 0]
    grid = np.arange(2*len(TIMES)*3*len(X_SENSORS)).reshape(2, len(TIMES), 3, len(X_SENSORS))
    if configuration in ("surface", "surface_deep"):
        indices = grid[0][np.ix_(ti, [1], xi)].ravel()
    elif configuration == "surface_multiy":
        # Same 693 upper-layer samples as default: 11 x positions x 3 y x 21 t.
        xi_equal = np.round(np.linspace(0, len(X_SENSORS)-1, 11)).astype(int)
        indices = grid[0][np.ix_(ti, [0, 1, 2], xi_equal)].ravel()
    else:
        raise ValueError(configuration)
    if configuration == "surface_deep":
        deep_t = np.arange(0, int(round(window/25.))+1, 8)
        if omit_initial:
            deep_t = deep_t[deep_t > 0]
        deep_x = np.round(np.linspace(0, len(X_SENSORS)-1, 9)).astype(int)
        indices = np.r_[indices, grid[1][np.ix_(deep_t, [1], deep_x)].ravel()]
    return indices.astype(int)


@lru_cache(maxsize=1)
def truth():
    return forward(tuple(THETA))


def dataset(configuration="surface", noise=.01, seed=101, **sampling):
    indices = observation_indices(configuration, **sampling)
    values = truth().ravel()
    # Same fixed instrument noise in both layers; independent of trial theta.
    sigma = noise * float(np.max(np.abs(truth()[0])))
    rng = np.random.default_rng(seed)
    full_noise = rng.normal(size=values.shape)
    measured = values[indices] + sigma * full_noise[indices]
    return dict(indices=indices, values=measured, sigma=sigma, noise=noise, seed=seed,
                configuration=configuration, sampling=sampling)


class Objective:
    def __init__(self, data, unknown_initial=False, fixed=None):
        self.data = data
        self.unknown_initial = unknown_initial
        self.fixed = {} if fixed is None else fixed
        self.full_size = 7 if unknown_initial else 3
        self.free = np.array([j for j in range(self.full_size) if j not in self.fixed])
        self.calls = 0
        self.last_parameters = None

    def expand(self, p):
        full = np.zeros(self.full_size)
        full[self.free] = p
        for j, value in self.fixed.items():
            full[j] = value
        return full

    def evaluate(self, p):
        if self.last_parameters is not None and np.array_equal(p, self.last_parameters):
            return
        from identifiability_tangent import forward_jacobian
        self.calls += 1
        prediction, jacobian = forward_jacobian(self.expand(p))
        indices = self.data["indices"]
        self.last_residual = (prediction.ravel()[indices]-self.data["values"]) / self.data["sigma"]
        self.last_jacobian = jacobian[indices][:, self.free] / self.data["sigma"]
        self.last_parameters = np.array(p, copy=True)

    def __call__(self, p):
        self.evaluate(p)
        return self.last_residual

    def jacobian(self, p):
        self.evaluate(p)
        return self.last_jacobian


def fit(data, start, unknown_initial=False, fixed=None, max_nfev=70):
    objective = Objective(data, unknown_initial, fixed)
    start = np.array(start, dtype=float)
    if unknown_initial and len(start) == 3:
        start = np.r_[start, np.zeros(4)]
    free = objective.free
    started = time.perf_counter()
    result = least_squares(objective, start[free], bounds=(LOWER[free], UPPER[free]),
                           x_scale=X_SCALE[free], jac=objective.jacobian,
                           ftol=2e-8, xtol=2e-8, gtol=1e-6, max_nfev=max_nfev)
    p = objective.expand(result.x)
    return dict(parameters=p.tolist(), start=start.tolist(), unknown_initial=unknown_initial,
                success=bool(result.success), message=result.message, nfev=int(result.nfev), calls=objective.calls,
                chi_square=float(2*result.cost), reduced_chi_square=float(2*result.cost/(len(data["values"])-len(free))),
                scaled_parameter_error=((p[:3]-THETA)/SCALES).tolist(),
                parameter_absolute_error=(p[:3]-THETA).tolist(), optimality=float(result.optimality),
                at_bound=(np.minimum(p-LOWER[:len(p)], UPPER[:len(p)]-p)<1e-4).tolist(),
                runtime_seconds=time.perf_counter()-started)


def central_jacobian(p, step=2e-4, **resolution):
    p = np.asarray(p, dtype=float)
    scale = np.r_[SCALES, np.ones(4)][:len(p)]
    columns = []
    for j in range(len(p)):
        offset = np.zeros_like(p)
        offset[j] = step*scale[j]
        columns.append((forward(p+offset, **resolution).ravel()-forward(p-offset, **resolution).ravel())/(2*offset[j]))
    return np.column_stack(columns)


def information(jacobian, data, unknown_initial=False):
    J = jacobian[data["indices"]] / data["sigma"]
    Jtheta = J[:, :3] * SCALES
    if unknown_initial:
        Jq = J[:, 3:]
        u, s, _ = np.linalg.svd(Jq, full_matrices=False)
        rank = int(np.sum(s > s[0]*1e-10))
        effective = Jtheta-u[:, :rank]@(u[:, :rank].T@Jtheta)
    else:
        rank = 0
        effective = Jtheta
    _, singular, vh = np.linalg.svd(effective, full_matrices=False)
    cutoff = np.linalg.norm(Jtheta, 2) * 1e-7
    numerical_rank = int(np.sum(singular > cutoff))
    covariance = (vh.T / singular**2) @ vh if numerical_rank == 3 else None
    sd = np.sqrt(np.diag(covariance)) if numerical_rank == 3 else None
    return dict(singular_values=singular.tolist(), condition=float(singular[0]/singular[-1]),
                weakest_scaled_direction=vh[-1].tolist(), scaled_local_standard_error=sd.tolist() if numerical_rank == 3 else None,
                local_standard_error=(sd*SCALES).tolist() if numerical_rank == 3 else None,
                correlation=(covariance/np.outer(sd, sd)).tolist() if numerical_rank == 3 else None,
                numerical_rank=numerical_rank, rank_absolute_cutoff=float(cutoff), nuisance_rank=rank,
                observation_count=len(data["indices"]))


if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    start = time.perf_counter()
    value = truth()
    print("forward", time.perf_counter()-start, "shape", value.shape, "peaks", np.max(abs(value), axis=(1,2,3)), flush=True)
    start = time.perf_counter()
    forward([.55, .45, .15])
    print("cached-reference forward", time.perf_counter()-start, flush=True)
    data = dataset()
    print(json.dumps(fit(data, [.55, .45, .15])), flush=True)
