"""Four-panel wave structure: saved BVP amplitudes and consistent layer fields."""
from figure_common import *
from two_mode_closure import closure_coefficients


def main():
    stem = 'fig3_wave_structure'
    meta_path = ROOT / 'traveling_wave_results/reference.json'
    data_path = ROOT / 'traveling_wave_results/reference.npz'
    meta = read_json(meta_path)
    with np.load(data_path, allow_pickle=False) as saved:
        xi, states = saved['zeta'].copy(), saved['profile'].copy()
    assert states.shape == (6, len(xi)) and meta['success']
    settings = meta['settings']
    assert settings['F'] == settings['s'] == .5 and settings['lam'] == .2
    # Reconstruct the exact reference linear basis; no BVP or time integration.
    co = closure_coefficients(F=settings['F'], s=settings['s'], lam=settings['lam'],
                              N=settings['N'], M=settings['Ny'])
    errors = {}
    for key in ['C', 'D', 'G']:
        expected = np.asarray(meta['coefficients'][key])
        errors[key] = float(np.max(np.abs(co[key] - expected)))
        assert np.allclose(co[key], expected, rtol=1e-10, atol=2e-12), key
    zeta = EPS * xi
    P, Q = states[:2] / EPS**2
    center = int(np.argmin(abs(zeta)))
    assert np.isclose(P[center], -1, rtol=1e-12)
    assert np.isclose(Q[center] * EPS**2, meta['center_B'], rtol=1e-12)
    ratio = abs(Q[center] / P[center])
    core_limit = 12.
    core = abs(zeta) <= core_limit
    z_grid = np.linspace(-core_limit, core_limit, 481)
    y = np.linspace(-1, 1, 201)
    n = np.arange(1, settings['N'] + 1)
    sine = np.sin((y[:, None] + 1) * n * np.pi / 2)
    modal_sine = co['basis']['phi'].reshape(2, 2, settings['N'])
    fields = np.einsum('icn,yn->icy', modal_sine, sine)
    a = np.array([np.interp(z_grid, zeta, row) for row in states[:2]])
    psi_tau = np.einsum('icy,iz->cyz', fields, a)
    upper, lower = psi_tau[0] + psi_tau[1], psi_tau[0] - psi_tau[1]
    # Physical fields use original amplitudes: no epsilon^-2 magnification.
    slow_reconstruction = EPS**2 * np.einsum(
        'icy,iz->cyz', fields,
        np.array([np.interp(z_grid, zeta, P), np.interp(z_grid, zeta, Q)]))
    coord_error = float(np.max(abs(psi_tau - slow_reconstruction)))
    assert coord_error < 1e-15
    assert np.max(abs(upper[[0, -1]])) < 1e-14
    assert np.max(abs(lower[[0, -1]])) < 1e-14

    fig = plt.figure(figsize=(183 / 25.4, 151 / 25.4))
    gs = fig.add_gridspec(2, 2, left=.11, right=.87, bottom=.105, top=.92,
                          wspace=.39, hspace=.64, height_ratios=[1, 1.05])
    axa, axb, axc, axd = [fig.add_subplot(gs[r, c]) for r, c in [(0,0),(0,1),(1,0),(1,1)]]
    panel(axa, 'a', 'Primary modal profile')
    panel(axb, 'b', 'Companion modal profile')
    for ax in [axa, axb]:
        ax.axhline(0, lw=.65, color='#B7B7B7')
        ax.set(xlim=(-core_limit, core_limit), xticks=[-10,-5,0,5,10],
               xlabel=r'Traveling coordinate $\zeta$')
    axa.plot(zeta[core], P[core], color=COLORS['primary'], lw=1.65)
    axa.set(ylabel=r'$P(\zeta)$', ylim=(-1.12, .06))
    axa.text(.04, .05, r'$P(0)=-1$', transform=axa.transAxes, fontsize=7.5)
    axb.plot(zeta[core], 1000 * Q[core], color=COLORS['companion'], lw=1.65)
    axb.set(ylabel=r'$10^3 Q(\zeta)$', ylim=(-1.20, .07))
    axb.text(.04, .05, r'$|Q(0)/P(0)|=1.074\times10^{-3}$',
             transform=axb.transAxes, fontsize=7)
    panel(axc, 'c', 'Upper-layer streamfunction')
    panel(axd, 'd', 'Lower-layer streamfunction')
    limit = float(np.max(abs(np.array([upper, lower]))) * 100)
    # One symmetric scale preserves the relative amplitudes of both layers.
    for ax, field in [(axc, upper), (axd, lower)]:
        im = ax.pcolormesh(z_grid, y, 100 * field, shading='nearest',
                           cmap='RdBu_r', vmin=-limit, vmax=limit, rasterized=True)
        ax.contour(z_grid, y, 100 * field, levels=[-.8*limit,-.4*limit],
                   colors='#2C4155', linewidths=.45, alpha=.65)
        ax.set(xlabel=r'Traveling coordinate $\zeta$', ylabel=r'$y$',
               xlim=(-core_limit, core_limit), ylim=(-1, 1),
               xticks=[-10,-5,0,5,10], yticks=[-1,-.5,0,.5,1])
        ax.spines['top'].set_visible(True)
        ax.spines['right'].set_visible(True)
    box = axd.get_position()
    cax = fig.add_axes([.90, box.y0, .018, box.height])
    bar = fig.colorbar(im, cax=cax)
    bar.set_label(r'$10^2\psi^\prime_{\ell,r}$', labelpad=4)
    bar.ax.tick_params(labelsize=7, length=2)

    source = dict(xi=xi, zeta=zeta, P=P, Q=Q, display_zeta=z_grid, y=y,
                  psi_upper=upper, psi_lower=lower, mode_fields=fields,
                  mode_sine_coefficients=modal_sine, phase_speeds=np.diag(co['C']))
    np.savetxt(HERE / (stem + '_profiles.csv'), np.column_stack([xi,zeta,P,Q]),
               delimiter=',', header='xi_original,zeta_slow,P_slow,Q_slow', comments='')
    np.savetxt(HERE / (stem + '_mode_fields.csv'),
               np.column_stack([y,fields[0,0],fields[0,1],fields[1,0],fields[1,1]]),
               delimiter=',', header='y,psi_B,tau_B,psi_C,tau_C', comments='')
    audit = dict(figure=3, inputs_sha256={str(p.relative_to(ROOT)):sha(p) for p in
                  [meta_path,data_path,ROOT/'two_mode_closure.py',ROOT/'_coeffs_strict.py']},
                 epsilon=EPS, baseline=settings, recomputation='Reference linear modes and coefficients only; no new BVP or evolution.',
                 reference_coefficient_max_absolute_differences=errors,
                 center_P=float(P[center]), center_Q=float(Q[center]), companion_primary_ratio=ratio,
                 field_coordinate_conversion_max_error=coord_error,
                 physical_upper_peak=float(np.max(abs(upper))),
                 physical_lower_peak=float(np.max(abs(lower))),
                 display_crop_slow=[-core_limit,core_limit],
                 full_computed_domain_slow=zeta[[0,-1]].tolist(),
                 physical_field_color_range_scaled=[-limit,limit],
                 field_normalization='Original physical perturbation fields; common color scale multiplied by 100.',
                 field_interpolation='Linear interpolation of saved dense BVP profiles onto display zeta grid; exact sine reconstruction in y.')
    save_bundle(fig, stem, source, audit)


if __name__ == '__main__':
    main()
