"""Shared Python style and reproducible exports for the four result figures."""
from pathlib import Path
import hashlib
import json
import os
import sys

HERE = Path(__file__).resolve().parent
BRANCH = HERE.parent
ROOT = BRANCH.parent
sys.path.insert(0, str(ROOT / '.local_python'))
sys.path.insert(0, str(ROOT))
os.environ.setdefault('MPLCONFIGDIR', str(HERE / '_mplconfig'))
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt

EPS = 0.1
COLORS = dict(primary='#286C9C', companion='#BB6538', parent='#333333',
              full='#428B80', longwave='#BB6538', S='#286C9C',
              SD='#428B80', MY='#9A6F9D')
mpl.rcParams.update({
    'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'],
    'font.size': 8, 'axes.labelsize': 8, 'axes.titlesize': 8.5,
    'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.linewidth': .7, 'xtick.major.width': .65, 'ytick.major.width': .65,
    'xtick.major.size': 3, 'ytick.major.size': 3,
    'legend.frameon': False, 'lines.linewidth': 1.3,
    'pdf.fonttype': 42, 'svg.fonttype': 'none',
    'savefig.facecolor': 'white', 'figure.facecolor': 'white',
    'mathtext.fontset': 'dejavusans',
})

def panel(ax, letter, title):
    ax.set_title(title, loc='left', pad=9)
    ax.text(-.17, 1.055, letter, transform=ax.transAxes,
            ha='left', va='bottom', fontsize=10, fontweight='bold')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save_bundle(fig, stem, data, audit):
    """Keep the specified canvas dimensions; write editable and raster copies."""
    fig.canvas.draw()
    # Catch labels extending beyond the export canvas without altering layout.
    renderer = fig.canvas.get_renderer()
    outside = []
    for artist in fig.findobj(mpl.text.Text):
        if not artist.get_visible() or not artist.get_text():
            continue
        bb = artist.get_window_extent(renderer)
        if bb.width == 0 or bb.height == 0:
            continue
        if bb.x0 < -1 or bb.y0 < -1 or bb.x1 > fig.bbox.width + 1 or bb.y1 > fig.bbox.height + 1:
            outside.append(artist.get_text())
    if outside:
        raise ValueError('Text outside figure canvas: ' + repr(outside))
    for ext, kwargs in [('.pdf', {}), ('.svg', {}), ('.png', {'dpi': 300}),
                        ('.tiff', {'dpi': 600, 'pil_kwargs': {'compression': 'tiff_lzw'}})]:
        fig.savefig(HERE / (stem + ext), **kwargs)
    fig.savefig(HERE / (stem + '_preview.png'), dpi=160)
    np.savez_compressed(HERE / (stem + '_source.npz'), **data)
    audit.update({'status': 'passed', 'backend': 'Python/matplotlib',
                  'size_mm': (fig.get_size_inches() * 25.4).tolist(),
                  'text_outside_canvas': outside,
                  'source_arrays': {k: list(np.asarray(v).shape) for k, v in data.items()},
                  'outputs': {ext: sha(HERE / (stem + ext)) for ext in ['.pdf', '.svg', '.png', '.tiff']},
                  'plot_code_sha256': sha(HERE / ('plot_' + stem + '.py')),
                  'common_style_sha256': sha(Path(__file__))})
    (HERE / (stem + '_audit.json')).write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    plt.close(fig)
    print(stem + ': exported PDF, SVG, PNG, TIFF, source arrays and audit', flush=True)
