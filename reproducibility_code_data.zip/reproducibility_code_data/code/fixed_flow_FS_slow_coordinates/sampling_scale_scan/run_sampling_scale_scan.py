"""Finite spatial/temporal sampling scan for known-initial-state F,s information.

The scan takes nested subsets of the saved, audited truth-point discrete tangent
matrix. It does not rerun the forward model, perform noisy fits, or change the
existing inverse experiment. All designs retain the same upper-layer y=0 field,
observation window, truth, initial modal template, and absolute noise scale.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
BRANCH = HERE.parent
DATA = BRANCH / "noisy_fs_results"
INPUT_NPZ = DATA / "local_information.npz"
INPUT_JSON = DATA / "local_information.json"
X = np.arange(-320.0, 64.0 + 0.1, 6.0)
TIMES = np.arange(0.0, 1000.0 + 0.1, 25.0)
SPATIAL_COUNTS = (17, 33, 65)
TEMPORAL_COUNTS = (11, 21, 41)
K_REFERENCES = (0.1, 0.2)
PHASE_SPEEDS = {"mode_1": -0.21104, "mode_2": -0.00837}
PARAMETER_SCALES = np.array([0.5, 0.5])


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def jsonable(value):
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)


def run() -> dict:
    metadata = json.loads(INPUT_JSON.read_text(encoding="utf-8"))
    with np.load(INPUT_NPZ, allow_pickle=False) as source:
        raw_jacobian = source["raw_jacobian_six_columns"].copy()
        sigma = float(source["noise_sigma"])
        baseline_indices = source["S_indices"].copy()

    expected_shape = (2 * len(TIMES) * 3 * len(X), 6)
    if raw_jacobian.shape != expected_shape:
        raise ValueError(f"Expected tangent shape {expected_shape}, got {raw_jacobian.shape}.")
    if metadata["physical_unknowns"] != ["F", "s"] or metadata["truth_FS"] != [0.5, 0.5]:
        raise ValueError("The saved tangent does not match the manuscript's F,s truth-point experiment.")
    if metadata["fixed_inputs"] != {
        "Um": 0.15, "Uj": 0.4, "w": 0.65, "lambda_fixed": 0.2,
        "beta": 1.0, "L": 1.0,
    }:
        raise ValueError("The saved background differs from the fixed-background manuscript setup.")

    # Reproduce the principal S design before scanning alternative resolutions.
    baseline_raw = raw_jacobian[baseline_indices, :2]
    baseline_jacobian = baseline_raw * PARAMETER_SCALES[None, :] / sigma
    baseline_sv = np.linalg.svd(baseline_jacobian, compute_uv=False)
    saved_baseline = next(
        row for row in metadata["configurations"]
        if row["design"] == "S" and row["unknown_initial"] is False
    )
    if not np.allclose(baseline_sv, saved_baseline["singular_values"], rtol=2e-11, atol=1e-12):
        raise ValueError("The saved 33 x 21 baseline information could not be reproduced.")

    rows = []
    for n_x in SPATIAL_COUNTS:
        x_index = np.rint(np.linspace(0, len(X) - 1, n_x)).astype(int)
        x_index = np.unique(x_index)
        if len(x_index) != n_x:
            raise ValueError(f"Spatial subset with {n_x} sites contains duplicates.")
        for n_t in TEMPORAL_COUNTS:
            t_index = np.rint(np.linspace(0, len(TIMES) - 1, n_t)).astype(int)
            t_index = np.unique(t_index)
            if len(t_index) != n_t:
                raise ValueError(f"Temporal subset with {n_t} times contains duplicates.")

            # Flattening order matches (layer, time, latitude, zonal site).
            flat_indices = np.array([
                ((t * 3) + 1) * len(X) + x
                for t in t_index for x in x_index
            ], dtype=int)
            tangent_rows = raw_jacobian[flat_indices, :2]
            J = tangent_rows * PARAMETER_SCALES[None, :] / sigma
            singular_values = np.linalg.svd(J, compute_uv=False)
            rank_cutoff = 1e-7 * singular_values[0]
            numerical_rank = int(np.count_nonzero(singular_values > rank_cutoff))
            condition = float(singular_values[0] / singular_values[-1])
            covariance = np.diag(PARAMETER_SCALES) @ np.linalg.inv(J.T @ J) @ np.diag(PARAMETER_SCALES)
            local_se = np.sqrt(np.diag(covariance))
            corr = float(covariance[0, 1] / np.sqrt(covariance[0, 0] * covariance[1, 1]))
            dx = float((X[-1] - X[0]) / (n_x - 1))
            dt = float((TIMES[-1] - TIMES[0]) / (n_t - 1))

            row = {
                "n_x": n_x,
                "n_t": n_t,
                "n_observations": int(len(flat_indices)),
                "delta_x": dx,
                "delta_t": dt,
                "delta_x_over_lambda_k01": dx / (2 * np.pi / 0.1),
                "delta_x_over_lambda_k02": dx / (2 * np.pi / 0.2),
                "singular_value_max": float(singular_values[0]),
                "singular_value_min": float(singular_values[-1]),
                "condition_number": condition,
                "numerical_rank": numerical_rank,
                "local_se_F": float(local_se[0]),
                "local_se_s": float(local_se[1]),
                "local_correlation_F_s": corr,
                "rank_cutoff": float(rank_cutoff),
            }
            for k in K_REFERENCES:
                wavelength = 2 * np.pi / k
                row[f"lambda_k{k:.1f}"] = wavelength
                for mode, c in PHASE_SPEEDS.items():
                    period = wavelength / abs(c)
                    row[f"period_{mode}_k{k:.1f}"] = period
                    row[f"delta_t_over_period_{mode}_k{k:.1f}"] = dt / period
            rows.append(row)

    csv_path = HERE / "sampling_scale_scan.csv"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    summary = {
        "status": "complete",
        "analysis": "3x3 nested spatial/temporal sampling scan of known-initial-state F,s local information",
        "fixed_setup": {
            "truth_FS": [0.5, 0.5],
            "fixed_background": metadata["fixed_inputs"],
            "measurement": "upper-layer physical streamfunction at y=0",
            "x_interval": [float(X[0]), float(X[-1])],
            "time_interval": [float(TIMES[0]), float(TIMES[-1])],
            "noise_sigma_absolute": sigma,
            "initial_modal_state": "prescribed and fixed",
        },
        "sampling_levels": {
            "spatial_counts": list(SPATIAL_COUNTS),
            "temporal_counts": list(TEMPORAL_COUNTS),
            "delta_x": [24.0, 12.0, 6.0],
            "delta_t": [100.0, 50.0, 25.0],
            "nested_subsets_of_existing_master_grid": True,
        },
        "reference_scales": {
            "wavenumbers": list(K_REFERENCES),
            "wavelength_definition": "lambda=2*pi/k, using the two k values in the parent-QG comparison",
            "phase_speeds_long_wave_limit": PHASE_SPEEDS,
            "period_definition": "T_i=lambda/abs(c_i), a long-wave reference period, not a fitted nonlinear solitary-wave period",
        },
        "metrics": [
            "noise-weighted, parameter-scaled 2-column sensitivity singular values",
            "condition number, numerical rank, physical-unit local standard errors and F-s correlation",
        ],
        "baseline_reproduction": {
            "design": "S (33 spatial sites x 21 times)",
            "singular_values": baseline_sv.tolist(),
            "saved_singular_values": saved_baseline["singular_values"],
            "condition_number": float(baseline_sv[0] / baseline_sv[-1]),
            "local_standard_errors": [float(x) for x in np.sqrt(np.diag(
                np.diag(PARAMETER_SCALES) @ np.linalg.inv(baseline_jacobian.T @ baseline_jacobian)
                @ np.diag(PARAMETER_SCALES)
            ))],
        },
        "scope_and_limits": [
            "This is a local sensitivity scan at the generating truth; no parameter refits or new noise realizations were run.",
            "The same stored discrete ETDRK4 tangent matrix and fixed absolute noise scale are used for every nested subset.",
            "The finite-k wavelength references and k->0 phase-speed periods contextualize the sampling intervals; they do not assign a unique wavelength or period to the localized solitary wave.",
        ],
        "inputs_sha256": {
            str(INPUT_NPZ.relative_to(BRANCH)): sha256(INPUT_NPZ),
            str(INPUT_JSON.relative_to(BRANCH)): sha256(INPUT_JSON),
        },
        "method_source_sha256": {
            str((BRANCH.parent / name).relative_to(BRANCH.parent)): sha256(BRANCH.parent / name)
            for name in ("direct_identifiability.py", "identifiability_tangent.py", "wave_propagation.py")
        },
        "analysis_script_sha256": sha256(Path(__file__).resolve()),
        "results": rows,
    }
    (HERE / "sampling_scale_scan_results.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False, default=jsonable), encoding="utf-8"
    )
    return summary


if __name__ == "__main__":
    result = run()
    print(json.dumps({
        "status": result["status"],
        "baseline_reproduction": result["baseline_reproduction"],
        "results": [
            {k: row[k] for k in (
                "n_x", "n_t", "delta_x", "delta_t", "singular_value_min",
                "condition_number", "local_se_F", "local_se_s", "numerical_rank"
            )}
            for row in result["results"]
        ],
    }, indent=2))
