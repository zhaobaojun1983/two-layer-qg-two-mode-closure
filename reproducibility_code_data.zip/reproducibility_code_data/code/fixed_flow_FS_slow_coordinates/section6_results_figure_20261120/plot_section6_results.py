"""Reproduce Figure 3 from saved inverse fits and truth-point sensitivities.

No model evolution or parameter optimization is performed. Only the 20 independent
noise realizations per layout enter the plotted recovery results. The nine pilot
multistart fits are excluded. Local contours use the saved observation Jacobian,
not the covariance of the plotted estimates.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator, FormatStrFormatter

HERE = Path(__file__).resolve().parent
LABELS = ("S", "P1", "P3")
COLORS = {"S": "#67727C", "P1": "#B87C29", "P3": "#176FA0"}
MARKERS = {"S": "o", "P1": "^", "P3": "D"}
STYLES = {"S": (0, (5, 2.5)), "P1": (0, (1.4, 1.7)), "P3": "-"}
LEVEL = 2.30


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_csv(path, fields, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def read_data(source, out):
    inputs = [source / "datasets.npz", source / "summary.json", source / "local_information.json"]
    summary = json.loads(inputs[1].read_text(encoding="utf-8"))
    saved_info = json.loads(inputs[2].read_text(encoding="utf-8"))
    with np.load(inputs[0], allow_pickle=False) as z:
        truth = z["truth_FS"].copy()
        sigma = float(z["sigma"])
        raw = z["raw_jacobian_FS"].copy()
        indices = {label: z[f"{label}_indices"].copy() for label in LABELS}
    assert np.array_equal(truth, [0.5, 0.5])
    points, covariances, metric_rows, fit_rows, jac_rows, covariance_rows = {}, {}, [], [], [], []
    for label in LABELS:
        rows = []
        for seed in range(2001, 2021):
            path = source / "fits" / f"{label}_seed{seed}_start3.json"
            inputs.append(path)
            record = json.loads(path.read_text(encoding="utf-8"))
            assert record["seed"] == seed and record["label"] == label
            assert record["cohort"] == "fresh_noise" and record["success"]
            assert not any(record["at_bound"])
            p = np.array(record["recovered_FS"])
            assert np.allclose(p, record["parameters"][:2], atol=0, rtol=0)
            rows.append(p)
            relative = 100 * (p - truth) / truth
            fit_rows.append(dict(layout=label, seed=seed, start_index=3,
                                 F_hat=p[0], s_hat=p[1], F_signed_relative_error_percent=relative[0],
                                 s_signed_relative_error_percent=relative[1]))
        p = np.array(rows)
        points[label] = p
        errors = p - truth
        rmse = np.sqrt(np.mean(errors**2, axis=0)) / truth * 100
        assert np.allclose(rmse, summary["fresh_noise_summary"][label]["relative_RMSE_percent_FS"], rtol=1e-12)
        jac = raw[indices[label]] / sigma
        u, singular, vh = np.linalg.svd(jac, full_matrices=False)
        cov = (vh.T / singular**2) @ vh
        covariances[label] = cov
        assert np.allclose(cov, saved_info[label]["covariance_FS"], rtol=1e-11, atol=1e-16)
        sd = np.sqrt(np.diag(cov))
        rho = cov[0, 1] / np.prod(sd)
        residual_s = jac[:, 1] - jac[:, 0] * (jac[:, 0] @ jac[:, 1]) / (jac[:, 0] @ jac[:, 0])
        conditional_information = residual_s @ residual_s
        assert np.isclose(1 / np.sqrt(conditional_information), sd[1], rtol=1e-10)
        for obs, master_index in enumerate(indices[label]):
            jac_rows.append(dict(layout=label, local_observation_index=obs, master_index=int(master_index),
                                 noise_normalized_dh_dF=jac[obs, 0], noise_normalized_dh_ds=jac[obs, 1]))
        covariance_rows.append(dict(layout=label, C_FF=cov[0, 0], C_Fs=cov[0, 1], C_ss=cov[1, 1]))
        metric_rows.append(dict(layout=label, n_replicates=len(p), n_observations=len(jac),
                                F_relative_RMSE_percent=rmse[0], s_relative_RMSE_percent=rmse[1],
                                F_local_standard_error=sd[0], s_local_standard_error=sd[1],
                                local_parameter_correlation=rho,
                                local_information_s_with_F_free=conditional_information,
                                F_mean_bias=errors[:, 0].mean(), s_mean_bias=errors[:, 1].mean(),
                                F_empirical_SD=errors[:, 0].std(ddof=1), s_empirical_SD=errors[:, 1].std(ddof=1)))
    write_csv(out / "recovery_points.csv", list(fit_rows[0]), fit_rows)
    write_csv(out / "local_jacobian.csv", list(jac_rows[0]), jac_rows)
    write_csv(out / "local_covariance.csv", list(covariance_rows[0]), covariance_rows)
    write_csv(out / "verified_metrics.csv", list(metric_rows[0]), metric_rows)
    hashes = {str(p.relative_to(source)).replace("\\", "/"): sha(p) for p in inputs}
    return truth, sigma, points, covariances, metric_rows, hashes


def draw(truth, points, covariances, out):
    plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
                         "font.size": 8.5, "axes.labelsize": 9, "axes.titlesize": 9,
                         "xtick.labelsize": 8.5, "ytick.labelsize": 8.5,
                         "legend.fontsize": 8.5, "pdf.fonttype": 42, "svg.fonttype": "none",
                         "mathtext.fontset": "dejavusans", "axes.linewidth": .65,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "xtick.major.width": .65, "ytick.major.width": .65,
                         "xtick.major.size": 3, "ytick.major.size": 3,
                         "savefig.facecolor": "white"})
    fig, axes = plt.subplots(2, 2, figsize=(6.69, 5.2))
    fig.subplots_adjust(left=.115, right=.975, bottom=.115, top=.945, hspace=.48, wspace=.37)
    contour_rows = []
    quartiles = []
    # Fixed horizontal offsets separate observations without changing their values.
    offsets = .17 * np.sin(np.arange(20) * 2.399963229728653)
    for col, parameter in enumerate(("F", "s")):
        ax = axes[0, col]
        ax.axhline(0, color="#3C444B", lw=.7, zorder=0)
        for x, label in enumerate(LABELS):
            relative = 100 * (points[label][:, col] - truth[col]) / truth[col]
            q1, median, q3 = np.quantile(relative, [.25, .5, .75], method="linear")
            quartiles.append(dict(layout=label, parameter=parameter,
                                  q25_signed_relative_error_percent=q1,
                                  median_signed_relative_error_percent=median,
                                  q75_signed_relative_error_percent=q3))
            ax.vlines(x, q1, q3, color=COLORS[label], lw=7, alpha=.22, zorder=1)
            ax.hlines(median, x-.17, x+.17, color=COLORS[label], lw=1.8, zorder=4)
            ax.scatter(x + offsets, relative, marker=MARKERS[label], s=18,
                       edgecolors=COLORS[label], facecolors="white", linewidths=.85,
                       alpha=.95, zorder=3)
        ax.set_xticks(range(3), LABELS)
        ax.set_xlim(-.5, 2.5)
        ax.set_ylabel("Signed relative error (%)")
        ax.set_title(f"Recovery of ${parameter}$", loc="left", pad=9)
        ax.yaxis.set_major_locator(MultipleLocator(1 if col == 0 else 5))
        ax.set_ylim((-2.5, 2.5) if col == 0 else (-15, 15))
        ax.grid(axis="y", color="#E5E8EA", linewidth=.55, zorder=-1)
        ax.set_axisbelow(True)
    # Shared axes make empirical recovery and the local geometric prediction comparable.
    for ax in axes[1]:
        ax.axvline(truth[0], color="#BCC2C6", lw=.6, zorder=0)
        ax.axhline(truth[1], color="#BCC2C6", lw=.6, zorder=0)
        ax.set_xlim(.487, .513)
        ax.set_ylim(.428, .572)
        ax.set_xticks([.49, .50, .51])
        ax.set_yticks([.44, .47, .50, .53, .56])
        ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f"))
        ax.yaxis.set_major_formatter(FormatStrFormatter("%.2f"))
        ax.set_ylabel("$s$")
        ax.set_xlabel("$F$")
    ax = axes[1, 0]
    for label in LABELS:
        p = points[label]
        ax.scatter(p[:, 0], p[:, 1], marker=MARKERS[label], s=20,
                   edgecolors=COLORS[label], facecolors="white", linewidths=.9,
                   alpha=.95, label=label, zorder=3)
    ax.scatter(*truth, marker="+", s=90, color="#202428", linewidths=1.5, zorder=5)
    ax.set_title("Joint recovery", loc="left", pad=9)
    ax.legend(loc="upper left", frameon=False, ncol=1, borderaxespad=.15,
              handletextpad=.35, labelspacing=.35)
    ax.text(.98, .03, "+  Reference", ha="right", va="bottom", fontsize=8.5,
            transform=ax.transAxes, color="#30363B")
    ax = axes[1, 1]
    t = np.linspace(0, 2*np.pi, 481)
    circle = np.stack([np.cos(t), np.sin(t)])
    for label in LABELS:
        cov = covariances[label]
        values, vectors = np.linalg.eigh(cov)
        delta = np.sqrt(LEVEL) * (vectors @ np.diag(np.sqrt(values)) @ circle)
        contour = truth[:, None] + delta
        inv = np.linalg.inv(cov)
        quadratic = np.einsum("in,ij,jn->n", delta, inv, delta)
        assert np.allclose(quadratic, LEVEL, rtol=1e-10)
        ax.plot(*contour, color=COLORS[label], ls=STYLES[label], lw=1.4,
                label=label, zorder=3)
        for number, (f, s) in enumerate(contour.T):
            contour_rows.append(dict(layout=label, point=number, F=f, s=s, quadratic_level=LEVEL))
    ax.scatter(*truth, marker="+", s=90, color="#202428", linewidths=1.5, zorder=5)
    ax.set_title("Local sensitivity", loc="left", pad=9)
    ax.legend(loc="upper left", frameon=False, ncol=1, borderaxespad=.15,
              handlelength=2.3, handletextpad=.45, labelspacing=.35)
    ax.text(.98, .03, "Δχ² = 2.30", ha="right", va="bottom", fontsize=8.5,
            transform=ax.transAxes, color="#30363B")
    for letter, ax in zip("abcd", axes.flat):
        ax.text(-.21, 1.055, letter, transform=ax.transAxes, fontweight="bold",
                fontsize=11, ha="left", va="bottom")
    for ext in ("pdf", "svg", "png", "tiff"):
        options = {"dpi": 600 if ext == "tiff" else 400} if ext in ("png", "tiff") else {}
        if ext == "tiff": options["pil_kwargs"] = {"compression": "tiff_lzw"}
        fig.savefig(out / f"fig3_recovery_identifiability.{ext}", **options)
    fig.savefig(out / "fig3_preview.png", dpi=150)
    plt.close(fig)
    write_csv(out / "local_contours.csv", list(contour_rows[0]), contour_rows)
    write_csv(out / "error_quartiles.csv", list(quartiles[0]), quartiles)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=HERE.parent / "paired_layer_design" / "results")
    parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args()
    source, out = args.source.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    truth, sigma, points, covariances, metrics, hashes = read_data(source, out)
    draw(truth, points, covariances, out)
    manifest = dict(figure="Section VI parameter recovery and local identifiability",
                    truth_FS=truth.tolist(), sigma=sigma, n_fits=60,
                    seeds=list(range(2001, 2021)), pilot_multistarts_plotted=False,
                    local_contour_definition="delta_p.T @ inverse(C) @ delta_p = 2.30; C=(J.T J)^(-1); J=dh/d(F,s)/sigma at truth",
                    local_contour_interpretation="Local quadratic sensitivity contours; not empirical confidence regions or nonlinear profile-likelihood contours.",
                    error_summary="Signed relative errors; all 20 values, horizontal median, thick translucent interquartile range (linear quantiles). Horizontal offsets are display-only.",
                    input_sha256=hashes, script_sha256=sha(Path(__file__)),
                    environment=dict(python=platform.python_version(), numpy=np.__version__, matplotlib=matplotlib.__version__),
                    dimensions_inches=[6.69, 5.2], minimum_text_points=8.5,
                    minimum_line_points=0.55, metrics=metrics,
                    data_checks="Each saved fit checked for success, cohort, seed and absence of bound hits; recomputed RMSE and Jacobian covariance agree with archived metrics.")
    (out / "figure_provenance.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({"fit_count": 60, "metrics": metrics, "outputs": "PDF, SVG, PNG, TIFF and six CSV source-data tables"}, indent=2))


if __name__ == "__main__":
    main()
