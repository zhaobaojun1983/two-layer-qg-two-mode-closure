"""Two fixed-background, noise-free recovery checks; no noisy fit suite.

The existing audited optimizer uses a fixed third coordinate internally.
Only the free (F,s[,qA,qB,qx,qw]) variables are reported as recovered values.
"""
from pathlib import Path
import hashlib
import json
import sys
import time

sys.dont_write_bytecode = True
import numpy as np

BRANCH = Path(__file__).resolve().parent
SOURCE = BRANCH.parent
sys.path.insert(0, str(SOURCE))
from direct_identifiability import forward, observation_indices, fit, LOWER, UPPER, X_SCALE
from slow_coordinate_forward import forward_slow, split_parameters
import _coeffs_strict as physics

OUT = BRANCH / "noiseless_recovery_results"
TRUE_FS = np.array([.5, .5])
TRUE_Q = np.zeros(4)
CONFIGURATION = "surface_deep"
CRITERIA = dict(max_physical_relative_error=1e-5,
                selected_observation_relative_L2=1e-7,
                unknown_initial_max_absolute_error=1e-3,
                optimizer_success_required=True)
CASES = [("known_initial", False, [.55,.45]),
         ("unknown_initial", True, [.55,.45,.03,-.15,.10,.03])]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (OUT/(name+".json")).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding="utf-8")


def expand(p):
    theta, q = split_parameters(p)
    return np.r_[theta, q] if len(p) == 6 else theta


def relative(actual, target):
    return float(np.linalg.norm(actual-target)/np.linalg.norm(target))


def main():
    started = time.perf_counter()
    OUT.mkdir(exist_ok=True)
    if (OUT/"summary.json").exists():
        raise FileExistsError("A completed run exists; preserve it before a separate new run.")
    assert (physics.UM,physics.UJ,physics.W,physics.L,physics.BETA)==(.15,.4,.65,1.,1.)
    protected = [SOURCE/name for name in (
        "direct_identifiability.py","identifiability_tangent.py","inverse_modal_branch.py",
        "two_mode_closure.py","_coeffs_strict.py","wave_propagation.py",
        "traveling_wave_results/reference.npz","traveling_wave_results/reference.json",
        "two_layer_model_two_mode_closure.tex","two_layer_model_two_mode_closure_red.tex",
        "two_layer_model_two_mode_closure.pdf","two_layer_model_two_mode_closure_red.pdf")]
    protected += [BRANCH/name for name in (
        "two_layer_model_fixed_flow_FS.tex","two_layer_model_fixed_flow_FS_red.tex",
        "two_layer_model_fixed_flow_FS.pdf","two_layer_model_fixed_flow_FS_red.pdf",
        "feasibility_and_revision_plan_zh.tex","feasibility_and_revision_plan_zh.pdf",
        "slow_coordinate_forward.py","check_coordinate_observations.py")]
    protected.append(SOURCE.parents[2]/"two_layer_model.tex")
    before = {str(p):digest(p) for p in protected}
    truth = forward(expand(TRUE_FS))
    indices = observation_indices(CONFIGURATION)
    assert len(indices)==747
    selected_truth = truth.ravel()[indices]
    residual_scale = .01*float(np.max(abs(truth[0])))
    assert residual_scale > 0
    # No random variates are generated or added. sigma is only a fixed unit.
    data = dict(indices=indices, values=selected_truth.copy(), sigma=residual_scale,
                noise=0., configuration=CONFIGURATION, sampling={})
    np.savez_compressed(OUT/"noiseless_data.npz", truth_full=truth, indices=indices,
                        data=selected_truth, residual_scale=np.array(residual_scale),
                        truth_FS=TRUE_FS, truth_q=TRUE_Q)
    manifest = dict(status="running", fixed_inputs=dict(Um=.15,Uj=.4,w=.65,lambda_fixed=.20,beta=1.,L=1.),
                    physical_unknowns=["F","s"], truth_FS=TRUE_FS.tolist(), truth_q=TRUE_Q.tolist(),
                    configuration=CONFIGURATION, observation_count=len(indices),
                    experiment=dict(period=1024.,nx=512,dt=5.,end_time=1000.,N=24,Ny=1025),
                    added_noise=0., random_noise_generated=False, residual_normalization=residual_scale,
                    normalization_meaning="Positive fixed residual unit, not a claimed nonzero measurement noise.",
                    initial_state="Known canonical modal BVP template, or that template with four fitted initial variables.",
                    planned_cases=[dict(name=n,unknown_initial=u,start=p) for n,u,p in CASES],
                    acceptance_criteria=CRITERIA,
                    optimizer=dict(method="SciPy bounded least_squares / TRF",jacobian="Audited discrete ETDRK4 tangent, free columns selected",
                                   max_nfev=70,ftol=2e-8,xtol=2e-8,gtol=1e-6),
                    protected_source_sha256=before, run_source_sha256=digest(Path(__file__)),
                    data_sha256=digest(OUT/"noiseless_data.npz"))
    save("experiment_manifest",manifest)
    records=[]
    for name, unknown, start in CASES:
        print("START "+name+" "+str(start),flush=True)
        free = np.array([0,1,3,4,5,6] if unknown else [0,1])
        start_full = expand(start)
        initial_prediction=forward(start_full)
        initial_selected=initial_prediction.ravel()[indices]
        initial_r=(initial_selected-selected_truth)/residual_scale
        raw=fit(data,start_full,unknown_initial=unknown,fixed={2:.20},max_nfev=70)
        assert raw["parameters"][2]==.20
        full=np.asarray(raw["parameters"])
        recovered=full[free]
        target=np.r_[TRUE_FS,TRUE_Q] if unknown else TRUE_FS
        prediction=forward(full)
        selected=prediction.ravel()[indices]
        residual=(selected-selected_truth)/residual_scale
        scaled_sse=float(residual@residual)
        fs_abs=abs(recovered[:2]-TRUE_FS)
        fs_rel=fs_abs/abs(TRUE_FS)
        q_abs=abs(recovered[2:]) if unknown else np.zeros(0)
        field=relative(selected,selected_truth)
        at_bound=(np.minimum(recovered-LOWER[free],UPPER[free]-recovered)<1e-4)
        slow_prediction=forward_slow(recovered,epsilon=.1)
        scale_check=relative(slow_prediction,prediction)
        assert scale_check<1e-10
        assert abs(scaled_sse-raw["chi_square"])/max(1.,scaled_sse)<1e-10
        passed=bool(raw["success"] and np.max(fs_rel)<=CRITERIA["max_physical_relative_error"]
                    and field<=CRITERIA["selected_observation_relative_L2"]
                    and (not unknown or np.max(q_abs)<=CRITERIA["unknown_initial_max_absolute_error"]))
        record=dict(case=name,unknown_initial=unknown,
                    free_parameter_names=["F","s"]+(["qA","qB","qx","qw"] if unknown else []),
                    free_parameter_count=len(free),truth=target.tolist(),start=start,recovered=recovered.tolist(),
                    original_interface_free_indices=free.tolist(), fixed_background_verified=True,
                    free_bounds=[LOWER[free].tolist(),UPPER[free].tolist()],free_parameter_scales=X_SCALE[free].tolist(),
                    absolute_FS_error=fs_abs.tolist(),relative_FS_error=fs_rel.tolist(),
                    initial_variable_absolute_error=q_abs.tolist(),free_variables_at_bound=at_bound.tolist(),
                    initial_selected_observation_relative_L2=relative(initial_selected,selected_truth),
                    selected_observation_relative_L2=field,full_observation_relative_L2=relative(prediction,truth),
                    full_per_layer_relative_L2=[relative(prediction[i],truth[i]) for i in range(2)],
                    max_selected_absolute_residual=float(np.max(abs(selected-selected_truth))),
                    initial_scaled_SSE=float(initial_r@initial_r),final_scaled_SSE=scaled_sse,
                    normalized_SSE_per_residual_dof=scaled_sse/(len(indices)-len(free)),
                    residual_degrees_of_freedom=len(indices)-len(free),
                    objective_interpretation="Deterministic scaled sum of squares; no chi-square distribution interpretation for exact data.",
                    success=raw["success"],termination=raw["message"],nfev=raw["nfev"],calls=raw["calls"],
                    optimality=raw["optimality"],runtime_seconds=raw["runtime_seconds"],
                    slow_coordinate_reconstruction_relative_L2=scale_check,acceptance_passed=passed)
        np.savez_compressed(OUT/(name+"_evidence.npz"),prediction_full=prediction,
                            initial_prediction_full=initial_prediction,selected_prediction=selected,
                            normalized_residual=residual,slow_coordinate_prediction=slow_prediction)
        record["evidence_sha256"]=digest(OUT/(name+"_evidence.npz"))
        save(name,record)
        records.append(record)
        print(json.dumps({k:record[k] for k in ("case","recovered","relative_FS_error","selected_observation_relative_L2",
                                               "nfev","success","acceptance_passed")}),flush=True)
    after={str(p):digest(p) for p in protected}
    assert before==after, "Pre-existing source or manuscript was modified."
    passed=all(r["acceptance_passed"] for r in records)
    summary=dict(status="passed" if passed else "needs_followup", completed_fits=len(records),
                 scope="Two local exact-data, fixed-background recovery checks, one start per initial-state case.",
                 all_acceptance_criteria_passed=passed,configuration=CONFIGURATION,observation_count=len(indices),
                 fixed_inputs=manifest["fixed_inputs"],added_noise=0.,physical_unknowns=["F","s"],
                 maximum_relative_FS_error=max(max(r["relative_FS_error"]) for r in records),
                 maximum_observation_relative_L2=max(r["selected_observation_relative_L2"] for r in records),
                 results=records,protected_files_unchanged=True,data_sha256=manifest["data_sha256"],
                 run_source_sha256=manifest["run_source_sha256"],
                 remaining_work="No noisy multistart fits, local information calculation, profile fits or noise repeats performed in this run.",
                 runtime_seconds=time.perf_counter()-started)
    manifest["status"]="complete"
    manifest["protected_files_unchanged"]=True
    save("experiment_manifest",manifest)
    save("summary",summary)
    print(json.dumps({k:summary[k] for k in ("status","completed_fits","maximum_relative_FS_error",
                                            "maximum_observation_relative_L2","runtime_seconds")}),flush=True)


if __name__=="__main__":
    main()
