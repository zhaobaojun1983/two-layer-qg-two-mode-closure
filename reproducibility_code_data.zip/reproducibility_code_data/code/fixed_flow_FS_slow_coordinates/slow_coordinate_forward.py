"""Fixed-jet forward observations in X=eps*x, T=eps**3*t, a=eps**2*u.

This module advances the scaled PDE, not a rescaled stored trajectory. It
reuses the validated modal coefficients and ETDRK4 numerical scheme. Only
(F,s) and optionally four initial-state variables are accepted as inputs.
"""
from pathlib import Path
import sys

import numpy as np

SOURCE = Path(__file__).resolve().parent.parent
if str(SOURCE) not in sys.path:
    sys.path.insert(0, str(SOURCE))
from direct_identifiability import reference, smooth_coefficients, X_SENSORS, TIMES
from wave_propagation import FourierETDRK4

FIXED_LAMBDA = 0.20


def split_parameters(parameters):
    p = np.asarray(parameters, dtype=float)
    if p.ndim != 1 or p.size not in (2, 6) or not np.all(np.isfinite(p)):
        raise ValueError("Expected (F,s) or (F,s,qA,qB,qx,qw), all finite.")
    return np.r_[p[:2], FIXED_LAMBDA], p[2:] if p.size == 6 else np.zeros(4)


def check_epsilon(epsilon):
    if not np.isfinite(epsilon) or epsilon <= 0:
        raise ValueError("epsilon must be prescribed, finite and positive.")


def initial_slow(X, epsilon, q=None):
    """Evaluate the saved template using a displacement measured in X units."""
    check_epsilon(epsilon)
    q = np.zeros(4) if q is None else np.asarray(q, dtype=float)
    if q.shape != (4,) or not np.all(np.isfinite(q)):
        raise ValueError("Expected four finite initial-state variables.")
    X = np.asarray(X, dtype=float)
    if X.ndim != 1:
        raise ValueError("Expected a one-dimensional spatial sample array.")
    _, wave, interp, extent = reference()
    shift_X = 25.0 * epsilon * q[2]
    inverse_width_X = wave["kappa_seed"] / (epsilon * np.exp(q[3]))
    z = np.abs(X - shift_X) * inverse_width_X
    inside = z <= extent
    u = np.zeros((2, X.size))
    u[:, inside] = (wave["amplitude_scale"] / epsilon**2) * interp(z[inside]).T
    return u * np.exp(q[:2, None])


def forward_slow(parameters, epsilon=0.1, nx=512, dt_original=5.0,
                 N=24, Ny=1025, details=False):
    """Physical layer streamfunctions, ordered (layer,time,y,x).

    The physical period, sample points and observation window remain fixed.
    No phase alignment is applied. The returned field includes eps**2.
    """
    check_epsilon(epsilon)
    theta, q = split_parameters(parameters)
    co = smooth_coefficients(theta, N=N, Ny=Ny)
    length_X = epsilon * 1024.0
    dt_T = epsilon**3 * dt_original
    solver = FourierETDRK4(co["C"] / epsilon**2, co["D"], co["G"],
                          length_X, nx, dt_T, frame_speed=0.0)
    h = solver.project(initial_slow(solver.x, epsilon, q))
    sample_X = epsilon * X_SENSORS
    fractional_nodes = (sample_X + length_X / 2) / (length_X / nx)
    exact_nodes = np.max(np.abs(fractional_nodes - np.round(fractional_nodes))) < 1e-12
    if exact_nodes:
        indices = np.round(fractional_nodes).astype(int)
    else:
        interpolation = np.exp(1j * solver.k[:, None] *
                               (sample_X[None, :] + length_X / 2)) / nx
    stride = int(round((epsilon**3 * 25.0) / dt_T))
    steps = int(round((epsilon**3 * 1000.0) / dt_T))
    if (stride <= 0 or abs(stride * dt_T - epsilon**3 * 25.0) > 1e-10 * epsilon**3
            or abs(steps * dt_T - epsilon**3 * 1000.0) > 1e-10 * epsilon**3):
        raise ValueError("Time step must exactly resolve the physical sample grid.")
    sampled, grids = [], []
    for step in range(steps + 1):
        if step % stride == 0:
            grid = np.fft.ifft(h, axis=-1).real
            sampled.append(grid[:, indices] if exact_nodes else np.real(h @ interpolation))
            if details:
                grids.append(grid)
        if step < steps:
            h = solver.step(h)
    modal = np.asarray(sampled)
    observations = epsilon**2 * np.einsum("ljy,tjx->ltyx", co["layer"], modal)
    if not np.all(np.isfinite(observations)):
        raise ValueError("Nonfinite slow-coordinate observation.")
    if not details:
        return observations
    return dict(observations=observations, modal_samples=modal,
                modal_grid=np.asarray(grids), X_grid=solver.x,
                X_samples=sample_X, T_samples=epsilon**3 * TIMES,
                dt_T=dt_T, length_X=length_X, exact_nodes=bool(exact_nodes),
                layer_reconstruction=co["layer"], physical_parameters=theta[:2],
                initial_variables=q, epsilon=epsilon)
