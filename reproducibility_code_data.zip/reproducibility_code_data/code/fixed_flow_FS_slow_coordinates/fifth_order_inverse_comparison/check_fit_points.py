"""Independent step-size and saved-Jacobian checks at the four fitted endpoints.

No optimization is performed. All original fit records remain unchanged.
"""
from pathlib import Path
import os
import sys
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
sys.dont_write_bytecode = True
import hashlib
import json
import time
from forward_models import forward_FS, np

HERE = Path(__file__).resolve().parent
CASES = ('parent_third_noiseless', 'parent_fifth_noiseless',
         'parent_third_noisy', 'parent_fifth_noisy')


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    start = time.perf_counter()
    rows, arrays, sources = [], {}, {}
    code_hash = digest(HERE/'forward_models.py')
    for case in CASES:
        meta_path, data_path = HERE/(case+'.json'), HERE/(case+'.npz')
        meta = json.loads(meta_path.read_text(encoding='utf-8'))
        assert meta['status'] == 'completed' and meta['success']
        assert meta['forward_source_sha256'] == code_hash
        sources[meta_path.name], sources[data_path.name] = digest(meta_path), digest(data_path)
        with np.load(data_path, allow_pickle=False) as data:
            coarse = data['prediction'].copy()
            rawJ = data['raw_jacobian_at_fit'].copy()
            indices = data['indices'].copy()
            residual = data['residual'].copy()
        theta = np.array(meta['recovered_FS'])
        sigma = meta['sigma']
        assert coarse.shape == (2, 41, 3, 65) and rawJ.shape == (coarse.size, 2)
        assert len(indices) == len(residual) == 747
        fine = forward_FS(theta, model=meta['model'], nx=512, dt=2.5, N=24, Ny=1025)
        delta = fine-coarse
        selected_delta = delta.ravel()[indices]
        selected_J = rawJ[indices]
        weighted_J = selected_J/sigma
        scaled_J = .5*weighted_J
        _, singular, vh = np.linalg.svd(scaled_J, full_matrices=False)
        covariance = .25*(vh.T/singular**2)@vh
        standard_error = np.sqrt(np.diag(covariance))
        correlation = covariance/np.outer(standard_error, standard_error)
        numerical_correction = -np.linalg.lstsq(selected_J, selected_delta, rcond=None)[0]
        remaining_GN_step = -np.linalg.lstsq(weighted_J, residual, rcond=None)[0]
        row = dict(case=case, model=meta['model'], recovered_FS=theta.tolist(),
                   coarse_dt=5., fine_dt=2.5,
                   full_observation_relative_difference=float(np.linalg.norm(delta)/np.linalg.norm(fine)),
                   SD_relative_difference=float(np.linalg.norm(selected_delta)/np.linalg.norm(fine.ravel()[indices])),
                   SD_RMS_in_sigma=float(np.sqrt(np.mean((selected_delta/sigma)**2))),
                   SD_max_absolute_difference_in_sigma=float(np.max(np.abs(selected_delta/sigma))),
                   linearized_time_step_parameter_correction_FS=numerical_correction.tolist(),
                   time_step_parameter_correction_relative_percent_of_truth=(numerical_correction/.5*100).tolist(),
                   fitted_point_scaled_singular_values=singular.tolist(),
                   fitted_point_condition=float(singular[0]/singular[-1]),
                   fitted_point_rank=int(np.count_nonzero(singular > 1e-7*singular[0])),
                   fitted_point_covariance_physical=covariance.tolist(),
                   fitted_point_local_standard_error=standard_error.tolist(),
                   fitted_point_correlation=correlation.tolist(),
                   saved_residual_RMS_in_sigma=float(np.sqrt(np.mean(residual**2))),
                   remaining_Gauss_Newton_step_FS=remaining_GN_step.tolist(),
                   remaining_GN_step_relative_percent_of_truth=(remaining_GN_step/.5*100).tolist(),
                   weighted_gradient_inf=float(np.max(np.abs(weighted_J.T@residual))),
                   normalized_GN_step_in_local_standard_errors=(remaining_GN_step/standard_error).tolist())
        assert row['fitted_point_rank'] == 2
        assert row['full_observation_relative_difference'] < 1e-5
        rows.append(row)
        for name, value in dict(fine_prediction=fine, delta_prediction=delta,
                                selected_delta=selected_delta,
                                linearized_time_step_correction=numerical_correction,
                                remaining_GN_step=remaining_GN_step,
                                covariance_physical=covariance,
                                scaled_singular_values=singular).items():
            arrays[case+'_'+name] = value
    for name, expected in sources.items():
        assert digest(HERE/name) == expected, name
    lookup = {r['case']: r for r in rows}
    comparisons = {}
    for kind in ('noiseless', 'noisy'):
        a, b = lookup['parent_third_'+kind], lookup['parent_fifth_'+kind]
        gap = np.array(b['recovered_FS'])-np.array(a['recovered_FS'])
        GN_gap_correction = np.array(b['remaining_Gauss_Newton_step_FS'])-np.array(a['remaining_Gauss_Newton_step_FS'])
        time_gap_correction = np.array(b['linearized_time_step_parameter_correction_FS'])-np.array(a['linearized_time_step_parameter_correction_FS'])
        comparisons[kind] = dict(fifth_minus_third_FS=gap.tolist(),
                                 estimated_GN_correction_to_gap=GN_gap_correction.tolist(),
                                 GN_correction_fraction_of_gap=np.abs(GN_gap_correction/gap).tolist(),
                                 estimated_time_refinement_correction_to_gap=time_gap_correction.tolist(),
                                 time_refinement_fraction_of_gap=np.abs(time_gap_correction/gap).tolist())
    np.savez_compressed(HERE/'fit_point_convergence.npz', **arrays)
    result = dict(status='passed', new_fits=False, cases=rows,
                  between_model_endpoint_comparisons=comparisons,
                  sigma_definition='The same fixed absolute observation noise as the four saved fits.',
                  numerical_correction_definition='-pinv(raw J_selected) @ (prediction_dt2.5-prediction_dt5); first-order endpoint correction only.',
                  remaining_GN_definition='-lstsq(raw J_selected/sigma, saved normalized residual); one unconstrained local Gauss-Newton step, not a refit.',
                  local_information_definition='Singular values use 0.5*raw J_selected/sigma. Covariance is in physical F,s units; assumed-model local indicators at each fitted endpoint.',
                  source_sha256=dict(sources, forward_models=code_hash, check_script=digest(Path(__file__))),
                  evidence_sha256=digest(HERE/'fit_point_convergence.npz'),
                  source_files_unchanged=True, runtime_seconds=time.perf_counter()-start)
    (HERE/'fit_point_convergence.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
