"""Limited, matched-data third/fifth-order FS comparison; never edits manuscripts."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import sys
import time

for name in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS'):
    os.environ[name] = '1'
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BRANCH, ROOT = HERE.parent, HERE.parents[1]
sys.path[:0] = [str(ROOT / '.local_python'), str(ROOT), str(BRANCH)]
import numpy as np
from scipy.optimize import least_squares
from direct_identifiability import observation_indices, X_SENSORS, Y_SENSORS, TIMES

TRUTH = np.array([.5, .5])
START = np.array([.55, .45])
BOUNDS = (np.array([.25, .30]), np.array([.90, .70]))
SCALE = np.array([.5, .5])
CASES = {
    'fifth_self_noiseless': ('consistent5', 'self'),
    'parent_third_noiseless': ('third', 'noiseless'),
    'parent_fifth_noiseless': ('consistent5', 'noiseless'),
    'parent_third_noisy': ('third', 'noisy'),
    'parent_fifth_noisy': ('consistent5', 'noisy'),
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, data):
    (HERE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def load(name):
    return json.loads((HERE / name).read_text(encoding='utf-8'))


def relative(value, reference):
    return float(np.linalg.norm(value-reference) / max(np.linalg.norm(reference), 1e-300))


def protect():
    manifest = load('experiment_manifest.json')
    for path, expected in manifest['protected_sha256'].items():
        assert digest(path) == expected, path
    return manifest


def initialize():
    if (HERE / 'experiment_manifest.json').exists():
        protect()
        return
    names = ['direct_identifiability.py', 'identifiability_tangent.py', 'inverse_modal_branch.py',
             'two_mode_closure.py', 'wave_propagation.py', '_coeffs_strict.py', 'long_time_validation.py',
             'traveling_wave_results/reference.npz', 'traveling_wave_results/reference.json',
             'two_layer_model_two_mode_closure.tex', 'two_layer_model_two_mode_closure_red.tex',
             'two_layer_model_two_mode_closure.pdf', 'two_layer_model_two_mode_closure_red.pdf']
    files = [ROOT / name for name in names]
    files += [BRANCH / name for name in ('two_layer_model_fixed_flow_FS.tex',
              'two_layer_model_fixed_flow_FS_red.tex', 'two_layer_model_fixed_flow_FS.pdf',
              'two_layer_model_fixed_flow_FS_red.pdf', 'source_manifest.json', 'delivery_check.json',
              'known_modal_results.json', 'noisy_fs_results/shared_data.npz')]
    files += [ROOT.parents[2] / 'two_layer_model.tex']
    with np.load(BRANCH / 'noisy_fs_results/shared_data.npz') as old:
        indices = old['SD_indices'].copy()
        sigma = float(old['sigma'])
        noise = old['standard_normal_noise'].copy()
    assert np.array_equal(indices, observation_indices('surface_deep')) and len(indices) == 747
    np.savez_compressed(HERE / 'observation_design.npz', indices=indices, sigma=sigma,
                        standard_normal_noise=noise, truth=TRUTH, start=START,
                        x_sensors=X_SENSORS, y_sensors=Y_SENSORS, times=TIMES)
    save('experiment_manifest.json', {
        'status': 'initialized', 'purpose': 'Limited decision experiment; SD only, fixed known modal initial state, F and s only',
        'truth_FS': TRUTH.tolist(), 'start_FS': START.tolist(), 'design': 'SD', 'observations': 747,
        'fixed_inputs': {'Um': .15, 'Uj': .40, 'w': .65, 'lambda': .20, 'beta': 1., 'L': 1.},
        'initial_state': 'Same saved third-order reference modal waveforms in the fixed reference-adjoint normalization; physical initial field is parameter-dependent at trial FS.',
        'nominal_forward': {'length': 1024., 'nx': 512, 'dt': 5., 'end_time': 1000., 'Nmode': 24, 'quadrature': 1025},
        'sigma': sigma, 'noise_source': 'Previous seed-101 standard-normal master vector; same fixed absolute sigma for every comparison',
        'noise_scale_definition': 'Preserved 1% of the previous third-order upper-layer master-grid peak; not rescaled separately for each candidate/model/parent.',
        'planned_cases': list(CASES), 'bounds_FS': [v.tolist() for v in BOUNDS],
        'uncertainty_scope': 'Two-column local linearized indicators of each assumed reduced model at the generating FS; no calibrated misspecification-aware confidence interval.',
        'new_parent_initial_states': 1, 'manuscript_changes': False,
        'protected_sha256': {str(p): digest(p) for p in files},
        'design_sha256': digest(HERE / 'observation_design.npz')})
    print(json.dumps({'initialized': True, 'observations': len(indices), 'sigma': sigma}), flush=True)


def prepare_data(parent_file):
    protect()
    path = Path(parent_file)
    if not path.is_absolute():
        path = HERE / path
    with np.load(path) as saved:
        parent = saved['observations'].copy()
    with np.load(HERE / 'observation_design.npz') as design:
        indices, sigma, z = design['indices'], float(design['sigma']), design['standard_normal_noise']
    assert parent.shape == (2, 41, 3, 65) and parent.size == z.size
    assert np.all(np.isfinite(parent))
    np.savez_compressed(HERE / 'matched_parent_data.npz', parent_full=parent,
                        indices=indices, sigma=sigma, standard_normal_noise=z,
                        noiseless=parent.ravel()[indices], noisy=parent.ravel()[indices]+sigma*z[indices])
    save('matched_parent_data.json', {'parent_source': str(path), 'parent_sha256': digest(path),
         'matched_data_sha256': digest(HERE / 'matched_parent_data.npz'), 'shape': list(parent.shape),
         'sigma': sigma, 'observations': len(indices), 'same_noise_and_sampling': True})
    print(json.dumps({'prepared_parent_data': str(path)}), flush=True)


def information(raw, indices, sigma):
    scaled = raw[indices] * SCALE / sigma
    _, singular, vh = np.linalg.svd(scaled, full_matrices=False)
    covariance = ((vh.T / singular**2) @ vh) * SCALE[:, None] * SCALE[None, :]
    sd = np.sqrt(np.diag(covariance))
    weak = vh[-1].copy()
    if weak[np.argmax(abs(weak))] < 0:
        weak *= -1
    return {'rank': int(np.sum(singular > 1e-7*singular[0])), 'singular_values': singular.tolist(),
            'condition': float(singular[0]/singular[-1]), 'weakest_scaled_direction': weak.tolist(),
            'covariance_physical': covariance.tolist(), 'local_standard_error': sd.tolist(),
            'correlation': (covariance/np.outer(sd, sd)).tolist()}


def local_information():
    from forward_models import forward_FS, jacobian_FS
    protect()
    with np.load(HERE / 'observation_design.npz') as design:
        indices, sigma = design['indices'], float(design['sigma'])
    rows, arrays = {}, {}
    for model in ('third', 'consistent5'):
        prediction = forward_FS(TRUTH, model=model)
        raw = jacobian_FS(TRUTH, model=model)
        assert raw.shape == (prediction.size, 2)
        rows[model] = information(raw, indices, sigma)
        arrays[model+'_prediction'] = prediction
        arrays[model+'_jacobian'] = raw
        print(json.dumps({'model': model, **rows[model]}), flush=True)
    save('local_information.json', {'status': 'completed', 'truth_FS': TRUTH.tolist(),
         'sigma': sigma, 'parameter_scales': SCALE.tolist(), 'design': 'SD', 'models': rows,
         'forward_source_sha256': digest(HERE / 'forward_models.py')})
    np.savez_compressed(HERE / 'local_information.npz', indices=indices, sigma=sigma, **arrays)


def fit_case(name):
    from forward_models import forward_FS, jacobian_FS
    manifest = protect()
    model, data_kind = CASES[name]
    target = HERE / (name + '.json')
    if target.exists():
        raise FileExistsError('Preserve the existing fit; do not overwrite '+str(target))
    with np.load(HERE / 'observation_design.npz') as design:
        indices, sigma = design['indices'].copy(), float(design['sigma'])
    if data_kind == 'self':
        reference = forward_FS(TRUTH, model=model)
        values = reference.ravel()[indices]
        data_sha256 = None
    else:
        metadata = load('matched_parent_data.json')
        assert metadata['matched_data_sha256'] == digest(HERE / 'matched_parent_data.npz')
        with np.load(HERE / 'matched_parent_data.npz') as data:
            reference, values = data['parent_full'].copy(), data[data_kind].copy()
        data_sha256 = metadata['matched_data_sha256']
    calls, trajectory = 0, []
    cache = {}
    def objective(p):
        nonlocal calls
        key = tuple(p)
        if key not in cache:
            y = forward_FS(p, model=model)
            r = (y.ravel()[indices]-values)/sigma
            cache.clear()
            cache[key] = (y, r)
            calls += 1
            record = {'call': calls, 'FS': p.tolist(), 'chi_square': float(r@r)}
            trajectory.append(record)
            save(name+'_progress.json', {'case': name, 'model': model, 'evaluations': trajectory})
            print(name+' '+json.dumps(record), flush=True)
        return cache[key][1]
    def jac(p):
        return jacobian_FS(p, model=model)[indices]/sigma
    started = time.perf_counter()
    result = least_squares(objective, START, jac=jac, bounds=BOUNDS, x_scale=SCALE,
                           ftol=2e-9, xtol=2e-9, gtol=1e-7, max_nfev=45)
    prediction = forward_FS(result.x, model=model)
    residual = (prediction.ravel()[indices]-values)/sigma
    raw_jac = jacobian_FS(result.x, model=model)
    row = {'status': 'completed', 'case': name, 'model': model, 'data_kind': data_kind,
           'start_FS': START.tolist(), 'recovered_FS': result.x.tolist(),
           'signed_error_FS': (result.x-TRUTH).tolist(),
           'relative_error_percent_FS': (100*(result.x-TRUTH)/TRUTH).tolist(),
           'absolute_relative_error_percent_FS': (100*abs(result.x-TRUTH)/TRUTH).tolist(),
           'success': bool(result.success), 'termination': result.message,
           'nfev': result.nfev, 'njev': result.njev, 'calls': calls,
           'optimality': float(result.optimality), 'active_mask': result.active_mask.tolist(),
           'chi_square': float(residual@residual), 'reduced_chi_square': float(residual@residual)/(len(indices)-2),
           'selected_reference_relative_L2': relative(prediction.ravel()[indices], reference.ravel()[indices]),
           'full_reference_relative_L2': relative(prediction, reference),
           'residual_rms_in_sigma': float(np.sqrt(np.mean(residual**2))),
           'sigma': sigma, 'observations': len(indices), 'runtime_seconds': time.perf_counter()-started,
           'matched_data_sha256': data_sha256, 'forward_source_sha256': digest(HERE / 'forward_models.py'),
           'runner_source_sha256': digest(Path(__file__)),
           'scope': 'One fixed start and one shared noise realization; finite matched-data decision experiment.'}
    np.savez_compressed(HERE / (name+'.npz'), prediction=prediction, residual=residual,
                        raw_jacobian_at_fit=raw_jac, indices=indices, values=values)
    row['evidence_sha256'] = digest(HERE / (name+'.npz'))
    save(name+'.json', row)
    protect()
    print('COMPLETE '+json.dumps(row), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['initialize', 'prepare-data', 'information', *CASES])
    parser.add_argument('--parent', default='parent_base.npz')
    args = parser.parse_args()
    if args.action == 'initialize': initialize()
    elif args.action == 'prepare-data': prepare_data(args.parent)
    elif args.action == 'information': local_information()
    else: fit_case(args.action)
