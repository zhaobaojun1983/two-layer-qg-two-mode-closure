"""Matched third/consistent-fifth observation maps with known modal initial data.

Only (F,s) vary. The Bickley shape and displacement 0.20 remain fixed.
All trial coefficients, reconstruction modes and their reference normalization
are recomputed. The original-coordinate PDE for consistent5 is
 a_t = -C a_x - D a_xxx - Qy + (M D) a_xxxxx - Qx + M d_xx Qy.
No higher-order solitary-wave BVP is needed: both models start from the same
saved modal profile in the same fixed reference normalization.
"""
from pathlib import Path
import os
import sys

# Set these before importing NumPy/SciPy or any project module.
for _name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
              'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
    os.environ[_name] = '1'
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BRANCH = HERE.parent
ROOT = BRANCH.parent
sys.path.insert(0, str(ROOT / '.local_python'))
sys.path.insert(0, str(ROOT))

import argparse
import hashlib
import importlib.util
import json
import time
import numpy as np
from _coeffs_strict import project
from direct_identifiability import (smooth_coefficients, initial_profile, forward as legacy_forward,
                                    X_SENSORS, Y_SENSORS, TIMES)
from wave_propagation import FourierETDRK4, phi

LENGTH = 1024.0
DURATION = 1000.0
LAMBDA_FIXED = 0.20
OBSERVATION_SHAPE = (2, 41, 3, 65)


def _theta(theta):
    values = np.asarray(theta, dtype=float)
    if values.shape != (2,) or not np.all(np.isfinite(values)) or values[0] <= 0:
        raise ValueError('theta must contain only finite (F,s), with F>0; displacement is fixed.')
    return values


def coefficients(theta=(.5, .5), N=24, Ny=1025):
    """Reference-gauged coefficients, including the ordered R tensor.

    The normalization is exactly the one used by the legacy inverse map.
    Raw R is projected from the trial right/adjoint fields and then transformed
    as R[i,p,q] *= scale[p]*scale[q]/scale[i], just as G is transformed.
    """
    F, s = _theta(theta)
    if not 2 <= int(N) <= 64:
        raise ValueError('The common reference normalization supports 2 <= N <= 64.')
    co = smooth_coefficients((float(F), float(s), LAMBDA_FIXED), N=int(N), Ny=int(Ny))
    basis = co['raw']['basis']
    fields = basis['fields']
    raw_R = np.empty((2, 2, 2))
    for p in range(2):
        for q in range(2):
            pp, tp = fields[p, :, 0]
            pqy, tqy = fields[q, :, 1]
            raw_R[:, p, q] = project(basis, np.array([pp*pqy + tp*tqy,
                                                     pp*tqy + tp*pqy]))
    scale = co['gauge_scale']
    co['R'] = raw_R * scale[None, :, None] * scale[None, None, :] / scale[:, None, None]
    co['raw_R'] = raw_R
    co['MD'] = co['M'] @ co['D']
    co['theta_FS'] = np.array([F, s])
    co['lambda_fixed'] = LAMBDA_FIXED
    return co


class ConsistentFifthETDRK4(FourierETDRK4):
    """The audited ETDRK4 stages with the consistent fifth-order operators."""
    def __init__(self, co, length=LENGTH, nx=512, dt=5.):
        self.co = co
        self.C, self.D, self.G = (co[k] for k in ('C', 'D', 'G'))
        self.length, self.nx, self.dt, self.frame_speed = float(length), int(nx), float(dt), 0.
        self.x = (np.arange(nx) - nx//2) * length/nx
        self.k = 2*np.pi*np.fft.fftfreq(nx, d=length/nx)
        self.mask = np.abs(np.fft.fftfreq(nx)*nx) < nx/3
        self.blocks = (-self.C[None] + self.k[:, None, None]**2*self.D[None]
                       + self.k[:, None, None]**4*co['MD'][None])
        # Inactive Fourier modes are always zero. Use harmless blocks for their
        # exponentials so an inactive, high-frequency truncation artifact cannot
        # produce 0*inf during the projected stages. Retained blocks are unchanged.
        active = np.where(self.mask[:, None, None], self.blocks, -self.C[None])
        eig, vectors = np.linalg.eig(active)
        growth = (1j*self.k[:, None]*eig).real
        if np.max(np.abs(eig.imag[self.mask])) > 1e-10 or np.max(growth[self.mask]) > 1e-9:
            raise ValueError('Consistent-fifth retained linear blocks have a growing/complex branch.')
        inverse = np.linalg.inv(vectors)
        z = dt*1j*self.k[:, None]*eig
        matrix = lambda f: np.einsum('kij,kj,kjl->kil', vectors, f, inverse)
        self.E, self.E2 = matrix(np.exp(z)), matrix(np.exp(z/2))
        self.Q = matrix(dt/2*phi(z/2, 1))
        self.f1 = matrix(dt*(phi(z, 1)-3*phi(z, 2)+4*phi(z, 3)))
        self.f2 = matrix(dt*(phi(z, 2)-2*phi(z, 3)))
        self.f3 = matrix(dt*(-phi(z, 2)+4*phi(z, 3)))
        self.linear_checks = dict(max_retained_growth=float(np.max(growth[self.mask])),
                                  max_eigenvector_condition=float(np.max(np.linalg.cond(vectors[self.mask]))))

    def nonlinear(self, h):
        h = h*self.mask
        u = np.fft.ifft(h, axis=-1).real
        ux = np.fft.ifft(h*(1j*self.k), axis=-1).real
        uxx = np.fft.ifft(-h*self.k**2, axis=-1).real
        uxxx = np.fft.ifft(h*(1j*self.k)**3, axis=-1).real
        qy = np.einsum('ipq,px,qx->ix', self.G, u, ux)
        qyh = np.fft.fft(qy, axis=-1)*self.mask
        qx = (np.einsum('ipq,px,qx->ix', self.co['R'], ux, uxx)
              - np.einsum('iqp,px,qx->ix', self.co['R'], u, uxxx))
        return (-qyh - np.fft.fft(qx, axis=-1)*self.mask
                - self.k**2*(self.co['M']@qyh))*self.mask

    def rhs(self, u):
        """Physical-grid RHS used only for independent operator checks."""
        h = self.project(u)
        linear = self.multiply(1j*self.k[:, None, None]*self.blocks, h)
        return np.fft.ifft((linear+self.nonlinear(h))*self.mask, axis=-1).real


def forward_FS(theta=(.5, .5), model='consistent5', nx=512, dt=5., N=24, Ny=1025):
    """Physical observations in original coordinates, shape (2,41,3,65).

    Axis order is layer, saved time (0:25:1000), latitude (-.5,0,.5),
    and zonal location (-320:6:64). Inputs and outputs match the old inverse map.
    """
    if model not in ('consistent5', 'third'):
        raise ValueError("model must be 'consistent5' or 'third'")
    co = coefficients(theta, N=N, Ny=Ny)
    if model == 'third':
        solver = FourierETDRK4(co['C'], co['D'], co['G'], LENGTH, nx, dt, frame_speed=0.)
    else:
        solver = ConsistentFifthETDRK4(co, LENGTH, nx, dt)
    h = solver.project(initial_profile(solver.x))
    indices = (X_SENSORS + LENGTH/2)/(LENGTH/nx)
    exact_nodes = np.max(abs(indices-np.round(indices))) < 1e-12
    stride, steps = int(round(25./dt)), int(round(DURATION/dt))
    if stride < 1 or abs(stride*dt-25.) > 1e-10 or abs(steps*dt-DURATION) > 1e-10:
        raise ValueError('dt must divide the 25-unit observation interval and 1000-unit duration.')
    snapshots = []
    for j in range(steps+1):
        if j % stride == 0:
            if exact_nodes:
                modal = np.fft.ifft(h, axis=-1).real[:, np.round(indices).astype(int)]
            else:
                modal = np.real(h@np.exp(1j*solver.k[:, None]*(X_SENSORS[None, :]+LENGTH/2)))/nx
            snapshots.append(modal)
        if j < steps:
            h = solver.step(h)
    observations = np.einsum('ljy,tjx->ltyx', co['layer'], np.array(snapshots))
    if observations.shape != OBSERVATION_SHAPE or not np.all(np.isfinite(observations)):
        raise FloatingPointError('Nonfinite or incorrectly shaped forward observations.')
    return observations


def jacobian_FS(theta=(.5, .5), model='consistent5', h=2e-5, **forward_options):
    """Two physical-parameter central differences, shape (15990,2).

    No noise weighting and no parameter scaling are applied. Each displaced
    forward solve rebuilds its coefficients, modes, gauge, and initial fields.
    The physical parameter step h may be a positive scalar or a two-vector.
    """
    theta = _theta(theta)
    steps = np.broadcast_to(np.asarray(h, dtype=float), (2,))
    if not np.all(np.isfinite(steps)) or np.any(steps <= 0):
        raise ValueError('Finite difference steps must be positive.')
    result = []
    for i in range(2):
        displacement = np.zeros(2)
        displacement[i] = steps[i]
        plus = forward_FS(theta+displacement, model=model, **forward_options)
        minus = forward_FS(theta-displacement, model=model, **forward_options)
        result.append(((plus-minus)/(2*steps[i])).ravel())
    return np.column_stack(result)


def _relative(value, reference):
    return float(np.linalg.norm(np.asarray(value)-reference)/max(np.linalg.norm(reference), 1e-300))


def _load_comparison():
    path = BRANCH/'higher_order_longwave_comparison'/'run_comparison.py'
    spec = importlib.util.spec_from_file_location('prior_fifth_order_comparison', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def self_checks(output='forward_model_self_checks.json'):
    """Meaningful operator, gauge, forward-grid and finite-difference checks."""
    started = time.perf_counter()
    comparison = _load_comparison()
    report = dict(status='running', physical_unknowns=['F', 's'], lambda_fixed=LAMBDA_FIXED,
                  observation_shape=list(OBSERVATION_SHAPE), known_modal_initial_profile=True,
                  operator_checks=[], legacy_checks=[], convergence=[], fd_step_checks=[])
    for theta in ((.5, .5), (.55, .45)):
        co = coefficients(theta)
        solver = ConsistentFifthETDRK4(co, nx=128, dt=2.5)
        x, k = solver.x, solver.k
        u = np.array([.01*np.cos(2*np.pi*x/LENGTH)+.002*np.sin(6*np.pi*x/LENGTH),
                      .006*np.sin(4*np.pi*x/LENGTH)+.001*np.cos(8*np.pi*x/LENGTH)])
        target = comparison.direct_rhs(co, k, solver.mask, 'consistent5')(u)
        rhs_error = _relative(solver.rhs(u), target)
        old_solver = comparison.HigherOrderETD(co, 2*np.pi/LENGTH, 128, 2.5, 'consistent5')
        step_error = _relative(solver.step(solver.project(u)), old_solver.step(old_solver.project(u)))
        raw = dict(co['raw'], R=co['raw_R'])
        scale = co['gauge_scale']
        gauged_raw = comparison.direct_rhs(raw, k, solver.mask, 'consistent5')(scale[:, None]*u)/scale[:, None]
        gauge_error = _relative(target, gauged_raw)
        report['operator_checks'].append(dict(theta=list(theta), rhs_relative_error=rhs_error,
                                              one_ETDRK4_step_relative_error=step_error,
                                              raw_to_reference_gauge_rhs_relative_error=gauge_error))
        assert max(rhs_error, step_error, gauge_error) < 2e-11
        current = forward_FS(theta, 'third')
        legacy = legacy_forward((*theta, LAMBDA_FIXED))
        error = _relative(current, legacy)
        report['legacy_checks'].append(dict(theta=list(theta), relative_error=error))
        assert error < 1e-12
    co0, co1 = coefficients((.5, .5)), coefficients((.55, .45))
    report['trial_coefficient_changes'] = {key: float(np.linalg.norm(co1[key]-co0[key]))
                                           for key in ('M', 'D', 'G', 'R', 'layer')}
    assert all(v > 0 for v in report['trial_coefficient_changes'].values())
    for model in ('third', 'consistent5'):
        base = forward_FS((.5, .5), model, nx=512, dt=5.)
        half = forward_FS((.5, .5), model, nx=512, dt=2.5)
        fine = forward_FS((.5, .5), model, nx=1024, dt=2.5)
        time_error, grid_error = _relative(base, half), _relative(half, fine)
        report['convergence'].append(dict(model=model, time_dt5_to_dt2p5=time_error,
                                           space_nx512_to_nx1024=grid_error))
        assert time_error < 1e-5 and grid_error < 1e-5
        j1 = jacobian_FS((.5, .5), model, h=2e-5)
        j2 = jacobian_FS((.5, .5), model, h=1e-5)
        column_error = [float(np.linalg.norm(j1[:, i]-j2[:, i])/np.linalg.norm(j2[:, i])) for i in range(2)]
        report['fd_step_checks'].append(dict(model=model, steps=[2e-5, 1e-5],
                                              relative_error=_relative(j1, j2), column_relative_errors=column_error))
        assert max(column_error) < 1e-4
        np.savez_compressed(HERE/(model+'_self_check_evidence.npz'),
                            forward_dt5=base, forward_dt2p5=half, forward_nx1024=fine,
                            jacobian_h2e5=j1, jacobian_h1e5=j2)
    report['status'] = 'passed'
    report['runtime_seconds'] = time.perf_counter()-started
    paths = [Path(__file__), ROOT/'direct_identifiability.py', ROOT/'inverse_modal_branch.py',
             ROOT/'two_mode_closure.py', ROOT/'_coeffs_strict.py', ROOT/'wave_propagation.py',
             BRANCH/'higher_order_longwave_comparison'/'run_comparison.py']
    report['source_sha256'] = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    (HERE/output).write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(self_checks(), indent=2), flush=True)
    else:
        print('Interfaces: coefficients, forward_FS, jacobian_FS; run --self-test for verification.')
