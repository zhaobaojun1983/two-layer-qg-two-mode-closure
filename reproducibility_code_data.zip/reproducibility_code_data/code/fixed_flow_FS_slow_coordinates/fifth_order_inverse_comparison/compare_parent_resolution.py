"""Compare completed parent runs on their identical physical observation grid."""
import hashlib
import json
from pathlib import Path
import numpy as np

from parent_reference import HERE, NOISE_SIGMA_REFERENCE, norm
from direct_identifiability import observation_indices


def compare(coarse_name, fine_name):
    with np.load(HERE / (coarse_name + ".npz"), allow_pickle=False) as saved:
        coarse = {key: saved[key].copy() for key in saved.files}
    with np.load(HERE / (fine_name + ".npz"), allow_pickle=False) as saved:
        fine = {key: saved[key].copy() for key in saved.files}
    for key in ("time", "x_sensors", "y_sensors"):
        if not np.array_equal(coarse[key], fine[key]):
            raise AssertionError("Observation grids differ: " + key)
    difference = fine["observations"] - coarse["observations"]
    ref = fine["observations"]
    sigma = NOISE_SIGMA_REFERENCE
    result = dict(coarse=coarse_name, fine=fine_name,
                  maximum_absolute=float(np.max(np.abs(difference))),
                  rms_absolute=float(np.sqrt(np.mean(difference**2))),
                  relative_l2=norm(difference) / norm(ref),
                  maximum_over_sigma=float(np.max(np.abs(difference))) / sigma,
                  rms_over_sigma=float(np.sqrt(np.mean(difference**2))) / sigma,
                  per_time_relative_l2=[norm(difference[:, j]) / norm(ref[:, j])
                                        for j in range(ref.shape[1])], designs={})
    for name in ("surface", "surface_deep", "surface_multiy"):
        indices = observation_indices(name)
        values = difference.ravel()[indices]
        result["designs"][name] = dict(
            count=len(indices), maximum_absolute=float(np.max(np.abs(values))),
            rms_over_sigma=float(np.sqrt(np.mean(values**2))) / sigma,
            norm_over_sigma=norm(values) / sigma,
            relative_l2=norm(values) / norm(ref.ravel()[indices]))
    information_path = HERE / "local_information.npz"
    if information_path.exists():
        result["truth_jacobian_linearized_parameter_shift"] = {}
        with np.load(information_path, allow_pickle=False) as information:
            indices = information["indices"]
            assert np.array_equal(indices, observation_indices("surface_deep"))
            values = difference.ravel()[indices]
            for model in ("third", "consistent5"):
                jacobian = information[model + "_jacobian"][indices]
                shift, _, rank, _ = np.linalg.lstsq(jacobian, values, rcond=None)
                _, singular, vh = np.linalg.svd(jacobian * .5 / sigma, full_matrices=False)
                result["truth_jacobian_linearized_parameter_shift"][model] = dict(
                    interpretation="J_truth pseudoinverse times (fine observations minus coarse observations); local estimate, not a refit",
                    delta_FS=shift.tolist(), relative_to_truth_percent=(100 * shift / .5).tolist(),
                    numerical_rank=int(rank), scaled_weak_direction=vh[-1].tolist(),
                    shift_along_scaled_weak_direction=float(vh[-1] @ (shift / .5)),
                    scaled_condition=float(singular[0] / singular[-1]),
                    unfitted_difference_norm_over_sigma=norm(values - jacobian @ shift) / sigma)
    # Sine modes share an orthogonal basis; zero padding gives the same field.
    nc, nf = coarse["initial_sine"].shape[1], fine["initial_sine"].shape[1]
    xc, xf = coarse["initial_sine"].shape[-1], fine["initial_sine"].shape[-1]
    if nf >= nc and xf % xc == 0:
        padded_initial = np.pad(coarse["initial_sine"], ((0, 0), (0, nf-nc), (0, 0)))
        result["initial_sine_max_abs_on_common_x"] = float(np.max(np.abs(
            fine["initial_sine"][..., ::xf//xc] - padded_initial)))
        padded_final = np.pad(coarse["final_sine"], ((0, 0), (0, nf-nc), (0, 0)))
        result["final_sine_relative_l2_on_common_x"] = norm(
            fine["final_sine"][..., ::xf//xc] - padded_final) / norm(fine["final_sine"][..., ::xf//xc])
    return result


if __name__ == "__main__":
    results = []
    for coarse, fine in (("parent_base", "parent_time"),
                         ("parent_time", "parent_meridional"),
                         ("parent_base", "parent_meridional"),
                         ("parent_time", "parent_zonal"),
                         ("parent_meridional", "parent_combined")):
        if all((HERE / (name + ".json")).exists() for name in (coarse, fine)):
            results.append(compare(coarse, fine))
    output = dict(reference_noise_sigma=NOISE_SIGMA_REFERENCE,
                  interpretation="Resolution differences, not rigorous absolute error bounds.",
                  comparisons=results)
    source_files = [Path(__file__), HERE / "parent_reference.py", HERE / "local_information.npz"]
    completed_names = set(row[key] for row in results for key in ("coarse", "fine"))
    source_files += [HERE / (name + extension) for name in completed_names
                     for extension in (".npz", ".json")]
    output["source_sha256"] = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                               for path in source_files if path.exists()}
    (HERE / "parent_resolution_comparison.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps([dict(coarse=row["coarse"], fine=row["fine"],
                           maximum_absolute=row["maximum_absolute"],
                           relative_l2=row["relative_l2"],
                           SD747=row["designs"]["surface_deep"],
                           parameter_shift=row.get("truth_jacobian_linearized_parameter_shift"))
                      for row in results], indent=2))
