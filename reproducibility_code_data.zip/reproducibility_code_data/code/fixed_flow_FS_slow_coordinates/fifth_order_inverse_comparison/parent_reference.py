"""Independent parent-QG data for the known-modal-initial-state inverse check.

Only the truth F=s=0.5, lambda=0.2 is evolved.  The original ParentQG
Jacobian kernel is used directly; no modal-projected field is substituted
for a parent observation.  Meridional refinement pads the SAME 24-mode
reference-gauge initial field; zonal refinement Fourier-interpolates the
SAME dealiased nx=512 initial field used by the legacy forward solver.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

for _key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_key] = "1"
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / ".local_python"))
import numpy as np

from direct_identifiability import (
    THETA, TIMES, X_SENSORS, Y_SENSORS, initial_profile,
    smooth_coefficients, forward as legacy_forward,
)
from long_time_validation import fixed_parent, step
from two_mode_closure import filter_x

PERIOD = 1024.0
INITIAL_NX = 512
NMODE = 24
COEFFICIENT_QUADRATURE = 1025
NOISE_SIGMA_REFERENCE = 9.573773981600056e-5


def norm(value):
    return float(np.linalg.norm(value))


def grid(nx):
    x = (np.arange(nx) - nx // 2) * PERIOD / nx
    wave = 2 * np.pi * np.fft.fftfreq(nx, d=PERIOD / nx)
    mask = np.abs(np.fft.fftfreq(nx) * nx) < nx / 3
    return x, wave, mask


def gauge_coefficients():
    """Keep the legacy inverse reference gauge without changing the physics."""
    smooth = smooth_coefficients(THETA, N=NMODE, Ny=COEFFICIENT_QUADRATURE)
    raw, scale = smooth["raw"], smooth["gauge_scale"]
    basis = dict(raw["basis"])
    basis["phi"] = raw["basis"]["phi"] * scale[:, None]
    basis["adjoint"] = raw["basis"]["adjoint"] / scale[:, None]
    basis["fields"] = raw["basis"]["fields"] * scale[:, None, None, None]
    co = dict(raw, basis=basis)
    for name in ("C", "D", "M", "E", "G"):
        co[name] = smooth[name]
    if "R" in raw:
        co["R"] = (raw["R"] * scale[None, :, None] *
                   scale[None, None, :] / scale[:, None, None])
    return co, smooth


def fixed_initial_amplitudes(nx):
    """Interpolate the fixed legacy initial trigonometric polynomial."""
    x0, wave0, mask0 = grid(INITIAL_NX)
    initial0 = filter_x(initial_profile(x0), mask0)
    if nx == INITIAL_NX:
        return initial0
    x, _, _ = grid(nx)
    transform = np.fft.fft(initial0, axis=-1)
    return (transform @ np.exp(1j * wave0[:, None] *
                              (x[None, :] + PERIOD / 2))).real / INITIAL_NX


def physical_observations(parent, state):
    """Evaluate psi +/- tau directly, retaining all parent sine modes."""
    sine = np.sin(np.arange(1, parent.N + 1)[:, None] * np.pi *
                  (Y_SENSORS[None, :] + 1) / 2)
    components = np.einsum("ny,cnx->cyx", sine, state)
    nx = state.shape[-1]
    indices = (X_SENSORS + PERIOD / 2) / (PERIOD / nx)
    if np.max(np.abs(indices - np.round(indices))) < 1e-12:
        sampled = components[..., np.round(indices).astype(int)]
    else:
        sampled = (np.fft.fft(components, axis=-1) @ np.exp(
            1j * parent.wave[:, None] * (X_SENSORS[None, :] + PERIOD / 2)
        )).real / nx
    return np.stack((sampled[0] + sampled[1], sampled[0] - sampled[1]))


def spectral_preflight(parent, requested_dt):
    max_frequency, max_growth = 0.0, -np.inf
    all_eigen = []
    for wave in parent.wave[parent.mask & (parent.wave >= 0)]:
        operator = (-1j * wave) * (parent.A0 - wave**2 * parent.H)
        operator = operator / (parent.b0 - wave**2)[:, None]
        eigen = np.linalg.eigvals(operator)
        all_eigen.append(eigen)
        max_frequency = max(max_frequency, float(np.abs(eigen.imag).max()))
        max_growth = max(max_growth, float(eigen.real.max()))
    eigen = np.concatenate(all_eigen)
    axis_limit = 2 * np.sqrt(2) / max_frequency
    if requested_dt is None:
        candidates = [dt for dt in (1.0, 0.5) if dt < 0.9 * axis_limit]
        if not candidates:
            raise ValueError("Neither dt=1 nor dt=0.5 passes the RK4 preflight")
        requested_dt = candidates[0]
    dt = 25.0 / int(np.ceil(25.0 / requested_dt))
    z = dt * eigen
    amplification = 1 + z + z**2 / 2 + z**3 / 6 + z**4 / 24
    checks = dict(max_linear_frequency=max_frequency,
                  max_linear_growth=max_growth,
                  rk4_imaginary_axis_limit=axis_limit,
                  actual_dt=dt,
                  max_rk4_amplification=float(np.abs(amplification).max()))
    if max_growth > 1e-9 or dt >= .95 * axis_limit:
        raise ValueError("Linear spectral RK4 precondition failed: " + str(checks))
    if checks["max_rk4_amplification"] > 1 + 1e-9:
        raise ValueError("RK4 amplification exceeds unity: " + str(checks))
    return checks


def diagnostics(parent, state):
    scale = norm(state)
    transform = np.fft.fft(state, axis=-1)
    active_max = np.max(np.abs(parent.wave[parent.mask]))
    xtail = np.abs(parent.wave) >= .75 * active_max
    retained = parent.reconstruct(parent.amplitudes(state))
    return dict(parent_sine_norm=scale,
                offspace_relative=norm(state - retained) / scale,
                x_tail_relative=norm(transform[..., xtail]) / norm(transform),
                y_tail_relative=norm(state[:, -max(2, parent.N // 4):]) / scale,
                maximum_sine_coefficient=float(np.max(np.abs(state))))


def source_hashes():
    sources = [Path(__file__), ROOT / "two_mode_closure.py",
               ROOT / "long_time_validation.py", ROOT / "direct_identifiability.py",
               ROOT / "inverse_modal_branch.py", ROOT / "_coeffs_strict.py",
               ROOT / "wave_propagation.py",
               ROOT / "traveling_wave_results/reference.npz",
               ROOT / "traveling_wave_results/reference.json"]
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sources}


def save_archive(path, state, initial, snapshots, times, records, settings):
    names = list(records[0])
    temporary = path.with_suffix(".writing.npz")
    np.savez_compressed(
        temporary, observations=np.stack(snapshots, axis=1), time=times,
        x_sensors=X_SENSORS, y_sensors=Y_SENSORS,
        initial_sine=initial, final_sine=state,
        diagnostics=np.array([[row[key] for key in names] for row in records]),
        diagnostic_names=np.array(names), settings_json=json.dumps(settings))
    temporary.replace(path)


def run(args):
    started = time.perf_counter()
    if args.N < NMODE or args.Ny <= 3 * args.N or args.nx < INITIAL_NX or args.nx % 2:
        raise ValueError("Require N>=24, Ny>3*N, and even nx>=512")
    if args.duration < 0 or args.duration > 1000 or args.duration % 25:
        raise ValueError("Duration must be a multiple of 25 between 0 and 1000")
    HERE.mkdir(exist_ok=True)
    co, smooth = gauge_coefficients()
    x, wave, mask = grid(args.nx)
    parent = fixed_parent(co, wave, mask, args.N, args.Ny)
    initial = parent.reconstruct(fixed_initial_amplitudes(args.nx))
    checks = spectral_preflight(parent, args.dt)
    checks["gauge_scale"] = smooth["gauge_scale"].tolist()
    checks["projector_identity_error"] = norm(parent.extract @ parent.phi - np.eye(2))
    checks["phi_matches_inverse_gauge"] = norm(
        co["basis"]["phi"].reshape(2, 2, NMODE) - smooth["phi"])
    initial_observation = physical_observations(parent, initial)
    legacy_t0 = legacy_forward(THETA, nx=512, dt=5., N=NMODE,
                               Ny=COEFFICIENT_QUADRATURE)[:, 0]
    checks["initial_observation_legacy_max_abs"] = float(np.max(np.abs(initial_observation - legacy_t0)))
    checks["initial_observation_legacy_relative_l2"] = norm(initial_observation - legacy_t0) / norm(legacy_t0)
    if checks["initial_observation_legacy_max_abs"] > 1e-12:
        raise AssertionError("Parent initial observations disagree with legacy forward")
    checks["parent_rhs_kernel"] = "two_mode_closure.ParentQG.rhs; direct parent nonlinear_grid Jacobians"
    setup_seconds = time.perf_counter() - started
    print("PREFLIGHT " + json.dumps(dict(checks=checks, setup_seconds=setup_seconds)), flush=True)
    if args.preflight:
        return dict(checks=checks, setup_seconds=setup_seconds)
    settings = dict(F=.5, s=.5, lam=.2, N=args.N, Ny=args.Ny, nx=args.nx,
                    dt=checks["actual_dt"], duration=args.duration, sample=25., period=PERIOD,
                    fixed_initial_nx=INITIAL_NX, Nmode=NMODE,
                    coefficient_quadrature=COEFFICIENT_QUADRATURE,
                    reference_noise_sigma=NOISE_SIGMA_REFERENCE, refinement=args.refinement)
    archive = HERE / (args.name + ".npz")
    summary_path = HERE / (args.name + ".json")
    checkpoint = HERE / (args.name + "_checkpoint.npz")
    if summary_path.exists():
        previous = json.loads(summary_path.read_text(encoding="utf-8"))
        if previous.get("settings") != settings:
            raise ValueError("Existing completed output has different settings; choose another name")
        print("ALREADY COMPLETE " + str(summary_path), flush=True)
        return previous
    state, times = initial.copy(), [0.]
    snapshots, records = [initial_observation], [diagnostics(parent, initial)]
    resumed_at = 0.0
    if args.resume and checkpoint.exists():
        with np.load(checkpoint, allow_pickle=False) as saved:
            if json.loads(str(saved["settings_json"])) != settings:
                raise ValueError("Checkpoint settings differ")
            state = saved["final_sine"].copy()
            if norm(saved["initial_sine"] - initial) > 1e-12:
                raise ValueError("Checkpoint physical initial field differs")
            times = saved["time"].tolist()
            snapshots = [saved["observations"][:, j].copy() for j in range(len(times))]
            names = saved["diagnostic_names"].tolist()
            records = [dict(zip(names, row.tolist())) for row in saved["diagnostics"]]
            resumed_at = times[-1]
    integration_started = time.perf_counter()
    steps_per_sample = int(round(25. / checks["actual_dt"]))
    for index in range(len(times), int(args.duration / 25) + 1):
        for _ in range(steps_per_sample):
            state = step(parent.rhs, state, checks["actual_dt"])
        if not np.all(np.isfinite(state)):
            raise FloatingPointError("Nonfinite parent state at t=" + str(index * 25))
        times.append(float(index * 25))
        snapshots.append(physical_observations(parent, state))
        records.append(diagnostics(parent, state))
        save_archive(checkpoint, state, initial, snapshots, times, records, settings)
        elapsed = time.perf_counter() - integration_started
        print(f"{args.name} t={times[-1]:g} offspace={records[-1]['offspace_relative']:.6g} "
              f"x_tail={records[-1]['x_tail_relative']:.3g} y_tail={records[-1]['y_tail_relative']:.3g} "
              f"integration_seconds={elapsed:.2f}", flush=True)
    save_archive(archive, state, initial, snapshots, times, records, settings)
    summary = dict(settings=settings, checks=checks, setup_seconds=setup_seconds,
                   integration_seconds=time.perf_counter() - integration_started,
                   runtime_seconds=time.perf_counter() - started, resumed_at=resumed_at,
                   observations_shape=list(np.stack(snapshots, axis=1).shape),
                   observation_peaks=np.max(np.abs(np.stack(snapshots, axis=1)), axis=(1, 2, 3)).tolist(),
                   final=records[-1], maxima={key: max(row[key] for row in records) for key in records[0]},
                   source_sha256=source_hashes(), archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("COMPLETE " + str(summary_path) + " " + json.dumps(summary), flush=True)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--name", default=None)
    parser.add_argument("--refinement", choices=("none", "time", "meridional", "zonal", "combined"), default="none")
    for name in ("N", "Ny", "nx"):
        parser.add_argument("--" + name, type=int, default=None)
    parser.add_argument("--dt", type=float, default=None)
    parser.add_argument("--duration", type=float, default=1000.)
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--resume", action="store_true")
    arguments = parser.parse_args()
    defaults = dict(N=24, Ny=129, nx=512, dt=None)
    if arguments.refinement in ("time", "meridional", "zonal", "combined"):
        defaults["dt"] = .5
    if arguments.refinement in ("meridional", "combined"):
        defaults.update(N=48, Ny=257)
    if arguments.refinement in ("zonal", "combined"):
        defaults["nx"] = 1024
    for key, value in defaults.items():
        if getattr(arguments, key) is None:
            setattr(arguments, key, value)
    if arguments.name is None:
        arguments.name = "parent_base" if arguments.refinement == "none" else "parent_" + arguments.refinement
    run(arguments)
