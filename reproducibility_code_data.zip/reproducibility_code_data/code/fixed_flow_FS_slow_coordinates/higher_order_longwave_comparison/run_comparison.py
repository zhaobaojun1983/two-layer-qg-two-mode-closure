"""Limited matched-initial-field comparison; historical manuscripts/data are read-only.

All equations use original coordinates. linear5 adds +MD a_xxxxx to the RHS;
consistent5 also adds -Qx + M dxx Qy. Slow-coordinate display uses eps=0.1.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import sys
import time

HERE = Path(__file__).resolve().parent
BRANCH = HERE.parent
ROOT = BRANCH.parent
sys.path.insert(0, str(ROOT / '.local_python'))
sys.path.insert(0, str(ROOT))
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import numpy as np
from scipy.linalg import expm
from two_mode_closure import closure_coefficients, fourier_grid, dx, filter_x, modal_nonlinearity, make_modal_rhs
from wave_propagation import FourierETDRK4, phi


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write_json(name, data):
    (HERE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def coefficients():
    return closure_coefficients(F=.5, s=.5, lam=.2, N=24, M=1025)


def source_name(k, nx):
    tag = 'k01' if k == .1 else 'k02'
    return ('baseline_' + tag) if nx == 32 else tag + '_Nx'


def case_name(k, model, nx, dt):
    return f"k{int(round(k*100)):02d}_{model}_N{nx}_dt{int(round(dt*1000)):03d}"


def load_reference(k, nx):
    stem = ROOT / 'long_time_results' / source_name(k, nx)
    meta = json.loads(stem.with_suffix('.json').read_text(encoding='utf-8'))
    with np.load(stem.with_suffix('.npz'), allow_pickle=False) as z:
        data = {key: z[key] for key in z.files}
    s = meta['settings']
    assert s['k'] == k and s['Nx'] == nx and s['Nmode'] == s['N'] == 24
    assert s['amp'] == .01 and s['ratio'] == .5 and s['F'] == s['s'] == .5 and s['lam'] == .2
    assert np.array_equal(data['time'], np.arange(601)*5.)
    return meta, data


class HigherOrderETD(FourierETDRK4):
    """Reuse the audited ETDRK4 stages, replacing only linear/nonlinear operators."""
    def __init__(self, co, k0, nx, dt, model):
        self.co, self.nx, self.dt, self.model = co, nx, dt, model
        self.length = 2*np.pi/k0
        self.x, self.k, self.mask = fourier_grid(k0, nx)
        C, D, M = (co[key] for key in ('C', 'D', 'M'))
        self.blocks = -C[None] + self.k[:,None,None]**2 * D[None]
        if model in ('linear5', 'consistent5'):
            self.blocks += self.k[:,None,None]**4 * (M@D)[None]
        elif model != 'longwave':
            raise ValueError(model)
        eig, vec = np.linalg.eig(self.blocks)
        growth = (1j*self.k[:,None]*eig).real
        assert np.max(np.abs(eig.imag[self.mask])) < 1e-10
        assert growth[self.mask].max() < 1e-9
        inv = np.linalg.inv(vec)
        z = dt*1j*self.k[:,None]*eig
        matrix = lambda f: np.einsum('kij,kj,kjl->kil', vec, f, inv)
        self.E, self.E2 = matrix(np.exp(z)), matrix(np.exp(z/2))
        self.Q = matrix(dt/2*phi(z/2,1))
        self.f1 = matrix(dt*(phi(z,1)-3*phi(z,2)+4*phi(z,3)))
        self.f2 = matrix(dt*(phi(z,2)-2*phi(z,3)))
        self.f3 = matrix(dt*(-phi(z,2)+4*phi(z,3)))
        self.linear_checks = {'retained_max_wavenumber': float(abs(self.k[self.mask]).max()),
                              'max_growth': float(growth[self.mask].max()),
                              'max_frequency': float(abs((1j*self.k[:,None]*eig).imag[self.mask]).max()),
                              'max_eigenvector_condition': float(np.linalg.cond(vec[self.mask]).max())}

    def nonlinear(self, h):
        h = h*self.mask
        u = np.fft.ifft(h, axis=-1).real
        ux = np.fft.ifft(h*(1j*self.k), axis=-1).real
        qy = np.einsum('ipq,px,qx->ix', self.co['G'], u, ux)
        qyh = np.fft.fft(qy, axis=-1)*self.mask
        value = -qyh
        if self.model == 'consistent5':
            uxx = np.fft.ifft(-h*self.k**2, axis=-1).real
            uxxx = np.fft.ifft(h*(1j*self.k)**3, axis=-1).real
            qx = (np.einsum('ipq,px,qx->ix', self.co['R'], ux, uxx)
                  - np.einsum('iqp,px,qx->ix', self.co['R'], u, uxxx))
            value -= np.fft.fft(qx, axis=-1)*self.mask
            value -= self.k**2*(self.co['M']@qyh)
        return value*self.mask


def direct_rhs(co, wave, mask, model):
    """Physical-grid implementation independent of the new Fourier nonlinear method."""
    def rhs(a):
        qy = modal_nonlinearity(a, wave, co, False)
        out = -co['C']@dx(a,wave)-co['D']@dx(a,wave,3)-qy
        if model != 'longwave':
            out += (co['M']@co['D'])@dx(a,wave,5)
        if model == 'consistent5':
            qx = modal_nonlinearity(a,wave,co,True)-qy
            out += -qx+co['M']@dx(qy,wave,2)
        return filter_x(out,mask)
    return rhs


def rk4(rhs, a, duration, dt):
    a = a.copy()
    for _ in range(round(duration/dt)):
        v1=rhs(a); v2=rhs(a+dt*v1/2); v3=rhs(a+dt*v2/2); v4=rhs(a+dt*v3)
        a += dt*(v1+2*v2+2*v3+v4)/6
    return a


def preflight():
    co = coefficients()
    protected = [ROOT/'two_mode_closure.py', ROOT/'_coeffs_strict.py', ROOT/'wave_propagation.py']
    for k in (.1,.2):
        for nx in (32,64):
            protected += [ROOT/'long_time_results'/(source_name(k,nx)+ext) for ext in ('.npz','.json')]
    protected += list(BRANCH.glob('two_layer_model_fixed_flow_FS*.tex'))
    protected += list(BRANCH.glob('two_layer_model_fixed_flow_FS*.pdf'))
    protected += list(ROOT.glob('two_layer_model_two_mode_closure*.tex'))
    protected += list(ROOT.glob('two_layer_model_two_mode_closure*.pdf'))
    manifest_path = HERE/'experiment_manifest.json'
    if manifest_path.exists():
        prior=json.loads(manifest_path.read_text(encoding='utf-8'))
        assert all(sha(Path(p)) == s for p,s in prior['protected_sha256'].items())
    else:
        write_json('experiment_manifest.json', {'scope':'Two higher-order fixed-mode models, k=0.2 primary and k=0.1 control; no manuscript edits or parent-QG reruns.',
            'fixed_inputs':{'F':.5,'s':.5,'lambda':.2,'Um':.15,'Uj':.4,'w':.65,'beta':1.,'L':1.},
            'initial':{'amplitude':.01,'ratio':.5,'phase':float(np.pi/2)},
            'coordinates':'Integration uses original x,t; display X=0.1x,T=0.001t.',
            'duration':3000.,'sample':5.,'Nmode':24,'quadrature':1025,
            'primary_metric':'Unaligned combined psi/tau relative L2 field error against saved parent at each time.',
            'baseline':{'Nx':32,'dt':.2},'time_check':{'Nx':32,'dt':.1},'space_check':{'Nx':64,'dt':.1},
            'protected_sha256':{str(p.resolve()):sha(p) for p in protected}})
    write_json('coefficients.json',{key:co[key].tolist() for key in ('C','M','E','D','G','R')})
    records=[]
    for k in (.1,.2):
        for nx in (32,64):
            _,ref=load_reference(k,nx)
            phi_error=float(abs(co['basis']['phi'].T-ref['phi']).max())
            assert phi_error < 1e-13
            for model in ('linear5','consistent5'):
                solver=HigherOrderETD(co,k,nx,.2,model)
                initial=ref['initial_amplitudes']
                analytic=np.array([.01*np.cos(k*solver.x),.005*np.cos(k*solver.x-np.pi/2)])
                assert np.max(abs(initial-analytic)) < 1e-16
                # Include higher harmonics to expose derivative and aliasing errors.
                a=initial+np.array([.001*np.cos(3*k*solver.x),.0007*np.sin(4*k*solver.x)])
                h=solver.project(a)
                fourier=solver.multiply(1j*solver.k[:,None,None]*solver.blocks,h)+solver.nonlinear(h)
                rhs=direct_rhs(co,solver.k,solver.mask,model)
                rhs_diff=float(np.linalg.norm(np.fft.ifft(fourier,axis=-1).real-rhs(a)))
                assert rhs_diff < 1e-12
                exact_err=max(float(np.max(abs(solver.E[m]-expm(.2j*solver.k[m]*solver.blocks[m]))))
                              for m in np.flatnonzero(solver.mask))
                assert exact_err < 1e-11
                rec={'k':k,'nx':nx,'model':model,'phi_max_abs_difference':phi_error,
                     'fourier_vs_direct_rhs_absolute_difference':rhs_diff,
                     'linear_expm_max_abs_difference':exact_err,**solver.linear_checks}
                if nx==32:
                    reference=rk4(rhs,initial,20.,.01)
                    h=solver.project(initial)
                    for _ in range(100): h=solver.step(h)
                    actual=np.fft.ifft(h,axis=-1).real
                    rec['ETD_vs_independent_RK4_short_relative_field_error']=float(np.linalg.norm(ref['phi']@(actual-reference))/np.linalg.norm(ref['phi']@reference))
                    assert rec['ETD_vs_independent_RK4_short_relative_field_error'] < 1e-7
                records.append(rec)
    # Verify formal residual-order improvement at fixed amplitude and varying k.
    rows=[]
    for k in (.2,.1,.05):
        x,wave,mask=fourier_grid(k,32)
        a=np.array([.01*np.cos(k*x),.005*np.sin(k*x)])
        full=make_modal_rhs(co,wave,mask,True)
        zero=dict(co,G=np.zeros_like(co['G']),R=np.zeros_like(co['R']))
        full_linear=make_modal_rhs(zero,wave,mask,True)
        new=direct_rhs(co,wave,mask,'consistent5')
        new_linear=direct_rhs(zero,wave,mask,'consistent5')
        lin=np.linalg.norm(full_linear(a)-new_linear(a))
        nonlin=np.linalg.norm((full(a)-full_linear(a))-(new(a)-new_linear(a)))
        rows.append({'k':k,'linear_rhs_difference':float(lin),'nonlinear_rhs_difference':float(nonlin)})
    orders=[{'linear':float(np.log2(a['linear_rhs_difference']/b['linear_rhs_difference'])),
             'nonlinear':float(np.log2(a['nonlinear_rhs_difference']/b['nonlinear_rhs_difference']))}
            for a,b in zip(rows[:-1],rows[1:])]
    assert min(x['linear'] for x in orders)>6.8 and min(x['nonlinear'] for x in orders)>4.8
    write_json('preflight_checks.json',{'status':'passed','checks':records,'higher_order_rhs_scaling':rows,'observed_orders':orders})
    print(json.dumps({'preflight':'passed','checks':len(records),'observed_orders':orders}),flush=True)


def run(k, model, nx, dt):
    name=case_name(k,model,nx,dt)
    meta_file=HERE/(name+'.json')
    if meta_file.exists():
        meta=json.loads(meta_file.read_text(encoding='utf-8'))
        assert meta['runner_sha256']==sha(__file__), 'Do not reuse a result generated by a different runner.'
        print(name+' already complete',flush=True)
        return
    co=coefficients()
    _,ref=load_reference(k,nx)
    assert np.max(abs(ref['phi']-co['basis']['phi'].T))<1e-13
    solver=HigherOrderETD(co,k,nx,dt,model)
    h=solver.project(ref['initial_amplitudes'])
    stride=round(5/dt)
    assert abs(stride*dt-5)<1e-12
    profiles=[]; errors=[]; to_full=[]; tails=[]
    started=time.perf_counter()
    for ti in range(601):
        a=np.fft.ifft(h,axis=-1).real
        assert np.all(np.isfinite(a)), (name,ti)
        assert np.max(abs(a)) < .2, ('Unexpected amplitude growth',name,ti)
        field=ref['phi']@a
        parent=ref['parent'][ti].reshape(48,nx)
        denom=np.linalg.norm(parent)
        profiles.append(a)
        errors.append(np.linalg.norm(field-parent)/denom)
        to_full.append(np.linalg.norm(field-ref['phi']@ref['full'][ti])/denom)
        tail=(abs(solver.k)>=.75*max(abs(solver.k[solver.mask]))) & solver.mask
        tails.append(np.linalg.norm(ref['phi']@h[:,tail])/np.linalg.norm(ref['phi']@h))
        if ti and ti%100==0:
            print(f'{name} t={ti*5}: error={100*errors[-1]:.6f}% ({time.perf_counter()-started:.1f}s)',flush=True)
        if ti<600:
            for _ in range(stride): h=solver.step(h)
    arrays={'time':ref['time'],'x':solver.x,'amplitudes':np.array(profiles),'relative_error':np.array(errors),
            'relative_to_full':np.array(to_full),'x_tail':np.array(tails),'phi':ref['phi']}
    np.savez_compressed(HERE/(name+'.npz'),**arrays)
    meta={'name':name,'model':model,'settings':{'k':k,'Nx':nx,'dt':dt,'duration':3000.,'sample':5.,'Nmode':24,'quadrature':1025},
          'linear_checks':solver.linear_checks,'max_error':float(max(errors)),'max_error_time':float(ref['time'][np.argmax(errors)]),
          'final_error':float(errors[-1]),'max_relative_to_full':float(max(to_full)),'final_relative_to_full':float(to_full[-1]),
          'max_x_tail':float(max(tails)),'initial_relative_error':float(errors[0]),
          'runtime_seconds':time.perf_counter()-started,'runner_sha256':sha(__file__),
          'source_sha256':{str(ROOT/'long_time_results'/(source_name(k,nx)+ext)):sha(ROOT/'long_time_results'/(source_name(k,nx)+ext)) for ext in ('.npz','.json')},
          'array_sha256':sha(HERE/(name+'.npz'))}
    if model=='longwave':
        f=np.einsum('ij,tjx->tix',ref['phi'],arrays['amplitudes']-ref['longwave'])
        denominator=np.linalg.norm(np.einsum('ij,tjx->tix',ref['phi'],ref['longwave']).reshape(601,-1),axis=1)
        meta['max_ETD_vs_saved_RK4_relative_field_difference']=float(max(np.linalg.norm(f.reshape(601,-1),axis=1)/denominator))
        assert meta['max_ETD_vs_saved_RK4_relative_field_difference']<1e-6
    write_json(name+'.json',meta)
    print(json.dumps({key:meta[key] for key in ('name','max_error','final_error','max_x_tail','runtime_seconds')}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--preflight',action='store_true')
    p.add_argument('--k',type=float,choices=(.1,.2),default=.2)
    p.add_argument('--model',choices=('longwave','linear5','consistent5'),default='consistent5')
    p.add_argument('--nx',type=int,choices=(32,64),default=32)
    p.add_argument('--dt',type=float,default=.2)
    args=p.parse_args()
    if args.preflight: preflight()
    else: run(args.k,args.model,args.nx,args.dt)
