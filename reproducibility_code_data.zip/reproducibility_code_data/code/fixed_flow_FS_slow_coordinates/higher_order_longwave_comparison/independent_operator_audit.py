"""Independent algebra/coordinate audit; no PDE evolution is performed."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import hashlib
import json
import numpy as np
from run_comparison import HigherOrderETD, coefficients, load_reference

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def scalar_rhs(co, derivatives, model, epsilon=None):
    """Literal scalar-index equations and analytic derivatives, no FFT products."""
    cscale = 1.0 if epsilon is None else epsilon**-2
    correction = 1.0 if epsilon is None else epsilon**2
    result = np.zeros_like(derivatives[0])
    for i in range(2):
        result[i] -= cscale * co['C'][i, i] * derivatives[1][i]
        for j in range(2):
            result[i] -= co['D'][i, j] * derivatives[3][j]
        for p in range(2):
            for q in range(2):
                result[i] -= co['G'][i, p, q] * derivatives[0][p] * derivatives[1][q]
        if model != 'longwave':
            for j in range(2):
                for p in range(2):
                    result[i] += correction * co['M'][i, j] * co['D'][j, p] * derivatives[5][p]
        if model == 'consistent5':
            for p in range(2):
                for q in range(2):
                    result[i] -= correction * co['R'][i, p, q] * derivatives[1][p] * derivatives[2][q]
                    result[i] += correction * co['R'][i, q, p] * derivatives[0][p] * derivatives[3][q]
                    for j in range(2):
                        result[i] += correction * co['M'][i, j] * co['G'][j, p, q] * (
                            derivatives[2][p] * derivatives[1][q]
                            + 2 * derivatives[1][p] * derivatives[2][q]
                            + derivatives[0][p] * derivatives[3][q])
    return result


def main():
    manifest = json.loads((HERE / 'experiment_manifest.json').read_text(encoding='utf-8'))
    protected = {p: digest(p) == recorded for p, recorded in manifest['protected_sha256'].items()}
    assert all(protected.values())
    co = coefficients()
    assert np.max(abs(co['D'] - (co['E'] - co['M'] @ co['C']))) < 1e-14
    rows = []
    for k0 in (.1, .2):
        for nx in (32, 64):
            _, reference = load_reference(k0, nx)
            x = np.arange(nx) * (2*np.pi/k0) / nx
            largest = max(np.flatnonzero(np.arange(nx) < nx/3))
            # Exact trigonometric derivatives include near-cutoff harmonics.
            components = [
                [(.01, 1, 0.), (.0013, 3, .41), (1e-6, largest-1, .7)],
                [(.005, 1, -np.pi/2), (.0009, 4, .33), (1.2e-6, largest, -.2)],
            ]
            derivatives = []
            for n in range(6):
                derivatives.append(np.array([
                    sum(amplitude*(harmonic*k0)**n*np.cos(harmonic*k0*x+phase+n*np.pi/2)
                        for amplitude, harmonic, phase in terms)
                    for terms in components]))
            for model in ('longwave', 'linear5', 'consistent5'):
                solver = HigherOrderETD(co, k0, nx, .1, model)
                assert np.array_equal(solver.x, x)
                initial = np.array([.01*np.cos(k0*x), .005*np.cos(k0*x-np.pi/2)])
                initial_error = float(np.max(abs(initial-reference['initial_amplitudes'])))
                assert initial_error < 1e-16
                h = solver.project(derivatives[0])
                production = solver.multiply(1j*solver.k[:, None, None]*solver.blocks, h) + solver.nonlinear(h)
                expected = np.fft.fft(scalar_rhs(co, derivatives, model), axis=-1) * solver.mask
                difference = float(np.max(abs(production-expected)))
                assert difference < 2e-11, (k0, nx, model, difference)
                eps = .1
                slow_derivatives = [a / eps**(n+2) for n, a in enumerate(derivatives)]
                slow = eps**5 * scalar_rhs(co, slow_derivatives, model, epsilon=eps)
                coordinate_error = float(np.max(abs(slow-scalar_rhs(co, derivatives, model))))
                assert coordinate_error < 2e-13
                # Only Q_y can change the periodic modal mean at this order.
                mean_addition = np.mean(scalar_rhs(co, derivatives, model)
                                        - scalar_rhs(co, derivatives, 'longwave'), axis=-1)
                assert np.max(abs(mean_addition)) < 2e-14
                rows.append(dict(k=k0, Nx=nx, model=model,
                                 analytic_scalar_vs_Fourier_max_abs=difference,
                                 original_vs_slow_rhs_max_abs=coordinate_error,
                                 initial_state_max_abs=initial_error,
                                 correction_mean_max_abs=float(np.max(abs(mean_addition)))))
    preflight = json.loads((HERE / 'preflight_checks.json').read_text(encoding='utf-8'))
    assert preflight['status'] == 'passed'
    result = dict(status='passed', checks=rows,
                  method='Analytic trigonometric derivatives and direct scalar-index summation; no call to production direct_rhs or modal_nonlinearity; no PDE time integration.',
                  noncommutative_MD_minus_DM_norm=float(np.linalg.norm(co['M']@co['D']-co['D']@co['M'])),
                  protected_files=len(protected), all_protected_hashes_unchanged=all(protected.values()),
                  runner_sha256=digest(HERE / 'run_comparison.py'),
                  audit_script_sha256=digest(__file__),
                  preflight_sha256=digest(HERE / 'preflight_checks.json'))
    (HERE / 'independent_operator_audit.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('status', 'protected_files', 'all_protected_hashes_unchanged', 'runner_sha256')}))
    print('checks', len(rows), 'worst_operator_error', max(r['analytic_scalar_vs_Fourier_max_abs'] for r in rows))


if __name__ == '__main__':
    main()
