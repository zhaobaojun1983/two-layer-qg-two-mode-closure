"""Fifth-order manuscript comparison from saved trajectories; no PDE integration."""
from pathlib import Path
import csv
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
EXPERIMENT = HERE.parent / 'higher_order_longwave_comparison'
sys.path.insert(0, str(ROOT / '.local_python'))
import numpy as np
from scipy.signal import resample
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

EPS = .1
MODELS = ('consistent5', 'full')
LABELS = {'consistent5': 'Consistent fifth order',
          'full': 'Full projection'}
COLORS = {'consistent5': '#D55E00', 'full': '#7A5195'}
STYLES = {'consistent5': '-',
          'full': (0, (5, 1.5, 1, 1.5))}


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save_json(name, obj):
    (HERE/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def save_csv(name, rows):
    with (HERE/name).open('w', newline='', encoding='utf-8-sig') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def load(path):
    with np.load(path, allow_pickle=False) as source:
        return {key: source[key] for key in source.files}


def build_source_data():
    data, arrays, curves_rows, waveform_rows, summaries, checks, sources = {}, {}, [], [], [], [], {}
    arrays['models'] = np.array(MODELS, dtype='U16')
    arrays['wavenumbers'] = np.array([.1, .2])
    for k in (.1, .2):
        tag = f'k{round(k*100):02d}'
        parent_path = ROOT/'long_time_results'/('baseline_k01.npz' if k == .1 else 'baseline_k02.npz')
        next_path = EXPERIMENT/(tag+'_consistent5_N32_dt200.npz')
        ref, higher = load(parent_path), load(next_path)
        sources[str(parent_path.relative_to(ROOT))] = sha(parent_path)
        sources[str(next_path.relative_to(ROOT))] = sha(next_path)
        assert np.array_equal(ref['time'], higher['time'])
        assert np.max(abs(ref['phi']-higher['phi'])) < 1e-13
        parent = ref['parent'].reshape(601, 48, 32)
        denominator = np.linalg.norm(parent.reshape(601, -1), axis=1)
        centre_sine = np.zeros(24)
        centre_sine[::2] = (-1.)**np.arange(12)

        def upper(field):
            return np.einsum('n,nx->x', centre_sine, field[:24]+field[24:])

        curves, waves = {}, {}
        for model in MODELS:
            amplitude = higher['amplitudes'] if model == 'consistent5' else ref[model]
            field = np.einsum('ij,tjx->tix', ref['phi'], amplitude)
            error = np.linalg.norm((field-parent).reshape(601, -1), axis=1)/denominator
            saved = higher['relative_error'] if model == 'consistent5' else ref[model+'_error']
            diff = float(np.max(abs(error-saved)))
            assert diff < 2e-13
            checks.append({'k':k, 'model':model, 'recomputed_vs_saved_error_max_difference':diff})
            curves[model], waves[model] = error, upper(field[-1])
            summaries.append({'k':k, 'model':model, 'final_relative_error':float(error[-1]),
                              'sampled_max_relative_error':float(error.max()),
                              'sampled_max_slow_time':float(EPS**3*ref['time'][error.argmax()])})
            for ti, err in zip(ref['time'], error):
                curves_rows.append({'k':k,'model':model,'original_time':float(ti),
                                    'slow_time':float(EPS**3*ti),'unaligned_relative_error':float(err)})
        x = np.arange(32)*(2*np.pi/k)/32
        parent_wave = upper(parent[-1])
        data[k] = {'time':EPS**3*ref['time'], 'curves':curves,
                   'x':EPS*x, 'parent':parent_wave, 'models':waves}
        arrays.update({tag+'_original_time':ref['time'], tag+'_slow_time':EPS**3*ref['time'],
                       tag+'_original_x':x, tag+'_slow_X':EPS*x,
                       tag+'_unaligned_errors':np.array([curves[m] for m in MODELS]),
                       tag+'_parent_upper_y0':parent_wave,
                       tag+'_model_upper_y0':np.array([waves[m] for m in MODELS])})
        for i, xi in enumerate(x):
            waveform_rows.append({'k':k, 'original_x':float(xi),'slow_X':float(EPS*xi),
                                  'parent_upper_y0':float(parent_wave[i]),
                                  **{m+'_upper_y0':float(waves[m][i]) for m in MODELS}})
    np.savez_compressed(HERE/'next_order_parent_comparison_source.npz', **arrays)
    save_csv('next_order_parent_comparison_errors.csv', curves_rows)
    save_csv('next_order_parent_comparison_waveforms.csv', waveform_rows)
    save_csv('next_order_parent_comparison_summary.csv', summaries)
    save_json('source_provenance.json', {'source_sha256':sources, 'checks':checks, 'summary':summaries,
              'norm':'Combined psi/tau physical L2 norm via orthogonal sine coefficients; no phase alignment.',
              'model_order':list(MODELS), 'complete_next_order_key':'consistent5',
              'waveform':'Upper-layer psi+tau at y=0, original time t=3000, plotted against X=0.1*x.',
              'script_sha256':sha(__file__)})
    return data


def figure(data):
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
                         'font.size':7,'axes.titlesize':8,'axes.labelsize':7,
                         'xtick.labelsize':6.5,'ytick.labelsize':6.5,
                         'axes.spines.right':False,'axes.spines.top':False,
                         'axes.linewidth':.65,'xtick.major.width':.65,'ytick.major.width':.65,
                         'svg.fonttype':'none','pdf.fonttype':42,'legend.frameon':False})
    fig, axs = plt.subplots(2, 2, figsize=(183/25.4,155/25.4))
    fig.subplots_adjust(left=.11,right=.985,bottom=.14,top=.925,wspace=.28,hspace=.49)
    magnitude = max(np.max(abs(v)) for d in data.values() for v in [d['parent'], *d['models'].values()])
    annotations = []
    for col,k in enumerate((.1,.2)):
        d=data[k]
        ax=axs[0,col]
        for model in MODELS:
            ax.plot(d['time'],100*d['curves'][model],color=COLORS[model],linestyle=STYLES[model],lw=1.15)
        ax.set(xlim=(0,3),xlabel=r'Slow time $T$',ylabel='Relative field error (%)',
               title=rf'$k={k:.1f}$: unaligned field error')
        ax.set_ylim(bottom=0)
        ax.grid(axis='y',color='#dedede',linewidth=.4)
        annotations.append(ax.text(-.16,1.055,'ab'[col],transform=ax.transAxes,fontsize=9,weight='bold'))
        ax=axs[1,col]
        length=EPS*2*np.pi/k
        dense=np.linspace(0,length,257)
        for model in MODELS:
            wave=resample(d['models'][model],256)
            ax.plot(dense,100*np.r_[wave,wave[0]],color=COLORS[model],linestyle=STYLES[model],lw=1.1)
        ax.plot(np.r_[d['x'],length],100*np.r_[d['parent'],d['parent'][0]],linestyle='none',
                marker='o',markersize=3,markerfacecolor='white',markeredgecolor='#202020',
                markeredgewidth=.65,zorder=8)
        ax.axhline(0,color='#bbbbbb',lw=.45,zorder=0)
        ax.set(xlim=(0,length),ylim=(-112*magnitude,112*magnitude),xlabel=r'Slow coordinate $X$',
               ylabel=r'Upper-layer $10^2\psi_{1,r}^\prime$',title=rf'$k={k:.1f}$: final waveform, $T=3$')
        ax.set_xticks(np.arange(0,np.floor(length)+1))
        annotations.append(ax.text(-.16,1.055,'cd'[col],transform=ax.transAxes,fontsize=9,weight='bold'))
    handles=[Line2D([],[],color=COLORS[m],linestyle=STYLES[m],lw=1.3,label=LABELS[m]) for m in MODELS]
    handles.append(Line2D([],[],color='#202020',linestyle='none',marker='o',markerfacecolor='white',
                          markersize=3,markeredgewidth=.65,label='Parent QG (samples)'))
    legend=fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.54,.025),ncol=3,
                      fontsize=7,handlelength=2.6,columnspacing=2.2)
    note=fig.text(.55,.965,'Error panels use different vertical scales; waveform panels share one scale.',ha='center',fontsize=6.6)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    overflow=[]
    for text in [*annotations,note,*legend.get_texts(),*[t for ax in axs.ravel() for t in
                [ax.title,ax.xaxis.label,ax.yaxis.label,*ax.get_xticklabels(),*ax.get_yticklabels()]]]:
        if not text.get_visible() or not text.get_text():continue
        box=text.get_window_extent(renderer)
        if box.x0 < fig.bbox.x0-1 or box.x1 > fig.bbox.x1+1 or box.y0 < fig.bbox.y0-1 or box.y1 > fig.bbox.y1+1:
            overflow.append(text.get_text())
    assert not overflow,overflow
    stem=HERE/'next_order_parent_comparison'
    for ext in ('pdf','svg','png','tiff'):
        options={'dpi':600} if ext in ('png','tiff') else {}
        if ext=='tiff':options['pil_kwargs']={'compression':'tiff_lzw'}
        fig.savefig(stem.with_suffix('.'+ext),**options)
    fig.savefig(HERE/'next_order_parent_comparison_preview.png',dpi=180)
    plt.close(fig)
    save_json('figure_qa.json',{'backend':'Python/matplotlib','status':'awaiting_visual_review',
              'dimensions_mm':[183,155],'raster_dpi':600,'text_outside_figure':overflow,
              'model_legend_entries':[LABELS[m] for m in MODELS],
              'svg_fonttype':'none','pdf_fonttype':42,
              'exports_sha256':{ext:sha(stem.with_suffix('.'+ext)) for ext in ('pdf','svg','png','tiff')}})


if __name__=='__main__':
    protected_before={str(p.relative_to(EXPERIMENT)):sha(p) for p in EXPERIMENT.rglob('*') if p.is_file()}
    data=build_source_data()
    figure(data)
    caption=('Parent-equation comparison for the consistent fifth-order approximation '
             '(complete next-order truncation) and the full fixed-mode projection '
             'at F=s=0.5. (a,b) Unaligned combined physical-field relative L2 errors for k=0.1 and '
             'k=0.2, respectively, with T=epsilon^3 t and epsilon=0.1. The error panels use different '
             'vertical scales. (c,d) Upper-layer perturbation streamfunctions at y=0 and t=3000 '
             '(T=3), displayed against X=epsilon x. Parent-QG fields are shown at saved grid points; '
             'model curves use periodic Fourier interpolation for display. Both waveform panels '
             'share the same physical-amplitude scale and retain the original phase. Each curve '
             'is one deterministic trajectory with the same initial physical field.\n')
    (HERE/'next_order_parent_comparison_caption.txt').write_text(caption,encoding='utf-8')
    protected_after={str(p.relative_to(EXPERIMENT)):sha(p) for p in EXPERIMENT.rglob('*') if p.is_file()}
    assert protected_before==protected_after,'Original experiment directory changed during figure generation.'
    save_json('preserved_experiment.json',{'unchanged':True,'file_count':len(protected_before),
                                         'sha256':protected_after})
    print(json.dumps({'status':'generated','models':list(MODELS),'protected_files':len(protected_after)}))
