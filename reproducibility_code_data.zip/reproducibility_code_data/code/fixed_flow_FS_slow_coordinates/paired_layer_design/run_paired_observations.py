"""Limited, reproducible paired-layer F,s design experiment; no manuscript edits.

prepare: freeze three layouts, truth, local information, and 21 noise fields.
run:     resume 9 seed-101 multistarts plus 60 fits on 20 fresh noise seeds.
summary: summarize all checkpoints, including failures and boundary hits.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time

for _variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_variable] = "1"
sys.dont_write_bytecode = True
import numpy as np

HERE = Path(__file__).resolve().parent
BRANCH = HERE.parent
ROOT = BRANCH.parent
INPUT = BRANCH / "noisy_fs_results"
OUT = HERE / "results"
sys.path.insert(0, str(ROOT))
from direct_identifiability import fit, forward, X_SENSORS, TIMES, Y_SENSORS
import _coeffs_strict as physics
import scipy

TRUTH = np.array([0.5, 0.5])
SCALE = np.array([0.5, 0.5])
STARTS = ((0.35, 0.40), (0.75, 0.60), (0.55, 0.45))
FRESH_SEEDS = tuple(range(2001, 2021))
DESIGNS = (
    ("S", (0,), (1,), 33, 21),
    ("P1", (0, 1), (1,), 23, 15),
    ("P3", (0, 1), (0, 1, 2), 11, 10),
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def information(raw, idx, sigma):
    jac = raw[idx, :2] / sigma
    scaled = jac * SCALE
    _, singular, vh = np.linalg.svd(scaled, full_matrices=False)
    cov = ((vh.T / singular**2) @ vh) * SCALE[:, None] * SCALE[None, :]
    sd = np.sqrt(np.diag(cov))
    residual_s = jac[:, 1] - jac[:, 0] * np.dot(jac[:, 0], jac[:, 1]) / np.dot(jac[:, 0], jac[:, 0])
    conditional = float(residual_s @ residual_s)
    assert abs(1 / np.sqrt(conditional) - sd[1]) < 1e-10
    weak = vh[-1].copy()
    if weak[1] < 0:
        weak *= -1
    return dict(observation_count=len(idx), singular_values=singular.tolist(),
                condition=float(singular[0] / singular[1]),
                local_sd_FS=sd.tolist(), covariance_FS=cov.tolist(),
                parameter_correlation=float(cov[0, 1] / (sd[0] * sd[1])),
                sensitivity_cosine=float(np.dot(jac[:, 0], jac[:, 1]) /
                                         (np.linalg.norm(jac[:, 0]) * np.linalg.norm(jac[:, 1]))),
                conditional_information_s_given_free_F=conditional,
                weak_scaled_direction=weak.tolist())


def verify(manifest):
    for name, expected in manifest["protected_hashes"].items():
        if sha(name) != expected:
            raise RuntimeError(f"Protected input changed: {name}")
    if sha(__file__) != manifest["driver_sha256"]:
        raise RuntimeError("Driver changed after preparation.")
    if sha(OUT / "datasets.npz") != manifest["datasets_sha256"]:
        raise RuntimeError("Prepared datasets changed.")


def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    manifest_path = OUT / "manifest.json"
    if manifest_path.exists():
        manifest = read(manifest_path)
        verify(manifest)
        return manifest
    if (OUT / "datasets.npz").exists():
        raise FileExistsError("Inspect partial preparation before rerunning.")
    assert (physics.UM, physics.UJ, physics.W, physics.L, physics.BETA) == (.15, .4, .65, 1., 1.)
    saved_info = read(INPUT / "local_information.json")
    for name, expected in saved_info["source_sha256"].items():
        assert sha(name) == expected, name
    with np.load(INPUT / "shared_data.npz", allow_pickle=False) as z:
        truth = z["truth"].copy()
        sigma = float(z["sigma"])
        original_noise = z["standard_normal_noise"].copy()
        s_indices = z["S_indices"].copy()
    with np.load(INPUT / "local_information.npz", allow_pickle=False) as z:
        raw = z["raw_jacobian_six_columns"].copy()
        assert np.allclose(truth, z["truth_full"], rtol=1e-12, atol=1e-15)
    assert truth.shape == (2, 41, 3, 65)
    assert np.array_equal(original_noise, np.random.default_rng(101).normal(size=truth.size))
    assert np.isclose(sigma, .01 * np.max(np.abs(truth[0])), rtol=1e-14)
    arrays = dict(truth=truth, sigma=np.array(sigma), raw_jacobian_FS=raw[:, :2],
                  truth_FS=TRUTH, x_master=X_SENSORS, t_master=TIMES, y_master=Y_SENSORS,
                  seeds=np.array((101,) + FRESH_SEEDS))
    for seed in (101,) + FRESH_SEEDS:
        arrays[f"noise_{seed}"] = np.random.default_rng(seed).normal(size=truth.size)
    grid = np.arange(truth.size).reshape(truth.shape)
    designs, local = [], {}
    for label, layers, ys, nx, nt in DESIGNS:
        xi = np.rint(np.linspace(0, 64, nx)).astype(int)
        ti = np.rint(np.linspace(0, 40, nt)).astype(int)
        idx = np.concatenate([grid[layer][np.ix_(ti, ys, xi)].ravel() for layer in layers])
        assert len(np.unique(idx)) == len(idx) == len(layers) * len(ys) * nx * nt
        if len(layers) == 2:
            assert np.array_equal(idx[:len(idx)//2] + truth.size//2, idx[len(idx)//2:])
        if label == "S":
            assert np.array_equal(idx, s_indices)
        arrays[f"{label}_indices"] = idx
        arrays[f"{label}_x_indices"] = xi
        arrays[f"{label}_t_indices"] = ti
        designs.append(dict(label=label, layers=list(layers), y=Y_SENSORS[list(ys)].tolist(),
                            nx=nx, nt=nt, observation_count=len(idx),
                            x_values=X_SENSORS[xi].tolist(), t_values=TIMES[ti].tolist(),
                            x_spacings=np.unique(np.diff(X_SENSORS[xi])).tolist(),
                            t_spacings=np.unique(np.diff(TIMES[ti])).tolist()))
        local[label] = information(raw, idx, sigma)
    # Existing upper-only three-latitude control, local information only.
    xi = np.rint(np.linspace(0, 64, 11)).astype(int)
    ti = np.arange(0, 41, 2)
    idx = grid[0][np.ix_(ti, (0, 1, 2), xi)].ravel()
    assert len(idx) == 693
    local["MY_local_only"] = information(raw, idx, sigma)
    # Additional exact-budget local control: upper-only, 22 x sites, 10 times,
    # 3 y. Relative to P3, pairing changes both layer and x allocation.
    xi22 = np.rint(np.linspace(0, 64, 22)).astype(int)
    ti10 = np.rint(np.linspace(0, 40, 10)).astype(int)
    upper3 = grid[0][np.ix_(ti10, (0, 1, 2), xi22)].ravel()
    local["U3_660_local_only"] = information(raw, upper3, sigma)
    arrays["U3_660_indices"] = upper3
    protected = {str(Path(p)): h for p, h in saved_info["source_sha256"].items()}
    for name in ("shared_data.npz", "local_information.npz", "local_information.json"):
        protected[str(INPUT / name)] = sha(INPUT / name)
    # Freeze every existing LaTeX source in this manuscript branch.
    for path in BRANCH.rglob("*.tex"):
        protected[str(path)] = sha(path)
    np.savez_compressed(OUT / "datasets.npz", **arrays)
    manifest = dict(status="prepared", protocol_date="2026-11-19", truth_FS=TRUTH.tolist(),
        fixed_background=dict(Um=.15, Uj=.4, w=.65, lambda_fixed=.20, beta=1., L=1.),
        initial_state="Known reference-normalized modal initial state, all four template variables zero.",
        forward_model="Third-order closure; same parameter-dependent modes and layer reconstruction as manuscript.",
        noise_model="Independent Gaussian errors across observations and layers, common fixed absolute sigma. Same full noise field shared across layouts within each seed.",
        sigma=sigma, noise_fraction_upper_peak=.01, designs=designs,
        pilot_seed=101, pilot_starts_FS=STARTS, fresh_seeds=FRESH_SEEDS,
        fresh_start_FS=STARTS[2], planned_fit_count=69,
        optimizer=dict(max_nfev=70, bounds_FS=[[.25, .30], [.90, .70]],
                       ftol=2e-8, xtol=2e-8, gtol=1e-6),
        environment=dict(python=sys.version, numpy=np.__version__, scipy=scipy.__version__, platform=platform.platform()),
        limitations=["Near-equal scalar observation counts, not equal instrument/deployment costs.",
                     "Layouts selected using truth-point sensitivities and earlier seed-101 pilot; seeds 2001--2020 are fresh evaluation noise.",
                     "Twenty replicates provide a limited conditional numerical comparison, not global identifiability or real-data validation.",
                     "Rounded master-grid selections can have nonuniform spacings; exact coordinates are saved."],
        protected_hashes=protected, driver_sha256=sha(__file__), datasets_sha256=sha(OUT / "datasets.npz"))
    write(OUT / "manifest.json", manifest)
    write(OUT / "local_information.json", local)
    print(json.dumps(dict(prepared=True, fits=69, local_information=local)), flush=True)
    return manifest


def run_one(task):
    label, seed, start_index = task
    folder = OUT / "fits"
    folder.mkdir(exist_ok=True)
    stem = f"{label}_seed{seed}_start{start_index+1}"
    path = folder / f"{stem}.json"
    if path.exists():
        return read(path)
    with np.load(OUT / "datasets.npz", allow_pickle=False) as z:
        idx, truth, sigma = z[f"{label}_indices"], z["truth"], float(z["sigma"])
        noise = z[f"noise_{seed}"][idx]
        values = truth.ravel()[idx] + sigma * noise
        raw = z["raw_jacobian_FS"][idx]
    data = dict(indices=idx, values=values, sigma=sigma, noise=.01, seed=seed,
                configuration=label, sampling={})
    record = fit(data, [*STARTS[start_index], .20], unknown_initial=False, fixed={2: .20}, max_nfev=70)
    p = np.array(record["parameters"])
    prediction = forward(p).ravel()[idx]
    residual = (prediction - values) / sigma
    check_chi = float(residual @ residual)
    assert abs(check_chi - record["chi_square"]) < 1e-7 * max(1., check_chi)
    assert p[2] == .20
    linear_error = np.linalg.lstsq(raw / sigma, noise, rcond=None)[0]
    record.update(label=label, seed=seed, start_index=start_index+1,
                  observation_count=len(idx), recovered_FS=p[:2].tolist(),
                  signed_error_FS=(p[:2]-TRUTH).tolist(),
                  absolute_relative_error_percent_FS=(100*np.abs(p[:2]-TRUTH)/TRUTH).tolist(),
                  linear_prediction_error_FS=linear_error.tolist(),
                  independent_forward_chi_square=check_chi,
                  cohort="pilot_multistart" if seed == 101 else "fresh_noise")
    evidence = folder / f"{stem}.npz"
    np.savez_compressed(evidence, indices=idx, noisy_values=values, selected_prediction=prediction,
                        normalized_residual=residual, recovered_FS=p[:2], seed=np.array(seed))
    record["evidence_sha256"] = sha(evidence)
    write(path, record)
    return record


def task_list():
    # Pilot held separate from fresh-noise statistics.
    return ([(d[0], 101, start) for start in range(3) for d in DESIGNS] +
            [(d[0], seed, 2) for seed in FRESH_SEEDS for d in DESIGNS])


def summarize():
    manifest = read(OUT / "manifest.json")
    verify(manifest)
    rows = []
    for label, seed, start in task_list():
        path = OUT / "fits" / f"{label}_seed{seed}_start{start+1}.json"
        if path.exists():
            r = read(path)
            assert sha(path.with_suffix(".npz")) == r["evidence_sha256"]
            rows.append(r)
    fresh = {}
    pilot = {}
    local = read(OUT / "local_information.json")
    for label, *_ in DESIGNS:
        rep = [r for r in rows if r["label"] == label and r["cohort"] == "fresh_noise"]
        pil = [r for r in rows if r["label"] == label and r["cohort"] == "pilot_multistart"]
        if rep:
            errors = np.array([r["signed_error_FS"] for r in rep])
            absrel = 100 * np.abs(errors) / TRUTH
            fresh[label] = dict(replicates=len(rep), successes=sum(r["success"] for r in rep),
                bound_hits=sum(any(r["at_bound"][:2]) for r in rep),
                mean_bias_FS=errors.mean(axis=0).tolist(),
                empirical_sd_FS=errors.std(axis=0, ddof=1).tolist() if len(rep)>1 else None,
                RMSE_FS=np.sqrt(np.mean(errors**2, axis=0)).tolist(),
                relative_RMSE_percent_FS=(100*np.sqrt(np.mean(errors**2, axis=0))/TRUTH).tolist(),
                mean_absolute_relative_error_percent_FS=absrel.mean(axis=0).tolist(),
                median_absolute_relative_error_percent_FS=np.median(absrel, axis=0).tolist(),
                max_absolute_relative_error_percent_FS=absrel.max(axis=0).tolist(),
                q90_absolute_relative_error_percent_FS=np.quantile(absrel, .9, axis=0).tolist(),
                mean_reduced_chi_square=float(np.mean([r["reduced_chi_square"] for r in rep])))
        if pil:
            best = min(pil, key=lambda r:r["chi_square"])
            pilot[label] = dict(attempts=len(pil), successes=sum(r["success"] for r in pil),
                bound_hits=sum(any(r["at_bound"][:2]) for r in pil),
                best_FS=best["recovered_FS"], best_start_index=best["start_index"],
                best_absolute_relative_error_percent_FS=best["absolute_relative_error_percent_FS"],
                start_spread_FS=np.ptp([r["recovered_FS"] for r in pil], axis=0).tolist())
    pairwise = {}
    if all(k in fresh for k in ("S", "P1", "P3")):
        for label in ("P1", "P3"):
            common = []
            for seed in FRESH_SEEDS:
                matches = {r["label"]:r for r in rows if r["seed"]==seed}
                if label in matches and "S" in matches:
                    common.append((matches["S"]["signed_error_FS"], matches[label]["signed_error_FS"]))
            if common:
                err = np.asarray(common)
                pairwise[label + "_vs_S"] = dict(paired_replicates=len(common),
                    count_smaller_absolute_error_FS=np.sum(abs(err[:,1,:])<abs(err[:,0,:]),axis=0).tolist(),
                    RMSE_reduction_percent_FS=(100*(1-np.sqrt(np.mean(err[:,1,:]**2,axis=0)/np.mean(err[:,0,:]**2,axis=0)))).tolist(),
                    local_sd_s_reduction_percent=100*(1-local[label]["local_sd_FS"][1]/local["S"]["local_sd_FS"][1]))
    result = dict(status="complete" if len(rows)==69 else "partial", completed_fits=len(rows),
                  optimizer_successes=sum(r["success"] for r in rows),
                  bound_hits=sum(any(r["at_bound"][:2]) for r in rows),
                  fresh_noise_summary=fresh, pilot_multistart_summary=pilot, paired_comparison=pairwise,
                  protected_sources_and_manuscripts_unchanged=True)
    write(OUT / "summary.json", result)
    with (OUT / "fits_summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        fields = ("label", "seed", "cohort", "start_index", "observation_count", "F", "s", "F_error_percent", "s_error_percent", "success", "at_bound", "nfev", "reduced_chi_square")
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            writer.writerow({**{k:r[k] for k in ("label", "seed", "cohort", "start_index", "observation_count", "success", "nfev", "reduced_chi_square")},
                "F":r["recovered_FS"][0], "s":r["recovered_FS"][1],
                "F_error_percent":r["absolute_relative_error_percent_FS"][0],
                "s_error_percent":r["absolute_relative_error_percent_FS"][1], "at_bound":any(r["at_bound"][:2])})
    print(json.dumps(result), flush=True)
    return result


def run(workers):
    manifest = prepare()
    verify(manifest)
    started = time.perf_counter()
    tasks = task_list()
    failures = []
    with ProcessPoolExecutor(max_workers=workers) as pool:
        pending = {pool.submit(run_one, task):task for task in tasks}
        for count, future in enumerate(as_completed(pending), 1):
            try:
                r = future.result()
                print(json.dumps(dict(done=count, total=len(tasks), design=r["label"], seed=r["seed"],
                                      start=r["start_index"], FS=r["recovered_FS"], success=r["success"])), flush=True)
            except Exception as exc:
                failures.append(dict(task=pending[future], error=repr(exc)))
                print(json.dumps(failures[-1]), flush=True)
    verify(manifest)
    write(OUT / "execution.json", dict(runtime_seconds=time.perf_counter()-started, workers=workers, exceptions=failures))
    summarize()
    if failures:
        raise RuntimeError("Some tasks failed; see execution.json and resume after inspection.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "run", "summary"))
    parser.add_argument("--workers", type=int, default=3)
    args = parser.parse_args()
    if args.action == "prepare":
        prepare()
    elif args.action == "run":
        run(args.workers)
    else:
        summarize()
