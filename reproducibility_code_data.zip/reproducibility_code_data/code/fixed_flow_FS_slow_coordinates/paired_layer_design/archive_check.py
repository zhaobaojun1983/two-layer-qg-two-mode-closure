"""Read-only verification and optional single-fit replay of the archived P3 study.

The original driver and historical manifest are preserved byte for byte. This
entry point resolves numerical inputs relative to this archive, never checks
later manuscript edits against historical manuscript hashes, and never writes
to the archived results. No optimization is run unless --replay-fit is supplied.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import sys

for _name in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_name] = "1"
sys.dont_write_bytecode = True
import numpy as np

HERE = Path(__file__).resolve().parent
CODE = HERE.parent.parent
ARCHIVE = CODE.parent
RESULTS = HERE / "results"
TRUTH = np.array([0.5, 0.5])


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(condition, message):
    if not condition:
        raise ValueError(message)


def close(actual, expected, message, rtol=2e-11, atol=1e-13):
    check(np.allclose(actual, expected, rtol=rtol, atol=atol), message)


def local_information(raw, indices, sigma):
    jac = raw[indices] / sigma
    _, singular, vh = np.linalg.svd(jac * TRUTH, full_matrices=False)
    cov = ((vh.T / singular**2) @ vh) * TRUTH[:, None] * TRUTH[None, :]
    sd = np.sqrt(np.diag(cov))
    return singular, cov, sd, cov[0, 1] / (sd[0] * sd[1])


def verify_archive():
    manifest = read(RESULTS / "manifest.json")
    mapping = read(HERE / "archive_sources.json")
    for record in mapping["files"]:
        path = (ARCHIVE / record["archive_path"]).resolve()
        check(path.is_relative_to(ARCHIVE), "Source mapping leaves the archive")
        check(sha(path) == record["sha256"], f"Frozen numerical source differs: {path}")
    check(sha(HERE / "run_paired_observations.py") == manifest["driver_sha256"], "Historical driver differs")
    check(sha(RESULTS / "datasets.npz") == manifest["datasets_sha256"], "Prepared dataset differs")
    summary = read(RESULTS / "summary.json")
    information = read(RESULTS / "local_information.json")
    with np.load(RESULTS / "datasets.npz", allow_pickle=False) as data:
        truth = data["truth"].copy()
        sigma = float(data["sigma"])
        check(truth.shape == (2, 41, 3, 65), "Unexpected observation tensor")
        close(sigma, manifest["sigma"], "Noise scale differs")
        for seed in (101, *range(2001, 2021)):
            check(np.array_equal(data[f"noise_{seed}"], np.random.default_rng(seed).normal(size=truth.size)),
                  f"Noise field differs: seed {seed}")
        expected_tasks = {(label, 101, start) for label in ("S", "P1", "P3") for start in (1, 2, 3)}
        expected_tasks |= {(label, seed, 3) for label in ("S", "P1", "P3") for seed in range(2001, 2021)}
        records = []
        for path in sorted((RESULTS / "fits").glob("*.json")):
            record = read(path)
            label, seed, start = record["label"], record["seed"], record["start_index"]
            check(path.stem == f"{label}_seed{seed}_start{start}", f"Task naming differs: {path.name}")
            evidence = path.with_suffix(".npz")
            check(sha(evidence) == record["evidence_sha256"], f"Fit evidence hash differs: {path.name}")
            idx = data[f"{label}_indices"]
            observed = truth.ravel()[idx] + sigma * data[f"noise_{seed}"][idx]
            with np.load(evidence, allow_pickle=False) as z:
                check(np.array_equal(z["indices"], idx), f"Observation indices differ: {path.name}")
                close(z["noisy_values"], observed, f"Noisy observations differ: {path.name}")
                residual = (z["selected_prediction"] - observed) / sigma
                close(z["normalized_residual"], residual, f"Residual differs: {path.name}")
                close(z["recovered_FS"], record["recovered_FS"], f"Fit parameters differ: {path.name}")
                close(float(residual @ residual), record["chi_square"], f"Chi-square differs: {path.name}")
                close(float(residual @ residual), record["independent_forward_chi_square"], f"Saved forward check differs: {path.name}")
            check(record["parameters"][2] == 0.2, f"Fixed jet center changed: {path.name}")
            close(np.array(record["recovered_FS"]) - TRUTH, record["signed_error_FS"], f"Parameter error differs: {path.name}")
            records.append(record)
        tasks = {(r["label"], r["seed"], r["start_index"]) for r in records}
        check(tasks == expected_tasks and len(records) == 69, "Expected 9 pilot and 60 fresh-noise fits")
        check(len(list((RESULTS / "fits").glob("*.npz"))) == 69, "Expected 69 evidence files")
        check(all(r["success"] and not any(r["at_bound"][:2]) for r in records), "Unexpected failure or bound hit")
        for design in manifest["designs"]:
            label = design["label"]
            idx = data[f"{label}_indices"]
            check(len(idx) == design["observation_count"], f"Count differs: {label}")
            check(len(np.unique(idx)) == len(idx), f"Repeated index: {label}")
            if label != "S":
                check(np.array_equal(idx[:len(idx)//2] + truth.size//2, idx[len(idx)//2:]), f"Layer pairing differs: {label}")
            singular, cov, sd, correlation = local_information(data["raw_jacobian_FS"], idx, sigma)
            local = information[label]
            close(singular, local["singular_values"], f"Singular values differ: {label}")
            close(cov, local["covariance_FS"], f"Local covariance differs: {label}")
            close(sd, local["local_sd_FS"], f"Local standard deviations differ: {label}")
            close(correlation, local["parameter_correlation"], f"Local correlation differs: {label}")
            fresh = [r for r in records if r["label"] == label and r["cohort"] == "fresh_noise"]
            check(len(fresh) == 20 and {r["seed"] for r in fresh} == set(range(2001, 2021)), f"Fresh cohort differs: {label}")
            errors = np.array([r["signed_error_FS"] for r in fresh])
            saved = summary["fresh_noise_summary"][label]
            close(errors.mean(axis=0), saved["mean_bias_FS"], f"Bias differs: {label}")
            close(errors.std(axis=0, ddof=1), saved["empirical_sd_FS"], f"Empirical SD differs: {label}")
            close(np.sqrt(np.mean(errors**2, axis=0)), saved["RMSE_FS"], f"RMSE differs: {label}")
            close(100*np.sqrt(np.mean(errors**2, axis=0))/TRUTH, saved["relative_RMSE_percent_FS"], f"Relative RMSE differs: {label}")
        with (RESULTS / "fits_summary.csv").open(encoding="utf-8-sig", newline="") as stream:
            csv_rows = list(csv.DictReader(stream))
        check(len(csv_rows) == 69, "Expected 69 CSV fit rows")
        by_task = {(r["label"], r["seed"], r["start_index"]): r for r in records}
        for row in csv_rows:
            key = row["label"], int(row["seed"]), int(row["start_index"])
            close([float(row["F"]), float(row["s"])], by_task[key]["recovered_FS"], "CSV parameters differ")
    execution = read(RESULTS / "execution.json")
    check(not execution["exceptions"], "Recorded execution contains exceptions")
    check(summary["completed_fits"] == 69 and summary["optimizer_successes"] == 69 and summary["bound_hits"] == 0,
          "Summary counts differ")
    return dict(status="passed", checked_fits=69, pilot_fits=9, fresh_noise_fits=60,
                frozen_numerical_files_and_driver=len(mapping["files"]), numpy_verification_version=np.__version__,
                historical_environment=manifest["environment"],
                relative_RMSE_percent_FS={k:v["relative_RMSE_percent_FS"] for k,v in summary["fresh_noise_summary"].items()},
                historical_manuscript_hashes="Preserved as provenance; not treated as current solver dependencies.",
                files_modified=False, optimizations_run=0)


def replay_one(stem, run_fit):
    check(Path(stem).name == stem and not stem.endswith(".json"), "Supply an archived fit stem without a path or suffix")
    record = read(RESULTS / "fits" / f"{stem}.json")
    sys.path.insert(0, str(CODE))
    from direct_identifiability import fit, forward
    with np.load(RESULTS / "datasets.npz", allow_pickle=False) as z:
        idx = z[f"{record['label']}_indices"].copy()
        sigma = float(z["sigma"])
        values = z["truth"].ravel()[idx] + sigma*z[f"noise_{record['seed']}"][idx]
    replay = record
    if run_fit:
        data = dict(indices=idx, values=values, sigma=sigma, noise=.01,
                    seed=record["seed"], configuration=record["label"], sampling={})
        replay = fit(data, record["start"], unknown_initial=False, fixed={2:.20}, max_nfev=70)
    prediction = forward(np.asarray(replay["parameters"])).ravel()[idx]
    with np.load(RESULTS / "fits" / f"{stem}.npz", allow_pickle=False) as z:
        difference = float(np.linalg.norm(prediction-z["selected_prediction"])/np.sqrt(len(idx))/sigma)
    if not run_fit:
        check(difference < 1e-6, "Forward replay differs by more than 1e-6 sigma RMS")
    return dict(fit=stem, optimization_run=run_fit,
                recovered_FS=replay["parameters"][:2],
                difference_from_saved_FS=(np.asarray(replay["parameters"][:2])-record["recovered_FS"]).tolist(),
                prediction_RMS_difference_in_sigma=difference,
                success=bool(replay["success"]), files_modified=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--forward-check", metavar="FIT_STEM", help="recompute one saved prediction without optimization")
    group.add_argument("--replay-fit", metavar="FIT_STEM", help="refit one archived data set in memory; no result files are overwritten")
    args = parser.parse_args()
    result = verify_archive()
    if args.forward_check or args.replay_fit:
        result["replay"] = replay_one(args.forward_check or args.replay_fit, bool(args.replay_fit))
        result["optimizations_run"] = int(bool(args.replay_fit))
    print(json.dumps(result, ensure_ascii=False, indent=2))
