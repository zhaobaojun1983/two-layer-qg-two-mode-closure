"""Symmetric localized waves of the full third-order LONG-WAVE closure.

No integration into a local second-order coupled system is made. Ordered
quadratic coefficients and all four entries of D remain distinct. This script
does not solve the untruncated full projection or the parent QG equations.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/".local_python"))
from scipy.integrate import solve_bvp
from scipy.interpolate import BPoly
from two_mode_closure import closure_coefficients, make_modal_rhs, dx

OUT=ROOT/"traveling_wave_results"


def positive_sqrt(matrix):
    # Principal real square root of the positive-spectrum 2x2 far-field matrix.
    values=np.linalg.eigvals(matrix)
    if np.max(np.abs(values.imag))>1e-10 or np.min(values.real)<=0:
        raise ValueError("Far field is outside the two-decaying-direction branch.")
    determinant=np.linalg.det(matrix)
    sd=np.sqrt(determinant)
    root=(matrix+sd*np.eye(2))/np.sqrt(np.trace(matrix)+2*sd)
    assert np.linalg.norm(root@root-matrix)<1e-9*max(1.,np.linalg.norm(matrix))
    return root


def problem(co,a0):
    if a0>=0:
        raise ValueError("This continuation starts on the negative-amplitude A branch.")
    C,D,G=(co[k] for k in ("C","D","G"))
    scale=abs(a0)
    kappa=np.sqrt(G[0,0,0]*a0/(12*D[0,0]))
    gap=-G[0,0,0]*a0/3
    dinv=np.linalg.inv(D)
    def speed(p):
        return C[0,0]-gap*np.exp(p[0])
    def fun(x,y,p):
        u,ux,uxx=y[:2],y[2:4],y[4:6]
        nonlinear=scale*np.einsum("ipq,px,qx->ix",G,u,ux)
        uxxx=dinv@((speed(p)*np.eye(2)-C)@ux-nonlinear)/kappa**2
        return np.vstack((ux,uxx,uxxx))
    def bc(ya,yb,p):
        K=dinv@(speed(p)*np.eye(2)-C)/kappa**2
        S=positive_sqrt(K)
        return np.r_[ya[0]+1.,ya[2:4],yb[2:4]+S@yb[:2],yb[4:6]-K@yb[:2]]
    return fun,bc,speed,kappa,scale


def initial_guess(x):
    sech2=1/np.cosh(x)**2
    u=np.array([-sech2,np.zeros_like(x)])
    ux=np.array([2*sech2*np.tanh(x),np.zeros_like(x)])
    uxx=np.array([-4*sech2+6*sech2**2,np.zeros_like(x)])
    return np.vstack((u,ux,uxx))


def solve_one(name="baseline",a0=-.01,extent=12.,tol=1e-8,nodes=401,N=64,Ny=4097,guess=None):
    OUT.mkdir(exist_ok=True)
    started=time.perf_counter()
    source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
        (Path(__file__),ROOT/"two_mode_closure.py",ROOT/"_coeffs_strict.py")}
    co=closure_coefficients(N=N,M=Ny)
    fun,bc,speed,kappa,scale=problem(co,a0)
    x=np.linspace(0,extent,nodes)
    y=initial_guess(x) if guess is None else guess.sol(x)
    p=np.array([0.]) if guess is None else guess.p
    sol=solve_bvp(fun,bc,x,y,p=p,tol=tol,bc_tol=min(tol,1e-11),max_nodes=30000)
    print(name,sol.message,"nodes",len(sol.x),"v",speed(sol.p),flush=True)
    if not sol.success:
        raise RuntimeError(sol.message)
    v=float(speed(sol.p))
    # Independent off-collocation point checks of the six first-order equations.
    fractions=np.array([.113,.371,.689,.887])
    tests=(sol.x[:-1,None]+np.diff(sol.x)[:,None]*fractions).ravel()
    yt=sol.sol(tests)
    defect=sol.sol(tests,1)-fun(tests,yt,sol.p)
    first_order_scaled_defect=float(np.max(np.abs(defect)/(1+np.abs(fun(tests,yt,sol.p)))))
    # Quintic Hermite reconstruction uses u,u_X,u_XX, then differentiates u
    # directly three times. This checks the original third-order equation.
    hermite=BPoly.from_derivatives(sol.x,[np.array([sol.y[:2,j],sol.y[2:4,j],sol.y[4:6,j]]) for j in range(len(sol.x))])
    hu=hermite(tests).T
    hp=hermite(tests,1).T
    hppp=hermite(tests,3).T
    C,D,G=(co[k] for k in ("C","D","G"))
    dispersion=D@hppp*kappa**2
    transport=(C-v*np.eye(2))@hp
    nonlinearity=scale*np.einsum("ipq,px,qx->ix",G,hu,hp)
    res=dispersion+transport+nonlinearity
    term_scale=max(np.max(np.abs(dispersion)),np.max(np.abs(transport)),np.max(np.abs(nonlinearity)))
    hermite_residual=float(np.max(np.abs(res))/term_scale)
    component_scales=np.maximum.reduce([np.max(np.abs(term),axis=1) for term in (dispersion,transport,nonlinearity)])
    component_residuals=np.max(np.abs(res),axis=1)/component_scales
    # Integral balance of the unintegrated ordered quadratic terms. Five-point
    # Gauss integration is exact for the relevant products of cubic splines.
    gauss,weights=np.polynomial.legendre.leggauss(5)
    gx=(sol.x[:-1,None]+.5*np.diff(sol.x)[:,None]*(gauss+1)).ravel()
    gy=sol.sol(gx)
    quad=scale*np.einsum("ipq,px,qx->ix",G,gy[:2],gy[2:4])
    cells=(quad.reshape(2,-1,5)*weights[None,None,:]).sum(axis=2)*np.diff(sol.x)[None,:]/2
    integrals=np.c_[np.cumsum(cells[:,::-1],axis=1)[:,::-1],np.zeros(2)]
    balance=D@(sol.y[4:6]*kappa**2)+(C-v*np.eye(2))@sol.y[:2]-integrals
    integral_residual=float(np.max(np.abs(balance))/max(np.max(np.abs(D@(sol.y[4:6]*kappa**2))),np.max(np.abs((C-v*np.eye(2))@sol.y[:2]))))
    # Dense common export in the physical travelling coordinate.
    grid=np.linspace(-extent,extent,8001)
    values=sol.sol(np.abs(grid))
    physical=np.vstack((scale*values[:2],scale*kappa*values[2:4]*np.sign(grid),scale*kappa**2*values[4:6]))
    tail=scale*sol.y[:,-1]
    K=np.linalg.solve(D,v*np.eye(2)-C)
    rates=np.sqrt(np.linalg.eigvals(K).real)
    center=scale*sol.sol(0.)
    # Independent Fourier differentiation and evaluation by the existing PDE
    # implementation: only an instantaneous travelling-wave residual, not a
    # propagation/stability experiment. No spectral filtering hides defects.
    fourier_checks=[]
    for nx in (1024,2048,4096):
        xfft=np.linspace(-extent,extent,nx,endpoint=False)
        fields=scale*hermite(np.abs(xfft)).T
        wave=np.pi*kappa/extent*np.fft.fftfreq(nx)*nx
        ux=dx(fields,wave)
        residual=make_modal_rhs(co,wave,np.ones(nx,dtype=bool),False)(fields)+v*ux
        fourier_checks.append(dict(Nx=nx,
            relative_to_translation=float(np.linalg.norm(residual)/np.linalg.norm(v*ux)),
            component_relative_to_translation=(np.linalg.norm(residual,axis=1)/np.linalg.norm(v*ux,axis=1)).tolist(),
            max_absolute=float(np.max(np.abs(residual)))))
    stats=dict(name=name,settings=dict(F=.5,s=.5,lam=.2,a0=a0,extent=extent,tol=tol,initial_nodes=nodes,N=N,Ny=Ny),
        success=bool(sol.success),message=sol.message,speed=v,scalar_seed_speed=float(C[0,0]+G[0,0,0]*a0/3),
        kappa_seed=float(kappa),physical_half_length=float(extent/kappa),adaptive_nodes=len(sol.x),
        amplitude_scale=scale,center_A=float(center[0]),center_B=float(center[1]),
        A_min=float(physical[0].min()),A_max=float(physical[0].max()),
        B_min=float(physical[1].min()),B_max=float(physical[1].max()),
        boundary_residual=float(np.abs(bc(sol.y[:,0],sol.y[:,-1],sol.p)).max()),
        maximum_rms_collocation_residual=float(sol.rms_residuals.max()),
        independent_first_order_scaled_defect=first_order_scaled_defect,
        independent_quintic_third_order_relative_residual=hermite_residual,
        independent_quintic_component_relative_residuals=component_residuals.tolist(),
        independent_quintic_third_order_absolute_residual=float(np.max(np.abs(res))*scale*kappa),
        integral_balance_relative_residual=integral_residual,
        tail_relative_u=float(np.linalg.norm(sol.y[:2,-1])),
        tail_physical_u=(scale*sol.y[:2,-1]).tolist(),
        tail_physical_first=(scale*kappa*sol.y[2:4,-1]).tolist(),
        tail_physical_second=(scale*kappa**2*sol.y[4:6,-1]).tolist(),
        physical_decay_rates=np.sort(rates).tolist(),
        minimum_decay_rate_times_half_length=float(min(rates)*extent/kappa),
        fourier_pde_residual=fourier_checks,
        centered_third_derivative=(scale*kappa**3*fun(np.array([0.]),sol.sol(np.array([0.])),sol.p)[4:6,0]).tolist(),
        coefficients={key:co[key].tolist() for key in ("C","D","G")},
        source_sha256=source_hashes,runtime_seconds=time.perf_counter()-started)
    np.savez_compressed(OUT/(name+".npz"),zeta=grid/kappa,profile=physical,mesh=sol.x,
                        scaled_states=sol.y,parameter=sol.p,collocation_rms=sol.rms_residuals,
                        quintic_test_zeta=tests/kappa,quintic_residual=res*scale*kappa)
    np.savetxt(OUT/(name+".csv"),np.c_[grid/kappa,physical.T],delimiter=",",
               header="zeta,A,B,A_prime,B_prime,A_second,B_second",comments="")
    (OUT/(name+".json")).write_text(json.dumps(stats,indent=2),encoding="utf-8")
    print(json.dumps({key:stats[key] for key in ("speed","center_B","tail_relative_u","independent_first_order_scaled_defect","independent_quintic_third_order_relative_residual","integral_balance_relative_residual")}),flush=True)
    return sol,stats


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--name",default="baseline")
    for key,default,kind in [("a0",-.01,float),("extent",12.,float),("tol",1e-8,float),
                             ("nodes",401,int),("N",64,int),("Ny",4097,int)]:
        parser.add_argument("--"+key,type=kind,default=default)
    solve_one(**vars(parser.parse_args()))
