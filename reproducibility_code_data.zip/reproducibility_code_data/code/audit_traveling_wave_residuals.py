"""Independent third-order residual audit of the saved travelling-wave reference.

The adaptive-cell quintic is used only to sample function values for the main
audit. Fourier differentiation then evaluates both original third-order ODEs.
An analytic sech-squared control diagnoses the separate, ill-conditioned task
of differentiating the tiny adaptive-cell quintics directly three times.
"""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / ".local_python"))
from scipy.interpolate import BPoly, CubicHermiteSpline

from two_mode_closure import closure_coefficients, make_modal_rhs

OUT = ROOT / "traveling_wave_results"


def norm(value):
    return float(np.linalg.norm(value))


def analytic_control(mesh):
    """Exact u=-sech^2(X), u_X, u_XX sampled before double-precision BPoly."""
    records = []
    fractions = np.array([.113, .371, .689, .887])
    for stride in (1, 2, 4, 8, 16):
        indices = np.unique(np.r_[np.arange(0, len(mesh), stride), len(mesh)-1])
        x = mesh[indices]
        q, t = 1 / np.cosh(x)**2, np.tanh(x)
        u, up, upp = -q, 2*q*t, -4*q+6*q*q
        poly = BPoly.from_derivatives(x, [[a, b, c] for a, b, c in zip(u, up, upp)])
        widths = np.diff(x)
        points = (x[:-1, None] + widths[:, None]*fractions).ravel()
        qp = 1 / np.cosh(points)**2
        exact = 8*qp*np.tanh(points)*(1-3*qp)
        error = poly(points, 3)-exact
        worst = int(np.argmax(np.abs(error)))
        records.append(dict(stride=stride, nodes=len(x), min_cell_width=float(widths.min()),
            max_absolute_third_derivative_error=float(np.abs(error).max()),
            relative_max_third_derivative_error=float(np.abs(error).max()/np.abs(exact).max()),
            worst_scaled_coordinate=float(points[worst]),
            worst_cell_width=float(widths[worst//len(fractions)])))
    return dict(function="u(X)=-sech(X)^2; exact u_X,u_XX,u_XXX used",
        arithmetic="IEEE-754 binary64 input values and SciPy BPoly arithmetic",
        purpose="The analytic control has no BVP error. Its tiny-cell third-derivative error measures differentiation/interpolation conditioning.",
        records=records,
        interpretation="The large local third-derivative error on tiny cells and its decrease upon cell coarsening support roundoff amplification (roughly h^-3) as the dominant fine-cell error. This local BPoly diagnostic is not the primary wave residual metric.")


def main():
    paths = [Path(__file__), OUT/"reference.json", OUT/"reference.npz",
             ROOT/"solve_coupled_traveling_wave.py", ROOT/"two_mode_closure.py"]
    hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    meta = json.loads((OUT/"reference.json").read_text(encoding="utf-8"))
    with np.load(OUT/"reference.npz") as data:
        mesh = data["mesh"].copy()
        state = data["scaled_states"].copy()
        export_zeta = data["zeta"].copy()
        export_profile = data["profile"].copy()
    if state.shape != (6, len(mesh)) or not np.all(np.diff(mesh) > 0):
        raise ValueError("Malformed saved six-state reference.")
    if not np.all(np.isfinite(state)):
        raise ValueError("Nonfinite reference states.")
    setting = meta["settings"]
    a0, scale = setting["a0"], meta["amplitude_scale"]
    kappa, extent, v = meta["kappa_seed"], setting["extent"], meta["speed"]
    C, D, G = (np.array(meta["coefficients"][key]) for key in ("C", "D", "G"))
    if not np.isclose(mesh[-1], extent) or mesh[0] != 0:
        raise ValueError("Mesh extent does not match metadata.")
    poly = BPoly.from_derivatives(mesh,
        [np.array([state[:2, j], state[2:4, j], state[4:6, j]]) for j in range(len(mesh))])
    cubic = CubicHermiteSpline(mesh, state[:2].T, state[2:4].T)
    cubic_at_export = scale*cubic(np.abs(export_zeta*kappa)).T
    # The saved CSV/NPZ profile comes from the C1 cubic solve_bvp interpolant.
    # Preserve and audit it as supplied, instead of replacing it by a smoother
    # reconstruction that happens to differentiate more accurately.
    export_cubic_difference = np.max(np.abs(cubic_at_export-export_profile[:2]), axis=1)
    export_nx = len(export_zeta)-1
    expected_export = np.linspace(-extent/kappa, extent/kappa, export_nx+1)
    if not np.allclose(export_zeta, expected_export, rtol=1e-13, atol=1e-13):
        raise ValueError("Original export is not on the expected uniform grid.")

    # This independent coefficient reconstruction is used only for a secondary
    # consistency comparison with the existing PDE RHS implementation.
    co = closure_coefficients(F=setting["F"], s=setting["s"], lam=setting["lam"],
                              N=setting["N"], M=setting["Ny"])
    coefficient_differences = {key: float(np.max(np.abs(co[key]-matrix)))
                              for key, matrix in zip(("C", "D", "G"), (C, D, G))}
    def evaluate_fields(u, nx, representation):
        wave = np.pi*kappa/extent*np.fft.fftfreq(nx)*nx
        transformed = np.fft.fft(u, axis=-1)
        ux = np.fft.ifft(1j*wave*transformed, axis=-1).real
        uxxx = np.fft.ifft((1j*wave)**3*transformed, axis=-1).real
        dispersion = D@uxxx
        transport = (C-v*np.eye(2))@ux
        a, b = u
        ax, bx = ux
        # Explicitly preserve all four ordered products in BOTH equations.
        nonlinear = np.array([
            G[i, 0, 0]*a*ax + G[i, 1, 1]*b*bx
            + G[i, 0, 1]*a*bx + G[i, 1, 0]*b*ax for i in range(2)])
        residual = dispersion+transport+nonlinear
        terms = (dispersion, transport, nonlinear)
        total_scale = sum(norm(term) for term in terms)
        component_scale = sum(np.linalg.norm(term, axis=1) for term in terms)
        if total_scale <= 0 or np.any(component_scale <= 0):
            raise ValueError("Degenerate residual normalization.")
        # PDE RHS + v*u_x is the negative of the explicit travelling ODE.
        pde = make_modal_rhs(co, wave, np.ones(nx, dtype=bool), False)(u)+v*ux
        consistency = pde+residual
        return dict(Nx=nx, representation=representation, physical_spacing=float(2*extent/kappa/nx),
            spectral_filter="none; all discrete Fourier modes retained",
            relative_moving_frame_L2=norm(residual)/total_scale,
            component_relative_moving_frame_L2=(np.linalg.norm(residual, axis=1)/component_scale).tolist(),
            max_absolute_residual=float(np.abs(residual).max()),
            component_max_absolute_residual=np.max(np.abs(residual), axis=1).tolist(),
            L2_term_norms={name: norm(term) for name, term in zip(("dispersion", "transport", "ordered_quadratic"), terms)},
            component_L2_term_norms={name: np.linalg.norm(term, axis=1).tolist()
                                    for name, term in zip(("dispersion", "transport", "ordered_quadratic"), terms)},
            explicit_ODE_vs_existing_PDE_relative_difference=norm(consistency)/total_scale,
            explicit_ODE_vs_existing_PDE_max_absolute_difference=float(np.abs(consistency).max()),
            relative_to_translation_L2=norm(residual)/norm(v*ux),
            component_relative_to_translation_L2=(np.linalg.norm(residual, axis=1)/np.linalg.norm(v*ux, axis=1)).tolist())

    checks, representation_checks, function_comparisons = [], [], []
    raw_export_check = None
    for nx in (1024, 2048, 4096, export_nx):
        xx = np.linspace(-extent, extent, nx, endpoint=False)
        quintic_values = scale*poly(np.abs(xx)).T
        cubic_values = scale*cubic(np.abs(xx)).T
        function_comparisons.append(dict(Nx=nx,
            component_max_absolute_difference=np.max(np.abs(cubic_values-quintic_values), axis=1).tolist(),
            component_relative_L2_difference=(np.linalg.norm(cubic_values-quintic_values, axis=1)/np.linalg.norm(quintic_values, axis=1)).tolist()))
        quintic_record = evaluate_fields(quintic_values, nx, "C2 quintic Hermite from saved u,u_X,u_XX")
        if nx in (1024, 2048, 4096):
            checks.append(quintic_record)
        representation_checks.append(quintic_record)
        if nx == export_nx:
            cubic_record = evaluate_fields(export_profile[:2, :-1], nx,
                "Original saved C1 cubic profile; last duplicate periodic endpoint omitted")
            raw_export_check = cubic_record
        else:
            cubic_record = evaluate_fields(cubic_values, nx,
                "C1 cubic reconstructed from saved u,u_X; same interpolant as original export")
        representation_checks.append(cubic_record)

    rates = np.linalg.eigvals(np.linalg.solve(D, v*np.eye(2)-C))
    if np.max(np.abs(rates.imag)) > 1e-12 or np.min(rates.real) <= 0:
        raise ValueError("The saved speed lacks two positive decay-rate squares.")
    decay = np.sort(np.sqrt(rates.real))
    controls = analytic_control(mesh)
    setup = dict(parameters={key: setting[key] for key in ("F", "s", "lam", "a0", "N", "Ny")},
        speed=v, center_A=float(scale*state[0, 0]), center_B=float(scale*state[1, 0]),
        center_A_absolute_error=float(abs(scale*state[0, 0]-a0)),
        center_first_derivatives=(scale*kappa*state[2:4, 0]).tolist(),
        physical_half_length=float(extent/kappa),
        physical_decay_rates=decay.tolist(), minimum_decay_rate_times_half_length=float(decay[0]*extent/kappa),
        relative_tail_to_abs_A0=norm(state[:2, -1]),
        tail_physical_u=(scale*state[:2, -1]).tolist(),
        tail_physical_first=(scale*kappa*state[2:4, -1]).tolist(),
        tail_physical_second=(scale*kappa**2*state[4:6, -1]).tolist(),
        coefficient_max_absolute_differences=coefficient_differences)
    criteria = dict(center_A_absolute_error_max=1e-12, center_first_derivative_max=1e-12,
        relative_tail_max=1e-10, minimum_decay_rate_times_half_length_min=20.,
        coefficient_absolute_difference_max=1e-12,
        reported_first_order_scaled_defect_max=1e-8,
        reported_integral_balance_relative_residual_max=1e-10,
        primary_quintic_1024_2048_4096_overall_and_component_moving_frame_L2_max=1e-7,
        explicit_ODE_vs_existing_PDE_relative_difference_max=1e-9)
    outcomes = dict(center_amplitude=setup["center_A_absolute_error"] <= 1e-12,
        center_symmetry=max(abs(value) for value in setup["center_first_derivatives"]) <= 1e-12,
        nonzero_companion=abs(setup["center_B"]) > 1e-12,
        small_tail=setup["relative_tail_to_abs_A0"] <= 1e-10,
        sufficient_tail_length=setup["minimum_decay_rate_times_half_length"] >= 20.,
        coefficient_reconstruction=max(coefficient_differences.values()) <= 1e-12,
        reported_first_order=meta["independent_first_order_scaled_defect"] <= 1e-8,
        reported_integral_balance=meta["integral_balance_relative_residual"] <= 1e-10,
        primary_quintic_explicit_third_order=all(max([r["relative_moving_frame_L2"]]+r["component_relative_moving_frame_L2"]) <= 1e-7 for r in checks),
        PDE_implementation_consistency=all(r["explicit_ODE_vs_existing_PDE_relative_difference"] <= 1e-9 for r in checks))
    raw_export_target_met = max([raw_export_check["relative_moving_frame_L2"]]
        + raw_export_check["component_relative_moving_frame_L2"]) <= 1e-7
    outcomes["original_C1_export_moving_frame_derivative_diagnostic_target"] = raw_export_target_met
    # An additional export documents the natural C2 reconstruction without
    # modifying the original C1 cubic CSV/NPZ. Derivatives here are derivatives
    # of that reconstruction, not substitutes for the independent FFT audit.
    abs_scaled = np.abs(export_zeta*kappa)
    quintic_export = np.vstack((scale*poly(abs_scaled).T,
        scale*kappa*poly(abs_scaled, 1).T*np.sign(export_zeta),
        scale*kappa**2*poly(abs_scaled, 2).T))
    quintic_target = OUT/"reference_quintic.csv"
    np.savetxt(quintic_target, np.c_[export_zeta, quintic_export.T], delimiter=",",
        header="zeta,A,B,A_prime,B_prime,A_second,B_second", comments="")
    result = dict(scope="Residual and locality audit of one computed wave of the corrected long-wave closure; no propagation, stability, or parent-model validity claim.",
        primary_metric="Explicit unintegrated third-order equations, independently Fourier-differentiated from sampled profile values, normalized by the sum of the L2 norms of dispersion, moving-frame transport, and ordered quadratic terms, both jointly and per equation.",
        normalization_note="Moving-frame term normalization avoids dilution by cancellation between c*u_x and v*u_x. Separate equation norms keep the small B component visible.",
        local_quintic_note="Direct third differentiation on the tiny adaptive-cell BPoly reconstruction is a roundoff-sensitive diagnostic, not the primary error metric. Its unfavorable value is retained together with the analytic control.",
        interpolation_note="Both the supplied C1 cubic export and the C2 quintic reconstructed from the saved u,u_X,u_XX are audited at common Fourier grids. The primary derivative operator is uniform-grid Fourier differentiation. No spectral filter or taper is applied. The original CSV/NPZ files remain unchanged.",
        interpretation="All computed residuals are reported, including the larger original-export and local-quintic diagnostics. Increasing residuals at the finest Fourier grids indicate differentiation sensitivity. The recorded numerical targets are analyst-selected diagnostic references, not user requirements or rigorous error bounds; no single pass/fail label combines the distinct diagnostics.",
        setup=setup, Fourier_checks=checks, analytic_quintic_control=controls,
        all_representation_Fourier_checks=representation_checks,
        cubic_vs_quintic_function_values=function_comparisons,
        original_export_audit=dict(Nx=export_nx,
            reconstructed_cubic_vs_original_component_max_difference=export_cubic_difference.tolist(),
            duplicate_endpoint_component_difference=np.abs(export_profile[:2, 0]-export_profile[:2, -1]).tolist(),
            Fourier_check=raw_export_check, analyst_selected_1e_minus_7_derivative_diagnostic_target_met=raw_export_target_met,
            interpretation="The original high-resolution C1 cubic export exceeds the analyst-selected 1e-7 moving-frame third-derivative diagnostic target, which is not a user requirement. Its function values agree with the quintic to about double-precision interpolation accuracy, but three derivatives amplify those small representation differences. Do not report the smallest quintic residual as the residual of every exported representation."),
        additional_quintic_export=dict(path=str(quintic_target.relative_to(ROOT)), rows=len(export_zeta),
            sha256=hashlib.sha256(quintic_target.read_bytes()).hexdigest(),
            description="C2 quintic Hermite reconstruction matching saved u,u_X,u_XX at adaptive nodes. Values and its own first/second derivatives are exported on the original uniform physical coordinate grid. Original reference.csv and reference.npz are retained unchanged."),
        reported_solver_diagnostics=dict(first_order_scaled_defect=meta["independent_first_order_scaled_defect"],
            integral_balance_relative_residual=meta["integral_balance_relative_residual"],
            local_quintic_third_order_relative_residual=meta["independent_quintic_third_order_relative_residual"]),
        diagnostic_targets=criteria, diagnostic_comparisons=outcomes, audit_completed=True,
        diagnostic_target_scope="Analyst-selected numerical reference levels for interpreting the listed measurements. They are not user acceptance requirements and do not replace the actual residual values; distinct diagnostics are not collapsed into one pass/fail verdict.",
        source_sha256=hashes)
    target = OUT/"residual_audit.json"
    target.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(dict(audit_completed=result["audit_completed"],
        primary_quintic_relative_residuals=[r["relative_moving_frame_L2"] for r in checks],
        original_export_audit=result["original_export_audit"],
        local_quintic_relative_residual=meta["independent_quintic_third_order_relative_residual"],
        additional_export=str(quintic_target),
        analytic_control_relative_error=controls["records"][0]["relative_max_third_derivative_error"]), indent=2))


if __name__ == "__main__":
    main()
