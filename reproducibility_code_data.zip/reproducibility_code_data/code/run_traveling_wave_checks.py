"""Convergence tests for a single fixed-amplitude symmetric coupled wave."""
import json
from pathlib import Path
import numpy as np
from solve_coupled_traveling_wave import solve_one

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"traveling_wave_results"


def main():
    specifications=[
        dict(name="tolerance_6",tol=1e-6),
        dict(name="tolerance_8",tol=1e-8),
        dict(name="baseline",tol=1e-10,nodes=801),
        dict(name="domain_8",extent=8.,tol=1e-10,nodes=801),
        dict(name="mesh_201",tol=1e-10,nodes=201),
        dict(name="mesh_1601",tol=1e-10,nodes=1601),
        dict(name="coefficient_N48",tol=1e-10,nodes=801,N=48),
        dict(name="reference",extent=16.,tol=1e-10,nodes=1601),
    ]
    solutions={}
    records={}
    for spec in specifications:
        sol,record=solve_one(**spec)
        solutions[spec["name"]]=sol
        records[spec["name"]]=record
    ref=records["reference"]
    rsol=solutions["reference"]
    comparisons=[]
    for name,sol in solutions.items():
        rec=records[name]
        # Compare physical fields and derivatives on the common physical domain.
        length=min(rec["physical_half_length"],ref["physical_half_length"])
        z=np.linspace(0,length,12001)
        us=sol.sol(z*rec["kappa_seed"])
        ur=rsol.sol(z*ref["kappa_seed"])
        profiles=rec["amplitude_scale"]*us[:2]
        profile_ref=ref["amplitude_scale"]*ur[:2]
        differences=np.linalg.norm(profiles-profile_ref,axis=1)/np.linalg.norm(profile_ref,axis=1)
        comparisons.append(dict(name=name,speed_difference=rec["speed"]-ref["speed"],
            A_relative_L2=float(differences[0]),B_relative_L2=float(differences[1]),
            A_max_absolute=float(np.max(np.abs(profiles[0]-profile_ref[0]))),
            B_max_absolute=float(np.max(np.abs(profiles[1]-profile_ref[1]))),
            center_B_difference=rec["center_B"]-ref["center_B"],
            common_half_length=length))
    summary=dict(scope="One symmetric localized wave of the corrected long-wave closure; no propagation or stability claim.",
                 fixed_amplitude=-.01,reference=ref,runs=records,comparisons=comparisons)
    (OUT/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print("CONVERGENCE "+json.dumps(comparisons),flush=True)


if __name__=="__main__":
    main()
