#!/usr/bin/env python3
"""Regenerate the three final figures without modifying archived evidence.

Place this script in PACKAGE/checks/. From the package root, run:
    python checks/reproduce_figures.py --output output/figures

Use --root to select a different package root. Relative --output paths are
interpreted relative to that root. Original plotting programs run in temporary
directories; only final PDFs, PNG previews, CSV tables and new provenance are
copied to the output directory. No model integration or optimization is run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


FIGURE12_REL = Path(
    "code/fixed_flow_FS_slow_coordinates/"
    "submission_format_20261120/figure_sources"
)
FIGURE3_REL = Path(
    "code/fixed_flow_FS_slow_coordinates/section6_results_figure_20261120"
)
PAIRED_REL = Path("code/fixed_flow_FS_slow_coordinates/paired_layer_design/results")
FIGURE12_FILES = (
    "plot_fig1.py", "plot_fig2.py", "figure_style.py",
    "fig1_source.npz", "fig2_source.npz",
)
CSV_FILES = (
    "recovery_points.csv", "error_quartiles.csv", "local_jacobian.csv",
    "local_covariance.csv", "local_contours.csv", "verified_metrics.csv",
)


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def input_files(root: Path) -> list[Path]:
    files = [root / FIGURE12_REL / name for name in FIGURE12_FILES]
    files.append(root / FIGURE3_REL / "plot_section6_results.py")
    paired = root / PAIRED_REL
    files.extend(paired / name for name in (
        "datasets.npz", "summary.json", "local_information.json",
    ))
    files.extend(
        paired / "fits" / f"{layout}_seed{seed}_start3.json"
        for layout in ("S", "P1", "P3") for seed in range(2001, 2021)
    )
    missing = [p.relative_to(root).as_posix() for p in files if not p.is_file()]
    if missing:
        raise FileNotFoundError("Missing figure inputs:\n  " + "\n  ".join(missing))
    return files


def check_output(root: Path, output: Path) -> None:
    if output == root or root.is_relative_to(output):
        raise ValueError("Choose a separate output directory, not the package root or its parent.")
    for name in ("code", "docs", "checks"):
        protected = (root / name).resolve()
        if output == protected or output.is_relative_to(protected) or protected.is_relative_to(output):
            raise ValueError(f"Output must not overlap archived package directory: {name}/")
    if output.exists() and not output.is_dir():
        raise ValueError("The output path exists and is not a directory.")


def run_original(script: Path, env: dict[str, str], *arguments: str) -> None:
    result = subprocess.run(
        [sys.executable, str(script), *arguments], cwd=script.parent,
        env=env, capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    if result.returncode:
        raise RuntimeError(
            f"{script.name} failed with exit code {result.returncode}.\n"
            f"{result.stdout}\n{result.stderr}"
        )
    print(f"  {script.name}: completed", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[1],
        help="Package root (default: parent of this script's checks/ directory).",
    )
    parser.add_argument(
        "--output", type=Path, default=Path("output/figures"),
        help="Output directory; relative paths are resolved against --root.",
    )
    args = parser.parse_args()
    root = args.root.resolve()
    output = (args.output if args.output.is_absolute() else root / args.output).resolve()
    check_output(root, output)
    inputs = input_files(root)
    initial_hashes = {p.relative_to(root).as_posix(): sha256(p) for p in inputs}

    with tempfile.TemporaryDirectory(prefix="two_layer_qg_figures_") as temporary:
        scratch = Path(temporary)
        fig12_source = scratch / "figure12" / "figure_sources"
        fig12_source.mkdir(parents=True)
        for name in FIGURE12_FILES:
            shutil.copy2(root / FIGURE12_REL / name, fig12_source / name)
        fig3_source = scratch / "figure3"
        fig3_source.mkdir()
        fig3_script = fig3_source / "plot_section6_results.py"
        shutil.copy2(root / FIGURE3_REL / fig3_script.name, fig3_script)
        env = os.environ.copy()
        env["MPLCONFIGDIR"] = str(scratch / "matplotlib_config")
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"

        print("[1/3] Regenerating modal and layer structure", flush=True)
        run_original(fig12_source / "plot_fig1.py", env)
        print("[2/3] Regenerating the parent-QG comparison", flush=True)
        run_original(fig12_source / "plot_fig2.py", env)
        print("[3/3] Regenerating recovery and local identifiability", flush=True)
        fig3_output = scratch / "figure3_output"
        run_original(
            fig3_script, env,
            "--source", str(root / PAIRED_REL), "--output", str(fig3_output),
        )

        products: dict[str, Path] = {}
        for stem in ("fig1_wave_structure", "fig2_parent_comparison"):
            exports = fig12_source.parent / "figures"
            products[stem + ".pdf"] = exports / (stem + ".pdf")
            products[stem + "_preview.png"] = exports / (stem + "_preview.png")
            products[stem + "_provenance.json"] = fig12_source / (stem + "_provenance.json")
        products["fig3_recovery_identifiability.pdf"] = fig3_output / "fig3_recovery_identifiability.pdf"
        products["fig3_preview.png"] = fig3_output / "fig3_preview.png"
        products["fig3_recovery_identifiability_provenance.json"] = fig3_output / "figure_provenance.json"
        products.update({name: fig3_output / name for name in CSV_FILES})
        for name, path in products.items():
            if not path.is_file():
                raise FileNotFoundError(f"Expected generated output is missing: {name}")

        after_hashes = {p.relative_to(root).as_posix(): sha256(p) for p in inputs}
        if initial_hashes != after_hashes:
            raise RuntimeError("An archived figure input changed during reproduction.")
        output.mkdir(parents=True, exist_ok=True)
        for name, path in products.items():
            shutil.copy2(path, output / name)
        manifest = {
            "purpose": "Reproduce the three final figures from unchanged archived inputs",
            "input_sha256": initial_hashes,
            "input_files_unchanged": True,
            "numerical_optimization_or_time_integration": False,
            "figure3_fit_count": 60,
            "figure3_seeds": list(range(2001, 2021)),
            "figure3_pilot_multistarts_plotted": False,
            "output_sha256": {name: sha256(output / name) for name in sorted(products)},
            "provenance_note": (
                "New provenance describes this reproduction. Original records remain unchanged. "
                "The original scripts generate additional TIFF/SVG/raster files in temporary "
                "directories; only PDFs, PNG previews, CSV tables and provenance are retained. "
                "PDF byte identity is not required across plotting-library or font versions."
            ),
        }
        (output / "reproduction_manifest.json").write_text(
            json.dumps(manifest, indent=2) + "\n", encoding="utf-8",
        )
    print(f"Saved 3 PDFs, 3 PNG previews, 6 CSV tables and provenance to {output}")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, RuntimeError) as error:
        raise SystemExit(str(error)) from error
