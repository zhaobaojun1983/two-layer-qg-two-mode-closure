"""Read-only current-manuscript checks from saved arrays; no dynamics are rerun."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
import numpy as np
from scipy.interpolate import BPoly
from scipy.signal import resample


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def load(path, keys=None):
    with np.load(path, allow_pickle=False) as z:
        out = {k: z[k] for k in (z.files if keys is None else keys)}
    for key, value in out.items():
        if np.issubdtype(value.dtype, np.number):
            assert np.isfinite(value).all(), (str(path), key, "nonfinite")
    return out


def same(actual, expected, label, rtol=2e-7, atol=2e-14):
    assert np.allclose(actual, expected, rtol=rtol, atol=atol), (label, actual, expected)


def field_norm(a):
    return np.linalg.norm(a.reshape(len(a), -1), axis=1)


def relative(a, b):
    return field_norm(a-b)/field_norm(b)


def check_modes(code):
    saved = read_json(code / "closure_checks.json")
    assert saved["passed"]
    c = {k: np.asarray(v) for k, v in saved["reference_coefficients"].items()
         if k in ("C", "D", "M", "E", "G", "R")}
    same(c["D"], c["E"]-c["M"]@c["C"], "D=E-MC", atol=2e-14)
    same(np.diag(c["C"]), [-.21103554131604507, -.008366158367535797], "phase speeds")
    wave = read_json(code / "traveling_wave_results/reference.json")
    for key in ("C", "D", "G"):
        same(c[key], wave["coefficients"][key], "reference coefficients "+key)
    audit = read_json(code / "modal_coefficient_checks.json")
    for key in ("biorthogonality_error", "eigen_residual", "parent_jacobian_error"):
        assert audit[key] < 1e-10, key
    coord = read_json(code / "fixed_flow_FS_slow_coordinates/coordinate_consistency_results/coordinate_consistency.json")
    rows = [r for r in coord["comparisons"] if r["case"] in ("reference", "low_start", "high_start")]
    assert len(rows) == 9
    for name in ("reference", "low_start", "high_start"):
        assert sorted(r["epsilon"] for r in rows if r["case"] == name) == [.05, .1, .2]
    max_coord = max(r["observations"]["relative_L2"] for r in rows)
    assert max_coord < 3.6e-15
    evidence_path=code/"fixed_flow_FS_slow_coordinates/coordinate_consistency_results/coordinate_evidence.npz"
    assert hashlib.sha256(evidence_path.read_bytes()).hexdigest()==coord["evidence_sha256"]
    evidence=load(evidence_path)
    same(.01*evidence["reference_slow_modal"],evidence["reference_original_modal"],"saved modal coordinate conversion")
    same(evidence["reference_slow_observations"],evidence["truth_physical"],"saved physical observations")
    same(evidence["slow_x_samples"]/.1,evidence["original_x_samples"],"saved observation positions")
    same(evidence["slow_t_samples"]/.001,evidence["original_t_samples"],"saved observation times")
    return {"phase_speeds": np.diag(c["C"]).tolist(), "coefficient_consistency": "PASS",
            "coordinate_comparisons": 9, "saved_max_coordinate_relative_L2": max_coord,
            "scope": "Saved coefficient, eigen-residual and nine coordinate-audit records; no new eigensolve or forward replay."}


def check_wave(code):
    from solve_coupled_traveling_wave import problem
    folder = code / "traveling_wave_results"
    summary = read_json(folder / "summary.json")
    names = ["reference", "baseline", "domain_8", "mesh_201", "mesh_1601",
             "coefficient_N48", "tolerance_6", "tolerance_8"]
    profiles, metadata = {}, {}
    for name in names:
        m = read_json(folder / (name+".json"))
        z = load(folder / (name+".npz"))
        assert m["success"]
        co = {k: np.asarray(v) for k, v in m["coefficients"].items()}
        fun, bc, speed, kappa, scale = problem(co, m["settings"]["a0"])
        y, x, p = z["scaled_states"], z["mesh"], z["parameter"]
        dy = fun(x, y, p)
        # solve_bvp stores the same piecewise cubic Hermite interpolant.
        interpolant = BPoly.from_derivatives(x, [np.array([y[:,j], dy[:,j]]) for j in range(len(x))])
        same(speed(p), m["speed"], name+" speed", atol=1e-14)
        same(z["collocation_rms"].max(), m["maximum_rms_collocation_residual"], name+" collocation")
        assert np.max(np.abs(bc(y[:,0], y[:,-1], p))) < 1e-10
        reconstructed = scale*interpolant(np.abs(z["zeta"])*kappa).T[:2]
        same(reconstructed, z["profile"][:2], name+" exported profile", atol=3e-14)
        profiles[name] = (interpolant, kappa, scale)
        metadata[name] = m
    ref = metadata["reference"]
    same(ref["speed"], -.21234573184565336, "reference speed")
    same([ref["center_A"], ref["center_B"]], [-.01, -1.0738135962831698e-5], "center values")
    checked = []
    for name in names[1:]:
        m = metadata[name]
        grid = np.linspace(0, min(m["physical_half_length"], ref["physical_half_length"]), 12001)
        f, k, scale = profiles[name]
        fr, kr, sr = profiles["reference"]
        u, v = scale*f(grid*k).T[:2], sr*fr(grid*kr).T[:2]
        err = np.linalg.norm(u-v, axis=1)/np.linalg.norm(v, axis=1)
        recorded = next(r for r in summary["comparisons"] if r["name"] == name)
        same(err, [recorded["A_relative_L2"], recorded["B_relative_L2"]], name+" BVP refinement", atol=3e-13)
        same(m["speed"]-ref["speed"], recorded["speed_difference"], name+" speed refinement")
        checked.append({"name": name, "profile_relative_L2": err.tolist(),
                        "speed_difference": m["speed"]-ref["speed"]})
    assert max(max(r["profile_relative_L2"]) for r in checked) < 5.73e-9
    assert max(abs(r["speed_difference"]) for r in checked) < 1.11e-10
    return {"reference_speed": ref["speed"], "reference_companion_center": ref["center_B"],
            "refinement_runs": checked}


def check_propagation(code):
    from wave_propagation import phase_align
    folder = code / "wave_propagation_results"
    summary = read_json(folder / "summary.json")
    base = load(folder / "unperturbed.npz")
    norm = np.linalg.norm(base["reference"], axis=1)
    raw = np.linalg.norm(base["profiles"]-base["reference"][None], axis=2)/norm
    same(raw, base["relative_error"], "unperturbed error history")
    same(raw.max(axis=0), [1.0953070888691572e-12, 3.260640835770796e-12], "unperturbed maximum")
    pert = load(folder / "localized_1pct.npz")
    same(pert["time"], base["time"], "propagation times")
    same(np.linalg.norm(pert["initial"]-base["initial"], axis=1)/norm, [.01,.01], "initial perturbation")
    x, time = base["x"], base["time"]
    k = 2*np.pi*np.fft.fftfreq(len(x), d=x[1]-x[0])
    whole, core, tail = [], [], []
    for j, u in enumerate(pert["profiles"]):
        shift, aligned = phase_align(u, base["profiles"][j], k)
        diff = u-aligned
        inside = np.abs(x-shift) <= 150
        whole.append(np.linalg.norm(diff, axis=1)/norm)
        core.append(np.linalg.norm(diff[:,inside], axis=1)/norm)
        tail.append(np.linalg.norm(diff[:,~inside], axis=1)/norm)
    whole, core, tail = map(np.asarray, (whole, core, tail))
    saved = summary["cases"]["localized_1pct"]["paired_diagnostics"]
    same(whole.max(axis=0), saved["max_aligned_relative"], "aligned maximum", atol=2e-11)
    same(whole[-1], saved["final_aligned_relative"], "aligned final", atol=2e-11)
    same(core[-1], saved["final_core_aligned_relative"], "aligned core", atol=2e-11)
    same(tail[-1], saved["final_exterior_aligned_relative"], "aligned tail", atol=2e-11)
    same(whole**2, core**2+tail**2, "squared core/tail decomposition")
    refinements=[]
    for name, low in (("unperturbed",base),("localized_1pct",pert)):
        for suffix in ("dt","nx","domain"):
            label=name+"_"+suffix
            high=load(folder/(label+".npz"), ["time","x","profiles"])
            same(high["time"], time, label+" sample times")
            if suffix == "nx":
                same(high["x"][::2], x, label+" nested grid")
                matched=high["profiles"][:,:,::2]
            elif suffix == "domain":
                same(np.diff(high["x"]), x[1]-x[0], label+" fixed grid spacing")
                matched=np.roll(high["profiles"].reshape(len(time),2,2,len(x)).sum(axis=2),len(x)//2,axis=2)
            else:
                same(high["x"],x,label+" grid")
                matched=high["profiles"]
            direct=high["profiles"][:,:,len(x)//2:len(x)//2+len(x)] if suffix=="domain" else matched
            mask=np.abs(x)<=150
            row={"refined":label,
                 "max_relative":(np.linalg.norm(matched-low["profiles"],axis=2)/norm).max(axis=0).tolist(),
                 "max_core_relative":(np.linalg.norm((direct-low["profiles"])[:,:,mask],axis=2)/norm).max(axis=0).tolist(),
                 "max_direct_common_interval_relative":(np.linalg.norm(direct-low["profiles"],axis=2)/norm).max(axis=0).tolist()}
            saved=next(r for r in summary["refinements"] if r["refined"]==label)
            for key in ("max_relative","max_core_relative","max_direct_common_interval_relative"):
                same(row[key],saved[key],label+" "+key,atol=3e-14)
            refinements.append(row)
            del high
    return {"unperturbed_max_relative":raw.max(axis=0).tolist(),
            "companion_aligned_max":float(whole[:,1].max()),"companion_aligned_final":float(whole[-1,1]),
            "companion_core_final":float(core[-1,1]),"companion_tail_final":float(tail[-1,1]),
            "refinements":refinements,"scope":"Finite-time third-order dynamics, not spectral stability or parent-QG solitary-wave validation."}


def check_parent(code):
    folder=code/"long_time_results"
    summary=read_json(folder/"summary.json")
    rows=[]
    for tag in ("k01","k02"):
        for suffix,reference in (("dt","baseline_"+tag),("N","baseline_"+tag),
             ("Nx",tag+"_dt" if tag=="k02" else "baseline_"+tag),
             ("Ny","baseline_"+tag),("N48",tag+"_N"),("N64",tag+"_N48")):
            name=tag+"_"+suffix
            lo=load(folder/(reference+".npz"),["time","parent"])
            hi=load(folder/(name+".npz"),["time","parent"])
            times,il,ih=np.intersect1d(lo["time"],hi["time"],return_indices=True)
            assert len(times)==601
            a,b=lo["parent"][il],hi["parent"][ih]
            nx=min(a.shape[-1],b.shape[-1]); n=max(a.shape[2],b.shape[2])
            a=a[...,::a.shape[-1]//nx]; b=b[...,::b.shape[-1]//nx]
            a=np.pad(a,((0,0),(0,0),(0,n-a.shape[2]),(0,0)))
            b=np.pad(b,((0,0),(0,0),(0,n-b.shape[2]),(0,0)))
            errors=relative(a,b)
            saved=next(r for r in summary["convergence"] if r["variant"]==name)["fields"]["parent"]
            same([errors.max(),errors[-1]],[saved["sampled_maximum"],saved["final"]],name+" parent refinement")
            rows.append({"variant":name,"reference":reference,"maximum":float(errors.max()),"final":float(errors[-1])})
    return rows


def check_fifth(code):
    folder=code/"fixed_flow_FS_slow_coordinates/higher_order_longwave_comparison"
    with (folder/"convergence_summary.csv").open(encoding="utf-8-sig",newline="") as f:
        saved_rows=[r for r in csv.DictReader(f) if r["model"]=="consistent5"]
    output=[]
    for tag,k in (("k10",.1),("k20",.2)):
        parent=load(code/("long_time_results/baseline_"+("k01" if k==.1 else "k02")+".npz"),["time","parent","phi","full","full_error"])
        phi=parent["phi"]
        fields={}
        for setting in ("N32_dt200","N32_dt100","N64_dt100","N64_dt050"):
            stem=tag+"_consistent5_"+setting
            z=load(folder/(stem+".npz"))
            meta=read_json(folder/(stem+".json"))
            digest=hashlib.sha256((folder/(stem+".npz")).read_bytes()).hexdigest()
            assert digest==meta["array_sha256"],stem
            same(z["time"],parent["time"],stem+" times")
            same(z["phi"],phi,stem+" basis")
            fields[setting]=np.einsum("ij,tjx->tix",phi,z["amplitudes"])
            if setting=="N32_dt200":
                target=parent["parent"].reshape(len(z["time"]),-1,32)
                error=relative(fields[setting],target)
                same(error,z["relative_error"],stem+" saved errors")
                full=relative(np.einsum("ij,tjx->tix",phi,parent["full"]),target)
                same(full,parent["full_error"],stem+" full projection")
                primary={"k":k,"fifth_max":float(error.max()),"fifth_final":float(error[-1]),
                         "full_max":float(full.max()),"full_final":float(full[-1])}
        comparisons=[("time_dt0.2_vs_dt0.1_N32",fields["N32_dt200"],fields["N32_dt100"]),
                     ("space_N32_vs_N64_dt0.1",resample(fields["N32_dt100"],64,axis=-1),fields["N64_dt100"]),
                     ("time_dt0.1_vs_dt0.05_N64",fields["N64_dt100"],fields["N64_dt050"])]
        checks=[]
        for label,a,b in comparisons:
            e=relative(a,b)
            saved=next(r for r in saved_rows if float(r["k"])==k and r["comparison"]==label)
            same([e.max(),e[-1]],[float(saved["sampled_max_relative_field_difference"]),float(saved["final_relative_field_difference"])],tag+" "+label,atol=3e-14)
            checks.append({"comparison":label,"maximum":float(e.max()),"final":float(e[-1])})
        primary["solver_refinements"]=checks
        output.append(primary)
    same([r["fifth_max"] for r in output],[.016134883243656004,.02731730530329228],"fifth-order manuscript errors")
    same([r["full_max"] for r in output],[.015966075407670532,.024068399248310775],"full-projection manuscript errors")
    return output


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parents[1],help="Package root containing code/")
    args=parser.parse_args()
    code=args.root.resolve()/"code"
    assert code.is_dir(),code
    sys.path.insert(0,str(code))
    result={"status":"PASS","scope":"Read-only current-manuscript saved-array checks; no time integration, BVP solve or optimization.",
            "modes_and_coordinates":check_modes(code),"boundary_value_wave":check_wave(code),
            "propagation":check_propagation(code),"parent_refinements":check_parent(code),
            "fifth_order_comparison":check_fifth(code)}
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()
