"""Read-only verification of current manuscript inverse evidence.

No forward integration or optimization is run. Original numerical sources and
historical source hashes remain unchanged. Supply the code/data package root.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
import numpy as np


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def close(actual, expected, message, rtol=5e-10, atol=1e-13):
    require(np.allclose(actual, expected, rtol=rtol, atol=atol), message)


def arrays(path):
    with np.load(path, allow_pickle=False) as saved:
        return {key: saved[key].copy() for key in saved.files}


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def information(raw, sigma):
    scaled = raw * 0.5 / sigma
    singular = np.linalg.svd(scaled, compute_uv=False)
    covariance = 0.25 * np.linalg.inv(scaled.T @ scaled)
    sd = np.sqrt(np.diag(covariance))
    correlation = covariance / np.outer(sd, sd)
    return singular, covariance, sd, correlation


def verify_sd(branch):
    directory = branch / "fifth_order_inverse_comparison"
    data = arrays(directory / "matched_parent_data.npz")
    design = arrays(directory / "observation_design.npz")
    metadata = read(directory / "matched_parent_data.json")
    require(sha(directory / "matched_parent_data.npz") == metadata["matched_data_sha256"], "SD data hash")
    indices, sigma = data["indices"], float(data["sigma"])
    require(len(indices) == 747 and len(np.unique(indices)) == 747, "SD indices")
    require(np.array_equal(indices, design["indices"]), "SD design indices")
    close(sigma, design["sigma"], "SD noise scale")
    close(data["standard_normal_noise"], design["standard_normal_noise"], "SD noise realization")
    parent = data["parent_full"]
    close(data["noiseless"], parent.ravel()[indices], "SD noiseless data")
    close(data["noisy"], data["noiseless"] + sigma * data["standard_normal_noise"][indices], "SD noisy data")
    cases = ["parent_third_noiseless", "parent_fifth_noiseless", "parent_third_noisy", "parent_fifth_noisy"]
    fits, evidence = {}, {}
    for name in cases:
        record = read(directory / f"{name}.json")
        saved = arrays(directory / f"{name}.npz")
        evidence[name] = saved
        require(record["success"] and record["active_mask"] == [0, 0], f"{name}: convergence/bounds")
        require(record["nfev"] == 9, f"{name}: recorded evaluation count")
        parameters = np.asarray(record["recovered_FS"])
        require(np.all(parameters > [.25, .30]) and np.all(parameters < [.90, .70]), f"{name}: interior estimates")
        for file, key in [(f"{name}.npz", "evidence_sha256"), ("matched_parent_data.npz", "matched_data_sha256"), ("forward_models.py", "forward_source_sha256"), ("run_limited_comparison.py", "runner_source_sha256")]:
            require(sha(directory / file) == record[key], f"{name}: {key}")
        require(np.array_equal(saved["indices"], indices), f"{name}: indices")
        close(saved["values"], data[record["data_kind"]], f"{name}: selected data")
        residual = (saved["prediction"].ravel()[indices] - saved["values"]) / sigma
        close(residual, saved["residual"], f"{name}: residual")
        chi = float(residual @ residual)
        close(chi, record["chi_square"], f"{name}: objective")
        close(chi / 745, record["reduced_chi_square"], f"{name}: reduced objective")
        close(np.sqrt(np.mean(residual**2)), record["residual_rms_in_sigma"], f"{name}: RMS")
        parameter_errors = 100 * np.abs(parameters - .5) / .5
        close(parameter_errors, record["absolute_relative_error_percent_FS"], f"{name}: parameter errors")
        selected_error = np.linalg.norm((saved["prediction"] - parent).ravel()[indices]) / np.linalg.norm(data["noiseless"])
        close(selected_error, record["selected_reference_relative_L2"], f"{name}: selected field error")
        full_error = np.linalg.norm(saved["prediction"] - parent) / np.linalg.norm(parent)
        close(full_error, record["full_reference_relative_L2"], f"{name}: full field error")
        fits[name] = {"relative_parameter_error_percent_FS": parameter_errors.tolist(), "selected_field_error_percent": 100 * float(selected_error), "chi_square": chi}
    local = read(directory / "local_information.json")
    saved_local = arrays(directory / "local_information.npz")
    require(np.array_equal(saved_local["indices"], indices), "SD information indices")
    local_result = {}
    for model in ["third", "consistent5"]:
        singular, covariance, sd, corr = information(saved_local[model + "_jacobian"][indices], sigma)
        record = local["models"][model]
        require(np.count_nonzero(singular > 1e-7 * singular[0]) == record["rank"] == 2, "SD local rank")
        close(singular, record["singular_values"], "SD singular values")
        close(covariance, record["covariance_physical"], "SD covariance")
        close(sd, record["local_standard_error"], "SD local standard errors")
        close(corr, record["correlation"], "SD local correlation")
        local_result[model] = {"singular_values": singular.tolist(), "standard_errors_FS": sd.tolist(), "correlation": float(corr[0, 1])}
    refinements = read(directory / "parent_resolution_comparison.json")
    parent_checks = []
    for record in refinements["comparisons"]:
        coarse = arrays(directory / (record["coarse"] + ".npz"))["observations"]
        fine = arrays(directory / (record["fine"] + ".npz"))["observations"]
        difference = fine - coarse
        rms = float(np.sqrt(np.mean(difference.ravel()[indices]**2)) / sigma)
        close(rms, record["designs"]["surface_deep"]["rms_over_sigma"], "SD parent refinement RMS")
        close(np.linalg.norm(difference) / np.linalg.norm(fine), record["relative_l2"], "SD parent refinement norm")
        parent_checks.append({"coarse": record["coarse"], "fine": record["fine"], "SD_RMS_in_sigma": rms})
    steps = read(directory / "fit_point_convergence.json")
    require(sha(directory / "fit_point_convergence.npz") == steps["evidence_sha256"], "SD fitted-step evidence hash")
    step_arrays = arrays(directory / "fit_point_convergence.npz")
    step_rms = []
    for record in steps["cases"]:
        name = record["case"]
        difference = step_arrays[name + "_fine_prediction"] - evidence[name]["prediction"]
        close(difference, step_arrays[name + "_delta_prediction"], "SD fitted-step delta")
        rms = float(np.sqrt(np.mean(difference.ravel()[indices]**2)) / sigma)
        close(rms, record["SD_RMS_in_sigma"], "SD fitted-step RMS")
        step_rms.append(rms)
    return {"status": "passed", "parent_data_fit_count": 4, "fits": fits, "local_information": local_result, "parent_refinements": parent_checks, "maximum_fitted_step_RMS_in_sigma": max(step_rms)}


def verify_sampling_scan(branch):
    directory = branch / "sampling_scale_scan"
    report = read(directory / "sampling_scale_scan_results.json")
    for relative, expected in report["inputs_sha256"].items():
        require(sha(branch / relative.replace("\\", "/")) == expected, "Sampling scan input hash")
    require(sha(directory / "run_sampling_scale_scan.py") == report["analysis_script_sha256"], "Sampling scan source hash")
    source = arrays(branch / "noisy_fs_results/local_information.npz")
    raw, sigma = source["raw_jacobian_six_columns"], float(source["noise_sigma"])
    require(raw.shape == (2 * 41 * 3 * 65, 6), "Sampling scan master derivative shape")
    with (directory / "sampling_scale_scan.csv").open(encoding="utf-8-sig", newline="") as stream:
        csv_rows = list(csv.DictReader(stream))
    require(len(report["results"]) == len(csv_rows) == 9, "Nine local scan records")
    nearly_equal = []
    for record, csv_row in zip(report["results"], csv_rows):
        nx, nt = record["n_x"], record["n_t"]
        xi = np.rint(np.linspace(0, 64, nx)).astype(int)
        ti = np.rint(np.linspace(0, 40, nt)).astype(int)
        indices = np.array([((t * 3) + 1) * 65 + x for t in ti for x in xi], dtype=int)
        singular, covariance, sd, corr = information(raw[indices, :2], sigma)
        close(singular, [record["singular_value_max"], record["singular_value_min"]], "Sampling scan singular values")
        close(sd, [record["local_se_F"], record["local_se_s"]], "Sampling scan standard errors")
        close(corr[0, 1], record["local_correlation_F_s"], "Sampling scan correlation")
        require(np.count_nonzero(singular > 1e-7 * singular[0]) == record["numerical_rank"] == 2, "Sampling scan rank")
        require(record["n_observations"] == nx * nt, "Sampling scan count")
        close([float(csv_row["local_se_F"]), float(csv_row["local_se_s"])], sd, "Sampling scan CSV")
        if (nx, nt) in [(17, 41), (33, 21), (65, 11)]:
            nearly_equal.append({"nx": nx, "nt": nt, "count": nx * nt, "standard_errors_FS": sd.tolist()})
    require(len(nearly_equal) == 3, "Near-equal-budget scan subset")
    values = np.asarray([row["standard_errors_FS"] for row in nearly_equal])
    spread = 100 * (values.max(axis=0) / values.min(axis=0) - 1)
    require(np.all(spread < 4), "Retained less-than-4-percent claim")
    return {"status": "passed", "local_layouts_recomputed": 9, "nonlinear_fits_run": 0, "nearly_equal_budget_layouts": nearly_equal, "maximum_pairwise_relative_standard_error_spread_percent_FS": spread.tolist()}


def verify(root):
    root = Path(root).resolve()
    branch = root / "code/fixed_flow_FS_slow_coordinates"
    original = load_module(branch / "paired_layer_design/archive_check.py", "_current_inverse_archive_check")
    return {"status": "passed", "package_root": str(root), "paired_layer_archive": original.verify_archive(), "SD_comparison": verify_sd(branch), "local_sampling_scan": verify_sampling_scan(branch), "files_modified": False, "forward_integrations_run": 0, "optimizations_run": 0}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True, help="Package root containing code/")
    arguments = parser.parse_args()
    print(json.dumps(verify(arguments.root), indent=2, ensure_ascii=False))
