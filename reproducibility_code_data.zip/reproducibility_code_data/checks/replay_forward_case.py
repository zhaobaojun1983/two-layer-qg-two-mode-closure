"""Replay one current-manuscript forward case into a fresh external directory."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True

WAVE = {"reference", "baseline", "domain_8", "mesh_201", "mesh_1601",
        "coefficient_N48", "tolerance_6", "tolerance_8"}
PROPAGATION = {base+suffix for base in ("unperturbed", "localized_1pct")
               for suffix in ("", "_dt", "_nx", "_domain")}
PARENT = {"baseline_k01", "baseline_k02"} | {
    tag+"_"+suffix for tag in ("k01", "k02")
    for suffix in ("dt", "N", "Nx", "Ny", "N48", "N64")}
FIFTH = {tag+"_consistent5_"+setting for tag in ("k10", "k20")
         for setting in ("N32_dt200", "N32_dt100", "N64_dt100", "N64_dt050")}
ALLOWED = {"wave": WAVE, "propagation": PROPAGATION, "parent": PARENT, "fifth": FIFTH}


def module_from_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def plan(code, kind, case):
    folders = {"wave": "traveling_wave_results", "propagation": "wave_propagation_results",
               "parent": "long_time_results",
               "fifth": "fixed_flow_FS_slow_coordinates/higher_order_longwave_comparison"}
    path = code/folders[kind]/(case+".json")
    meta = json.loads(path.read_text(encoding="utf-8-sig"))
    s = meta["settings"]
    if kind == "wave":
        assert (s["F"],s["s"],s["lam"]) == (.5,.5,.2)
        kwargs = {"name": case, "a0": s["a0"], "extent": s["extent"], "tol": s["tol"],
                  "nodes": s["initial_nodes"], "N": s["N"], "Ny": s["Ny"]}
        script, function, destination = "solve_coupled_traveling_wave.py", "solve_one", "OUT"
    elif kind == "propagation":
        kwargs = {"name": case, **{k: s[k] for k in ("nx","length","dt","duration","sample","kind","epsilon")}}
        script, function, destination = "wave_propagation.py", "run_case", "OUT"
    elif kind == "parent":
        assert (s["F"],s["s"],s["lam"],s["Nmode"],s["coefficient_quadrature"]) == (.5,.5,.2,24,1025)
        kwargs = {k: s[k] for k in ("name","k","amp","ratio","phase","lam","N","Nx","Ny","dt","duration","sample")}
        script, function, destination = "long_time_validation.py", "run", "OUT"
    else:
        assert meta["model"] == "consistent5"
        assert (s["duration"],s["sample"],s["Nmode"],s["quadrature"]) == (3000.,5.,24,1025)
        kwargs = {"k":s["k"],"model":"consistent5","nx":s["Nx"],"dt":s["dt"]}
        script = "fixed_flow_FS_slow_coordinates/higher_order_longwave_comparison/run_comparison.py"
        function, destination = "run", "HERE"
    return {"kind":kind,"case":case,"metadata":str(path),"script":script,
            "function":function,"output_global":destination,"parameters":kwargs}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parents[1],help="Package root containing code/")
    parser.add_argument("--kind",choices=tuple(ALLOWED),required=True)
    parser.add_argument("--case",required=True,help="Exact archived stem; only current-manuscript cases are accepted")
    parser.add_argument("--output",type=Path,required=True,help="New directory outside the immutable package; must not exist")
    parser.add_argument("--dry-run",action="store_true",help="Print exact archived parameters; create no files and run no solver")
    args=parser.parse_args()
    if args.case not in ALLOWED[args.kind]:
        parser.error("Unsupported current-manuscript case. Choose: "+", ".join(sorted(ALLOWED[args.kind])))
    root=args.root.resolve()
    code=root/"code"
    output=args.output.resolve()
    if not code.is_dir():
        parser.error("The package root must contain code/.")
    if output.exists():
        parser.error("The output directory already exists; choose a new directory.")
    if output == root or output.is_relative_to(root):
        parser.error("The output directory must be outside the immutable package root.")
    record=plan(code,args.kind,args.case)
    record.update(output=str(output),dry_run=args.dry_run)
    print(json.dumps(record,indent=2),flush=True)
    if args.dry_run:
        return
    sys.path.insert(0,str(code))
    module=module_from_file("current_manuscript_replay_"+args.kind,code/record["script"])
    # The archived source stays unchanged. Only this process's destination changes.
    setattr(module,record["output_global"],output)
    output.mkdir(parents=True,exist_ok=False)
    getattr(module,record["function"])(**record["parameters"])
    print(json.dumps({"status":"completed","kind":args.kind,"case":args.case,"output":str(output)}),flush=True)


if __name__=="__main__":
    main()
