"""Replay one current SD forward calculation or optionally refit in memory.

Uses unchanged numerical routines with package-relative saved observations.
Historical driver initialize()/protect() are never called. No files are written.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

for _key in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[_key] = "1"
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from check_inverse_results import arrays, read, require, sha, verify_sd
import numpy as np

CASES = ("parent_third_noiseless", "parent_fifth_noiseless", "parent_third_noisy", "parent_fifth_noisy")


def replay(root, case, refit=False):
    require(case in CASES, "Choose one of the four current SD cases")
    root = Path(root).resolve()
    branch = root / "code/fixed_flow_FS_slow_coordinates"
    directory = branch / "fifth_order_inverse_comparison"
    # Read-only array/hash validation precedes any new numerical calculation.
    verify_sd(branch)
    record = read(directory / f"{case}.json")
    saved = arrays(directory / f"{case}.npz")
    data = arrays(directory / "matched_parent_data.npz")
    indices, sigma = data["indices"], float(data["sigma"])
    values = data[record["data_kind"]]
    model = record["model"]
    require(sha(directory / "forward_models.py") == record["forward_source_sha256"], "Forward source hash")
    spec = importlib.util.spec_from_file_location("_portable_sd_forward_models", directory / "forward_models.py")
    numerical = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(numerical)
    started = time.perf_counter()
    parameters = np.asarray(record["recovered_FS"], dtype=float)
    optimizer = None
    if refit:
        from scipy.optimize import least_squares
        cache = {}

        def objective(p):
            key = tuple(p)
            if key not in cache:
                prediction = numerical.forward_FS(p, model=model)
                cache.clear()
                cache[key] = (prediction.ravel()[indices] - values) / sigma
            return cache[key]

        def jacobian(p):
            return numerical.jacobian_FS(p, model=model)[indices] / sigma

        result = least_squares(objective, record["start_FS"], jac=jacobian,
                               bounds=([.25, .30], [.90, .70]), x_scale=[.5, .5],
                               ftol=2e-9, xtol=2e-9, gtol=1e-7, max_nfev=45)
        parameters = result.x
        optimizer = {"success": bool(result.success), "message": str(result.message), "nfev": int(result.nfev), "active_mask": result.active_mask.tolist()}
    prediction = numerical.forward_FS(parameters, model=model)
    residual = (prediction.ravel()[indices] - values) / sigma
    delta = prediction - saved["prediction"]
    return {"case": case, "model": model, "optimization_run": bool(refit),
            "parameters_FS": parameters.tolist(), "archived_parameters_FS": record["recovered_FS"],
            "parameter_difference_FS": (parameters - np.asarray(record["recovered_FS"])).tolist(),
            "prediction_difference_RMS_in_sigma": float(np.sqrt(np.mean(delta**2)) / sigma),
            "prediction_difference_relative_L2": float(np.linalg.norm(delta) / np.linalg.norm(saved["prediction"])),
            "chi_square": float(residual @ residual), "archived_chi_square": record["chi_square"],
            "optimizer": optimizer, "runtime_seconds": time.perf_counter() - started,
            "files_modified": False, "historical_driver_called": False,
            "numpy_runtime": np.__version__}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--case", choices=CASES, default="parent_third_noiseless")
    parser.add_argument("--refit", action="store_true", help="Run one bounded nonlinear optimization in memory; default replays only one saved forward prediction")
    arguments = parser.parse_args()
    print(json.dumps(replay(arguments.root, arguments.case, arguments.refit), indent=2, ensure_ascii=False))
