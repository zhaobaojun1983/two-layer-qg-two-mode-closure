"""Portable entry point for the selected manuscript code/data archive."""
from pathlib import Path
import argparse
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("check", "figures"))
    parser.add_argument("--output", type=Path, default=Path("output/figures"),
                        help="Figure output; relative to the package root")
    args = parser.parse_args()
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    if args.action == "figures":
        subprocess.run([sys.executable, "-B", str(ROOT / "checks/reproduce_figures.py"),
                        "--root", str(ROOT), "--output", str(args.output)],
                       cwd=ROOT, env=env, check=True)
        return
    results = {}
    for kind in ("forward", "inverse"):
        command = [sys.executable, "-B", str(ROOT / ("checks/check_" + kind + "_results.py")),
                   "--root", str(ROOT)]
        process = subprocess.run(command, cwd=ROOT, env=env, capture_output=True,
                                 text=True, encoding="utf-8", errors="replace")
        if process.returncode:
            raise RuntimeError(kind + " check failed:\n" + process.stdout + process.stderr)
        results[kind] = json.loads(process.stdout)
    print(json.dumps({"status": "passed", "files_modified": False,
                      "time_integration_or_optimization": False, "checks": results},
                     indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
