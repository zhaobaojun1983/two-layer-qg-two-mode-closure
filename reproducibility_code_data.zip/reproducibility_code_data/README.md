# Modal closure and local parameter identifiability for coupled Rossby waves

Code and numerical data supporting the main results of
`2146446_1_supp_latex_26635107_tnf36y.new`, by Bao-jun Zhao and Chao-wei Xu.
Prepared on 2026-11-23 for the repository
<https://github.com/zhaobaojun1983/two-layer-qg-two-mode-closure>.

## Contents

| Paper result | Included material |
| --- | --- |
| Sections II–III: modes and closure | Eigenproblem, adjoints, coefficients, branch tracking and original/slow-coordinate evidence |
| Section IV: coupled wave | Reference boundary-value solution, seven resolution comparisons, unperturbed/1% perturbed propagation and refinements |
| Section V: parent comparison | Two periodic parent-QG benchmarks, full projection, consistent fifth-order trajectories and refinement records |
| Section VI: parameter recovery | S/P1/P3 observations, saved noise, 60 principal fits and nine separate multistart checks, Jacobians and local information |
| Section VI: independent order comparison | Four third/fifth-order fits to parent-generated SD observations and their accuracy checks |
| Figures 1–3 | Plotting programs, numerical source arrays/tables, provenance and reference figure PDFs |

This is a selected code/data archive. The article, reviewer correspondence and
submission files are not included. Original numerical files are copied without
changing their bytes. A few compound historical records also contain auxiliary
entries; the supported checks select the cases used in the current paper.
The former nine-layout **nonlinear** fitting archive is excluded. The small
local-information sampling scan is retained because its less-than-4% result
remains in Section VI C.

## Quick start

Use Python 3.12. In a terminal opened in this directory:

```text
python -m venv .venv
```

Activate `.venv` with the command appropriate to your shell, then run:

```text
python -m pip install -r requirements.txt
python -B verify_release.py
python -B reproduce.py check
python -B reproduce.py figures --output output/figures
```

`check` recomputes diagnostics from archived arrays, including all 69 S/P1/P3
records and four SD fits. It does not integrate trajectories or fit parameters.
`figures` regenerates all three figures in a temporary work area, then writes
PDFs, PNG previews and source/provenance files to the requested output directory.
The shipped evidence stays unchanged. Numerical source values are reproducible;
PDF metadata and rendering need not be byte-identical across environments.

## Optional numerical replay

One S/P1/P3 forward prediction, followed by an optional single nonlinear refit:

```text
python -B code/fixed_flow_FS_slow_coordinates/paired_layer_design/archive_check.py --forward-check P3_seed2001_start3
python -B code/fixed_flow_FS_slow_coordinates/paired_layer_design/archive_check.py --replay-fit P3_seed2001_start3
```

One independent SD forward prediction, followed by an optional single refit:

```text
python -B checks/replay_sd.py --root . --case parent_third_noiseless
python -B checks/replay_sd.py --root . --case parent_third_noiseless --refit
```

The supported SD cases are `parent_third_noiseless`, `parent_fifth_noiseless`,
`parent_third_noisy` and `parent_fifth_noisy`. Replays leave archived fits unchanged.
Use the same P3 command with another saved fit stem to reproduce another seed
or layout. All recorded seeds, observations and starts are included.

The original experiment drivers preserve their original source hashes and
historical guards. Some guards refer to old manuscript paths. Use the portable
entry points above instead of launching those historical drivers wholesale.
The underlying forward solvers are included; their inputs and case settings
are indexed in [docs/results_index.md](docs/results_index.md).

For a full forward-case replay, select an archived case and a **new directory
outside this package**. Start with `--dry-run` to inspect the exact saved
settings without computing:

```text
python -B checks/replay_forward_case.py --root . --kind wave --case reference --output ../wave_replay --dry-run
python -B checks/replay_forward_case.py --root . --kind wave --case reference --output ../wave_replay
```

The same wrapper supports `--kind propagation --case localized_1pct`,
`--kind parent --case baseline_k02` and
`--kind fifth --case k20_consistent5_N32_dt200`, each with its own fresh
output directory. All eight wave, eight propagation, fourteen parent and
eight fifth-order archived cases are supported. These commands rerun solvers
and may take substantially longer than checking saved arrays.

## Environment and provenance

`requirements.txt` records the installed versions used for this package's
record checks and figure regeneration. The historical fitting manifest records
Python 3.12.14, NumPy 2.3.5 and SciPy 1.18.1; its numerical dependency pins are
also preserved in `docs/requirements-historical-replay.txt`. Run-specific
manifests remain the authority for the original calculations. Packaging does
not change those historical versions or imply a full simulation-suite rerun.

See [numerical methods](docs/numerical_methods.md),
[result-to-file index](docs/results_index.md) and
[validation](docs/validation.md). `package_manifest.json` lists each selected
historical file and its original hash; `SHA256SUMS.txt` covers the delivered
package, including the new portable wrappers and documentation.

OpenAI Codex assisted with computational scripting, numerical consistency
checks and data-derived figure preparation. The authors are responsible for
the methods, interpretation and scientific content. License terms have not
yet been specified by the authors. When citing these materials, identify the
paper and the repository version or commit actually used.
