"""Verify every archived file against SHA256SUMS.txt, without writing files."""
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
checked = 0
for line in (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
    expected, relative = line.split("  ", 1)
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Checksum path leaves this archive: " + relative)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    if digest.hexdigest() != expected:
        raise ValueError("Checksum mismatch: " + relative)
    checked += 1
print(f"PASS: {checked} files verified; no files modified.")
